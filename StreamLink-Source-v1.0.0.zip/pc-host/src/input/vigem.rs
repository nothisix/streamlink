//! Direct Win32 ViGEmBus Xbox 360 virtual controller driver client.
//! Uses exact IOCTLs from nefarius/ViGEmBus (`BusShared.h`) with zero external DLLs.

use std::ffi::c_void;
use std::mem::size_of;

use windows::core::GUID;
use windows::Win32::Devices::DeviceAndDriverInstallation::{
    SetupDiDestroyDeviceInfoList, SetupDiEnumDeviceInterfaces, SetupDiGetClassDevsW,
    SetupDiGetDeviceInterfaceDetailW, DIGCF_DEVICEINTERFACE, DIGCF_PRESENT,
    SP_DEVICE_INTERFACE_DATA, SP_DEVICE_INTERFACE_DETAIL_DATA_W,
};
use windows::Win32::Foundation::{CloseHandle, HANDLE, INVALID_HANDLE_VALUE};
use windows::Win32::Storage::FileSystem::{
    CreateFileW, FILE_ATTRIBUTE_NORMAL, FILE_FLAG_NO_BUFFERING, FILE_FLAG_OVERLAPPED,
    FILE_FLAG_WRITE_THROUGH, FILE_SHARE_READ, FILE_SHARE_WRITE, OPEN_EXISTING,
};
use windows::Win32::System::IO::{DeviceIoControl, GetOverlappedResult, OVERLAPPED};
use windows::Win32::System::Threading::CreateEventW;

use crate::net::protocol::GamepadInput;

// {96E42B22-F5E9-42F8-B043-ED0F932F014F}
const GUID_DEVINTERFACE_BUSENUM_VIGEM: GUID = GUID::from_values(
    0x96E42B22,
    0xF5E9,
    0x42F8,
    [0xB0, 0x43, 0xED, 0x0F, 0x93, 0x2F, 0x01, 0x4F],
);

const FILE_DEVICE_BUS_EXTENDER: u32 = 0x0000_002A;
const METHOD_BUFFERED: u32 = 0;
const FILE_WRITE_DATA: u32 = 2;

const fn ctl_code(device_type: u32, function: u32, method: u32, access: u32) -> u32 {
    (device_type << 16) | (access << 14) | (function << 2) | method
}

const IOCTL_VIGEM_BASE: u32 = 0x801;
const IOCTL_VIGEM_PLUGIN_TARGET: u32 =
    ctl_code(FILE_DEVICE_BUS_EXTENDER, IOCTL_VIGEM_BASE + 0x000, METHOD_BUFFERED, FILE_WRITE_DATA);
const IOCTL_VIGEM_UNPLUG_TARGET: u32 =
    ctl_code(FILE_DEVICE_BUS_EXTENDER, IOCTL_VIGEM_BASE + 0x001, METHOD_BUFFERED, FILE_WRITE_DATA);
const IOCTL_VIGEM_CHECK_VERSION: u32 =
    ctl_code(FILE_DEVICE_BUS_EXTENDER, IOCTL_VIGEM_BASE + 0x002, METHOD_BUFFERED, FILE_WRITE_DATA);
const IOCTL_VIGEM_WAIT_DEVICE_READY: u32 =
    ctl_code(FILE_DEVICE_BUS_EXTENDER, IOCTL_VIGEM_BASE + 0x003, METHOD_BUFFERED, FILE_WRITE_DATA);
const IOCTL_XUSB_SUBMIT_REPORT: u32 =
    ctl_code(FILE_DEVICE_BUS_EXTENDER, IOCTL_VIGEM_BASE + 0x201, METHOD_BUFFERED, FILE_WRITE_DATA);

const VIGEM_COMMON_VERSION: u32 = 0x0001;
const VIGEM_TARGET_XBOX360_WIRED: i32 = 0;

#[repr(C)]
struct VigemCheckVersion {
    size: u32,
    version: u32,
}

#[repr(C)]
struct VigemPluginTarget {
    size: u32,
    serial_no: u32,
    target_type: i32,
    vendor_id: u16,
    product_id: u16,
}

#[repr(C)]
struct VigemUnplugTarget {
    size: u32,
    serial_no: u32,
}

#[repr(C)]
struct VigemWaitDeviceReady {
    size: u32,
    serial_no: u32,
}

#[repr(C)]
#[derive(Clone, Copy)]
struct XusbReport {
    w_buttons: u16,
    b_left_trigger: u8,
    b_right_trigger: u8,
    s_thumb_lx: i16,
    s_thumb_ly: i16,
    s_thumb_rx: i16,
    s_thumb_ry: i16,
}

#[repr(C)]
struct XusbSubmitReport {
    size: u32,
    serial_no: u32,
    report: XusbReport,
}

pub struct ViGEmController {
    bus_handle: HANDLE,
    serial_no: u32,
    event_handle: HANDLE,
    last_seq: u32,
}

unsafe impl Send for ViGEmController {}

impl ViGEmController {
    pub fn connect() -> Result<Self, String> {
        unsafe {
            let dev_info = SetupDiGetClassDevsW(
                Some(&GUID_DEVINTERFACE_BUSENUM_VIGEM),
                None,
                None,
                DIGCF_PRESENT | DIGCF_DEVICEINTERFACE,
            )
            .map_err(|e| format!("SetupDiGetClassDevsW: {e}"))?;

            let mut bus_handle = INVALID_HANDLE_VALUE;
            let mut iface_data = SP_DEVICE_INTERFACE_DATA {
                cbSize: size_of::<SP_DEVICE_INTERFACE_DATA>() as u32,
                ..Default::default()
            };

            let mut idx = 0u32;
            while SetupDiEnumDeviceInterfaces(
                dev_info,
                None,
                &GUID_DEVINTERFACE_BUSENUM_VIGEM,
                idx,
                &mut iface_data,
            )
            .is_ok()
            {
                idx += 1;
                let mut required = 0u32;
                let _ = SetupDiGetDeviceInterfaceDetailW(
                    dev_info,
                    &iface_data,
                    None,
                    0,
                    Some(&mut required),
                    None,
                );
                if required == 0 {
                    continue;
                }
                let mut buf = vec![0u8; required as usize];
                let detail = buf.as_mut_ptr() as *mut SP_DEVICE_INTERFACE_DETAIL_DATA_W;
                (*detail).cbSize = size_of::<SP_DEVICE_INTERFACE_DETAIL_DATA_W>() as u32;

                if SetupDiGetDeviceInterfaceDetailW(
                    dev_info,
                    &iface_data,
                    Some(detail),
                    required,
                    Some(&mut required),
                    None,
                )
                .is_ok()
                {
                    let path_ptr = (*detail).DevicePath.as_ptr();
                    let h = CreateFileW(
                        windows::core::PCWSTR(path_ptr),
                        0x8000_0000 | 0x4000_0000, // GENERIC_READ | GENERIC_WRITE
                        FILE_SHARE_READ | FILE_SHARE_WRITE,
                        None,
                        OPEN_EXISTING,
                        FILE_ATTRIBUTE_NORMAL
                            | FILE_FLAG_NO_BUFFERING
                            | FILE_FLAG_WRITE_THROUGH
                            | FILE_FLAG_OVERLAPPED,
                        None,
                    );
                    if let Ok(handle) = h {
                        if handle != INVALID_HANDLE_VALUE {
                            bus_handle = handle;
                            break;
                        }
                    }
                }
            }
            let _ = SetupDiDestroyDeviceInfoList(dev_info);

            if bus_handle == INVALID_HANDLE_VALUE {
                return Err("ViGEmBus device interface not found".into());
            }

            let event_handle =
                CreateEventW(None, false, false, None).map_err(|e| format!("CreateEventW: {e}"))?;

            let check = VigemCheckVersion {
                size: size_of::<VigemCheckVersion>() as u32,
                version: VIGEM_COMMON_VERSION,
            };
            if let Err(e) = ioctl_sync(bus_handle, event_handle, IOCTL_VIGEM_CHECK_VERSION, &check) {
                let _ = CloseHandle(event_handle);
                let _ = CloseHandle(bus_handle);
                return Err(format!("ViGEm version check failed: {e}"));
            }

            // Plug in Xbox 360 virtual controller on first free serial slot
            for serial in 1..=16u32 {
                let plugin = VigemPluginTarget {
                    size: size_of::<VigemPluginTarget>() as u32,
                    serial_no: serial,
                    target_type: VIGEM_TARGET_XBOX360_WIRED,
                    vendor_id: 0x045E,
                    product_id: 0x028E,
                };
                if ioctl_sync(bus_handle, event_handle, IOCTL_VIGEM_PLUGIN_TARGET, &plugin).is_ok()
                {
                    let wait = VigemWaitDeviceReady {
                        size: size_of::<VigemWaitDeviceReady>() as u32,
                        serial_no: serial,
                    };
                    let _ = ioctl_sync(
                        bus_handle,
                        event_handle,
                        IOCTL_VIGEM_WAIT_DEVICE_READY,
                        &wait,
                    );
                    return Ok(Self {
                        bus_handle,
                        serial_no: serial,
                        event_handle,
                        last_seq: 0,
                    });
                }
            }

            let _ = CloseHandle(event_handle);
            let _ = CloseHandle(bus_handle);
            Err("No free ViGEm target slots".into())
        }
    }

    pub fn reset_seq(&mut self) {
        self.last_seq = 0;
    }

    pub fn submit_report(&mut self, g: &GamepadInput) -> Result<(), String> {
        // Ignore out-of-order older packets (handle wraparound cleanly), while allowing clean resync on seq restart (1..=4)
        if self.last_seq != 0 && g.seq > 4 && g.seq.wrapping_sub(self.last_seq) > 0x7FFF_FFFF {
            return Ok(());
        }
        self.last_seq = g.seq;

        let req = XusbSubmitReport {
            size: size_of::<XusbSubmitReport>() as u32,
            serial_no: self.serial_no,
            report: XusbReport {
                w_buttons: g.buttons,
                b_left_trigger: g.lt,
                b_right_trigger: g.rt,
                s_thumb_lx: g.lx,
                s_thumb_ly: g.ly,
                s_thumb_rx: g.rx,
                s_thumb_ry: g.ry,
            },
        };
        match unsafe {
            ioctl_sync(
                self.bus_handle,
                self.event_handle,
                IOCTL_XUSB_SUBMIT_REPORT,
                &req,
            )
        } {
            Ok(()) => Ok(()),
            // ViGEmBus returns ERROR_NO_MORE_ITEMS (0x80070103) when no XUSB URB is queued yet;
            // official ViGEmClient treats only ERROR_ACCESS_DENIED (0x80070005) as a target error.
            Err(e) if e.contains("0x80070103") || e.contains("259") => Ok(()),
            Err(e) => Err(e),
        }
    }
}

impl Drop for ViGEmController {
    fn drop(&mut self) {
        unsafe {
            let unplug = VigemUnplugTarget {
                size: size_of::<VigemUnplugTarget>() as u32,
                serial_no: self.serial_no,
            };
            let _ = ioctl_sync(
                self.bus_handle,
                self.event_handle,
                IOCTL_VIGEM_UNPLUG_TARGET,
                &unplug,
            );
            let _ = CloseHandle(self.event_handle);
            let _ = CloseHandle(self.bus_handle);
        }
    }
}

unsafe fn ioctl_sync<T>(
    handle: HANDLE,
    event: HANDLE,
    code: u32,
    in_buf: &T,
) -> Result<(), String> {
    let mut overlapped = OVERLAPPED {
        hEvent: event,
        ..Default::default()
    };
    let mut transferred = 0u32;
    let ok = DeviceIoControl(
        handle,
        code,
        Some(in_buf as *const T as *const c_void),
        size_of::<T>() as u32,
        None,
        0,
        Some(&mut transferred),
        Some(&mut overlapped),
    );
    if ok.is_ok() {
        return Ok(());
    }
    GetOverlappedResult(handle, &overlapped, &mut transferred, true)
        .map_err(|e| format!("DeviceIoControl 0x{code:08X} failed: {e}"))
}
