use crate::net::protocol::{KeyboardInput, MouseAbsInput, MouseRelInput};

#[cfg(windows)]
static LAST_MOUSE_BTNS: std::sync::atomic::AtomicU8 = std::sync::atomic::AtomicU8::new(0);

#[cfg(windows)]
fn button_flags(prev: u8, cur: u8) -> windows::Win32::UI::Input::KeyboardAndMouse::MOUSE_EVENT_FLAGS {
    use windows::Win32::UI::Input::KeyboardAndMouse::{
        MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP, MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP,
        MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP, MOUSE_EVENT_FLAGS,
    };

    let mut flags = MOUSE_EVENT_FLAGS(0);
    let changed = prev ^ cur;
    if changed & 0x01 != 0 {
        flags |= if cur & 0x01 != 0 {
            MOUSEEVENTF_LEFTDOWN
        } else {
            MOUSEEVENTF_LEFTUP
        };
    }
    if changed & 0x02 != 0 {
        flags |= if cur & 0x02 != 0 {
            MOUSEEVENTF_RIGHTDOWN
        } else {
            MOUSEEVENTF_RIGHTUP
        };
    }
    if changed & 0x04 != 0 {
        flags |= if cur & 0x04 != 0 {
            MOUSEEVENTF_MIDDLEDOWN
        } else {
            MOUSEEVENTF_MIDDLEUP
        };
    }
    flags
}

#[cfg(windows)]
pub fn send_mouse_rel(m: &MouseRelInput) {
    use std::mem::size_of;
    use windows::Win32::UI::Input::KeyboardAndMouse::{
        SendInput, INPUT, INPUT_0, INPUT_MOUSE, MOUSEEVENTF_HWHEEL, MOUSEEVENTF_MOVE,
        MOUSEEVENTF_WHEEL, MOUSEINPUT,
    };

    let prev = LAST_MOUSE_BTNS.swap(m.buttons, std::sync::atomic::Ordering::Relaxed);
    let mut flags = button_flags(prev, m.buttons);
    if m.dx != 0 || m.dy != 0 {
        flags |= MOUSEEVENTF_MOVE;
    }
    if m.wheel != 0 {
        flags |= MOUSEEVENTF_WHEEL;
    }

    let mut inputs = Vec::with_capacity(2);
    if flags.0 != 0 {
        inputs.push(INPUT {
            r#type: INPUT_MOUSE,
            Anonymous: INPUT_0 {
                mi: MOUSEINPUT {
                    dx: m.dx as i32,
                    dy: m.dy as i32,
                    mouseData: (m.wheel as i32 * 120) as u32,
                    dwFlags: flags,
                    time: 0,
                    dwExtraInfo: 0,
                },
            },
        });
    }
    if m.h_wheel != 0 {
        inputs.push(INPUT {
            r#type: INPUT_MOUSE,
            Anonymous: INPUT_0 {
                mi: MOUSEINPUT {
                    dx: 0,
                    dy: 0,
                    mouseData: (m.h_wheel as i32 * 120) as u32,
                    dwFlags: MOUSEEVENTF_HWHEEL,
                    time: 0,
                    dwExtraInfo: 0,
                },
            },
        });
    }
    if !inputs.is_empty() {
        unsafe {
            SendInput(&inputs, size_of::<INPUT>() as i32);
        }
    }
}

#[cfg(not(windows))]
pub fn send_mouse_rel(_m: &MouseRelInput) {}

#[cfg(windows)]
pub fn send_mouse_abs(m: &MouseAbsInput) {
    use std::mem::size_of;
    use windows::Win32::UI::Input::KeyboardAndMouse::{
        SendInput, INPUT, INPUT_0, INPUT_MOUSE, MOUSEEVENTF_ABSOLUTE, MOUSEEVENTF_HWHEEL,
        MOUSEEVENTF_MOVE, MOUSEEVENTF_VIRTUALDESK, MOUSEEVENTF_WHEEL, MOUSEINPUT,
    };

    let prev = LAST_MOUSE_BTNS.swap(m.buttons, std::sync::atomic::Ordering::Relaxed);
    let mut flags = MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK | MOUSEEVENTF_MOVE;
    flags |= button_flags(prev, m.buttons);
    if m.wheel != 0 {
        flags |= MOUSEEVENTF_WHEEL;
    }

    let mut inputs = Vec::with_capacity(2);
    inputs.push(INPUT {
        r#type: INPUT_MOUSE,
        Anonymous: INPUT_0 {
            mi: MOUSEINPUT {
                dx: m.x_norm as i32,
                dy: m.y_norm as i32,
                mouseData: (m.wheel as i32 * 120) as u32,
                dwFlags: flags,
                time: 0,
                dwExtraInfo: 0,
            },
        },
    });
    if m.h_wheel != 0 {
        inputs.push(INPUT {
            r#type: INPUT_MOUSE,
            Anonymous: INPUT_0 {
                mi: MOUSEINPUT {
                    dx: 0,
                    dy: 0,
                    mouseData: (m.h_wheel as i32 * 120) as u32,
                    dwFlags: MOUSEEVENTF_HWHEEL,
                    time: 0,
                    dwExtraInfo: 0,
                },
            },
        });
    }
    unsafe {
        SendInput(&inputs, size_of::<INPUT>() as i32);
    }
}

#[cfg(not(windows))]
pub fn send_mouse_abs(_m: &MouseAbsInput) {}

#[cfg(windows)]
pub fn send_keyboard(k: &KeyboardInput) {
    use std::mem::size_of;
    use windows::Win32::UI::Input::KeyboardAndMouse::{
        SendInput, INPUT, INPUT_0, INPUT_KEYBOARD, KEYBDINPUT, KEYEVENTF_KEYUP, VIRTUAL_KEY,
    };

    let mut flags = windows::Win32::UI::Input::KeyboardAndMouse::KEYBD_EVENT_FLAGS(0);
    if !k.is_down {
        flags |= KEYEVENTF_KEYUP;
    }
    let input = INPUT {
        r#type: INPUT_KEYBOARD,
        Anonymous: INPUT_0 {
            ki: KEYBDINPUT {
                wVk: VIRTUAL_KEY(k.vk_code),
                wScan: k.scan_code,
                dwFlags: flags,
                time: 0,
                dwExtraInfo: 0,
            },
        },
    };
    unsafe {
        SendInput(&[input], size_of::<INPUT>() as i32);
    }
}

#[cfg(not(windows))]
pub fn send_keyboard(_k: &KeyboardInput) {}
