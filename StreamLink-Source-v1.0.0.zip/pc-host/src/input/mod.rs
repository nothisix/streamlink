pub mod mouse_kbd;
#[cfg(windows)]
pub mod vigem;

use crate::net::protocol::{GamepadInput, KeyboardInput, MouseAbsInput, MouseRelInput};

pub struct InputInjector {
    #[cfg(windows)]
    vigem: Option<vigem::ViGEmController>,
}

impl InputInjector {
    pub fn new() -> Self {
        #[cfg(windows)]
        let vigem = match vigem::ViGEmController::connect() {
            Ok(v) => Some(v),
            Err(e) => {
                eprintln!("[input] ViGEmBus unavailable ({e}); gamepad injection disabled");
                None
            }
        };
        Self {
            #[cfg(windows)]
            vigem,
        }
    }

    pub fn vigem_ready(&self) -> bool {
        #[cfg(windows)]
        {
            self.vigem.is_some()
        }
        #[cfg(not(windows))]
        {
            false
        }
    }

    pub fn inject_gamepad(&mut self, g: &GamepadInput) {
        #[cfg(windows)]
        if let Some(v) = &mut self.vigem {
            let _ = v.submit_report(g);
        }
        #[cfg(not(windows))]
        let _ = g;
    }

    pub fn inject_mouse_rel(&self, m: &MouseRelInput) {
        mouse_kbd::send_mouse_rel(m);
    }

    pub fn inject_mouse_abs(&self, m: &MouseAbsInput) {
        mouse_kbd::send_mouse_abs(m);
    }

    pub fn inject_keyboard(&self, k: &KeyboardInput) {
        mouse_kbd::send_keyboard(k);
    }
}
