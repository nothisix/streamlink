//! Tactile Industrial / Minimalist Monochrome & Warm Cream/Matte Charcoal UI.
//! Zero AI slop: sharp 1px borders, Signal Orange (#FF4D00) strictly for active stream indicators,
//! SpaceGrotesk + JetBrainsMono typography, crisp oscilloscope sparkline, QR pairing card.

use std::sync::atomic::Ordering;
use std::sync::Arc;

use eframe::egui::{
    self, Color32, FontData, FontDefinitions, FontFamily, Pos2, Rect, Rounding, Stroke, Vec2,
};
use qrcode::QrCode;

use crate::net::abr::ResolutionTier;
use crate::net::protocol::VideoCodec;
use crate::net::server::SharedContext;

const CREAM_BG: Color32 = Color32::from_rgb(0xF4, 0xF3, 0xEE);
const CREAM_CARD: Color32 = Color32::from_rgb(0xEA, 0xE8, 0xE1);
const CREAM_BORDER: Color32 = Color32::from_rgb(0xD6, 0xD4, 0xCC);
const OBSIDIAN_BG: Color32 = Color32::from_rgb(0x11, 0x11, 0x11);
const OBSIDIAN_CARD: Color32 = Color32::from_rgb(0x18, 0x18, 0x18);
const OBSIDIAN_BORDER: Color32 = Color32::from_rgb(0x2A, 0x2A, 0x2A);
const SIGNAL_ORANGE: Color32 = Color32::from_rgb(0xFF, 0x4D, 0x00);

pub struct HostApp {
    ctx: Arc<SharedContext>,
    dark_mode: bool,
    pin_edit: String,
    qr_cached_payload: String,
    qr_modules: Vec<bool>,
    qr_width: usize,
}

impl HostApp {
    pub fn new(cc: &eframe::CreationContext<'_>, ctx: Arc<SharedContext>) -> Self {
        install_fonts(&cc.egui_ctx);
        let pin_edit = {
            let s = ctx.settings.lock();
            String::from_utf8_lossy(&s.pin).into_owned()
        };
        let mut app = Self {
            ctx,
            dark_mode: true,
            pin_edit,
            qr_cached_payload: String::new(),
            qr_modules: Vec::new(),
            qr_width: 0,
        };
        app.refresh_qr();
        app
    }

    fn refresh_qr(&mut self) {
        let (ip, port, pin) = {
            let s = self.ctx.settings.lock();
            let t = self.ctx.telemetry.lock();
            (
                t.lan_ip.clone(),
                s.stream_port,
                String::from_utf8_lossy(&s.pin).into_owned(),
            )
        };
        let payload = format!("streamlink://pair?ip={ip}&port={port}&pin={pin}");
        if payload == self.qr_cached_payload {
            return;
        }
        self.qr_cached_payload = payload.clone();
        if let Ok(code) = QrCode::new(payload.as_bytes()) {
            let w = code.width();
            self.qr_width = w;
            self.qr_modules = (0..w * w)
                .map(|idx| code[(idx % w, idx / w)] == qrcode::Color::Dark)
                .collect();
        }
    }
}

fn install_fonts(egui_ctx: &egui::Context) {
    let mut fonts = FontDefinitions::default();
    fonts.font_data.insert(
        "SpaceGrotesk".to_owned(),
        FontData::from_static(include_bytes!("../../assets/SpaceGrotesk.ttf")).into(),
    );
    fonts.font_data.insert(
        "JetBrainsMono".to_owned(),
        FontData::from_static(include_bytes!("../../assets/JetBrainsMono-Regular.ttf")).into(),
    );
    fonts
        .families
        .entry(FontFamily::Proportional)
        .or_default()
        .insert(0, "SpaceGrotesk".to_owned());
    fonts
        .families
        .entry(FontFamily::Monospace)
        .or_default()
        .insert(0, "JetBrainsMono".to_owned());
    egui_ctx.set_fonts(fonts);
}

impl eframe::App for HostApp {
    fn update(&mut self, egui_ctx: &egui::Context, _frame: &mut eframe::Frame) {
        egui_ctx.request_repaint_after(std::time::Duration::from_millis(50));
        self.refresh_qr();

        let (bg, card_bg, border, fg, muted) = if self.dark_mode {
            (
                OBSIDIAN_BG,
                OBSIDIAN_CARD,
                OBSIDIAN_BORDER,
                CREAM_BG,
                Color32::from_rgb(0x88, 0x86, 0x7E),
            )
        } else {
            (
                CREAM_BG,
                CREAM_CARD,
                CREAM_BORDER,
                OBSIDIAN_BG,
                Color32::from_rgb(0x5B, 0x5A, 0x55),
            )
        };

        let mut style = (*egui_ctx.style()).clone();
        style.visuals.window_fill = bg;
        style.visuals.panel_fill = bg;
        style.visuals.extreme_bg_color = card_bg;
        style.visuals.widgets.noninteractive.bg_fill = card_bg;
        style.visuals.widgets.noninteractive.bg_stroke = Stroke::new(1.0_f32, border);
        style.visuals.widgets.inactive.bg_fill = card_bg;
        style.visuals.widgets.inactive.bg_stroke = Stroke::new(1.0_f32, border);
        style.visuals.widgets.inactive.fg_stroke = Stroke::new(1.0_f32, fg);
        style.visuals.widgets.hovered.bg_fill = border;
        style.visuals.widgets.hovered.bg_stroke = Stroke::new(1.0_f32, fg);
        style.visuals.widgets.active.bg_fill = SIGNAL_ORANGE;
        style.visuals.widgets.active.fg_stroke = Stroke::new(1.0_f32, OBSIDIAN_BG);
        for w in [
            &mut style.visuals.widgets.noninteractive,
            &mut style.visuals.widgets.inactive,
            &mut style.visuals.widgets.hovered,
            &mut style.visuals.widgets.active,
        ] {
            w.rounding = Rounding::same(2.0);
        }
        egui_ctx.set_style(style);

        let telem = self.ctx.telemetry.lock().clone();
        let settings = self.ctx.settings.lock().clone();
        let mut new_streaming_enabled = None;
        let mut new_require_pin = None;
        let mut new_codec = None;
        let mut new_res = None;
        let mut new_fps = None;
        let mut new_bitrate = None;

        egui::CentralPanel::default()
            .frame(egui::Frame::none().fill(bg).inner_margin(16.0))
            .show(egui_ctx, |ui| {
                // Header Strip
                ui.horizontal(|ui| {
                    let (dot_rect, _) =
                        ui.allocate_exact_size(Vec2::splat(10.0), egui::Sense::hover());
                    let dot_color = if telem.client_connected && settings.streaming_enabled {
                        SIGNAL_ORANGE
                    } else if settings.streaming_enabled {
                        fg
                    } else {
                        muted
                    };
                    ui.painter().circle_filled(dot_rect.center(), 5.0, dot_color);
                    ui.add_space(4.0);
                    ui.label(
                        egui::RichText::new("STREAMLINK HOST // REV 1.0")
                            .size(16.0)
                            .strong()
                            .color(fg),
                    );
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        let theme_label = if self.dark_mode { "CREAM" } else { "OBSIDIAN" };
                        if ui.button(egui::RichText::new(theme_label).monospace().size(11.0)).clicked() {
                            self.dark_mode = !self.dark_mode;
                        }
                        ui.add_space(6.0);
                        let arm_txt = if settings.streaming_enabled {
                            "HOST ARMED"
                        } else {
                            "HOST PAUSED"
                        };
                        if ui
                            .add(
                                egui::Button::new(
                                    egui::RichText::new(arm_txt)
                                        .monospace()
                                        .size(11.0)
                                        .color(if settings.streaming_enabled {
                                            OBSIDIAN_BG
                                        } else {
                                            fg
                                        }),
                                )
                                .fill(if settings.streaming_enabled {
                                    SIGNAL_ORANGE
                                } else {
                                    card_bg
                                }),
                            )
                            .clicked()
                        {
                            new_streaming_enabled = Some(!settings.streaming_enabled);
                        }
                    });
                });

                ui.add_space(8.0);
                ui.label(
                    egui::RichText::new(format!(
                        "{}  |  VIGEMBUS: {}",
                        telem.status_line,
                        if telem.vigem_ready { "READY" } else { "OFFLINE" }
                    ))
                    .monospace()
                    .size(11.0)
                    .color(muted),
                );
                ui.add_space(12.0);

                // Telemetry Grid
                egui::Frame::none()
                    .fill(card_bg)
                    .stroke(Stroke::new(1.0_f32, border))
                    .inner_margin(12.0)
                    .show(ui, |ui| {
                        ui.columns(5, |cols| {
                            metric_cell(&mut cols[0], "RTT", &format!("{:.1} MS", telem.rtt_ms), fg, muted);
                            metric_cell(&mut cols[1], "FPS", &format!("{}", telem.active_fps), fg, muted);
                            metric_cell(
                                &mut cols[2],
                                "BITRATE",
                                &format!("{:.1} MBPS", telem.bitrate_kbps as f32 / 1000.0),
                                fg,
                                muted,
                            );
                            metric_cell(
                                &mut cols[3],
                                "LOSS / FEC",
                                &format!("{:.1}% / {}%", telem.loss_pct, telem.fec_pct),
                                fg,
                                muted,
                            );
                            metric_cell(
                                &mut cols[4],
                                "PIPELINE",
                                &format!("{} {}", telem.encoder_label, telem.active_codec.label()),
                                fg,
                                muted,
                            );
                        });
                    });

                ui.add_space(12.0);

                // Main Split: Left Pairing & QR, Right Controls & Oscilloscope
                ui.columns(2, |cols| {
                    // Left: Pairing Card
                    egui::Frame::none()
                        .fill(card_bg)
                        .stroke(Stroke::new(1.0_f32, border))
                        .inner_margin(12.0)
                        .show(&mut cols[0], |ui| {
                            ui.set_min_height(240.0);
                            ui.label(
                                egui::RichText::new("PAIRING / ENDPOINT")
                                    .monospace()
                                    .size(11.0)
                                    .color(muted),
                            );
                            ui.add_space(8.0);
                            ui.horizontal(|ui| {
                                // Monochrome QR Matrix
                                let qr_px = 148.0;
                                let (qr_rect, _) = ui.allocate_exact_size(
                                    Vec2::splat(qr_px),
                                    egui::Sense::hover(),
                                );
                                ui.painter().rect_filled(qr_rect, 0.0, CREAM_BG);
                                if self.qr_width > 0 {
                                    let quiet = 2usize;
                                    let total = self.qr_width + quiet * 2;
                                    let cell = qr_px / total as f32;
                                    for y in 0..self.qr_width {
                                        for x in 0..self.qr_width {
                                            if self.qr_modules[y * self.qr_width + x] {
                                                let min = Pos2::new(
                                                    qr_rect.left() + (x + quiet) as f32 * cell,
                                                    qr_rect.top() + (y + quiet) as f32 * cell,
                                                );
                                                let r = Rect::from_min_size(min, Vec2::splat(cell.ceil()));
                                                ui.painter().rect_filled(r, 0.0, OBSIDIAN_BG);
                                            }
                                        }
                                    }
                                }
                                ui.painter().rect_stroke(
                                    qr_rect,
                                    0.0,
                                    Stroke::new(1.0_f32, border),
                                );

                                ui.add_space(12.0);
                                ui.vertical(|ui| {
                                    ui.label(egui::RichText::new("PIN").monospace().size(10.0).color(muted));
                                    let pin_str = String::from_utf8_lossy(&settings.pin).into_owned();
                                    ui.label(
                                        egui::RichText::new(&pin_str)
                                            .monospace()
                                            .size(28.0)
                                            .strong()
                                            .color(fg),
                                    );
                                    ui.horizontal(|ui| {
                                        if ui
                                            .button(egui::RichText::new("NEW PIN").monospace().size(10.0))
                                            .clicked()
                                        {
                                            self.ctx.regenerate_pin();
                                            let p = self.ctx.settings.lock().pin;
                                            self.pin_edit = String::from_utf8_lossy(&p).into_owned();
                                        }
                                        let pin_gate_lbl = if settings.require_pin { "PIN: ON" } else { "PIN: OFF" };
                                        if ui
                                            .button(egui::RichText::new(pin_gate_lbl).monospace().size(10.0))
                                            .clicked()
                                        {
                                            new_require_pin = Some(!settings.require_pin);
                                        }
                                    });
                                    ui.horizontal(|ui| {
                                        ui.label(egui::RichText::new("SET").monospace().size(10.0).color(muted));
                                        let te = egui::TextEdit::singleline(&mut self.pin_edit)
                                            .desired_width(48.0)
                                            .font(egui::TextStyle::Monospace);
                                        if ui.add(te).changed() {
                                            self.pin_edit = self.pin_edit.chars().filter(|c| c.is_ascii_digit()).take(4).collect();
                                            if self.pin_edit.len() == 4 {
                                                self.ctx.set_pin_str(&self.pin_edit);
                                            }
                                        }
                                    });
                                    ui.add_space(8.0);
                                    ui.label(egui::RichText::new("LAN IP:PORT").monospace().size(10.0).color(muted));
                                    ui.label(
                                        egui::RichText::new(format!("{}:{}", telem.lan_ip, settings.stream_port))
                                            .monospace()
                                            .size(12.0)
                                            .color(fg),
                                    );
                                    ui.add_space(6.0);
                                    ui.label(egui::RichText::new("CLIENT").monospace().size(10.0).color(muted));
                                    ui.label(
                                        egui::RichText::new(format!(
                                            "{} ({})",
                                            telem.client_name, telem.client_addr
                                        ))
                                        .monospace()
                                        .size(11.0)
                                        .color(fg),
                                    );
                                });
                            });
                        });

                    // Right: Stream Parameters & Sparkline
                    egui::Frame::none()
                        .fill(card_bg)
                        .stroke(Stroke::new(1.0_f32, border))
                        .inner_margin(12.0)
                        .show(&mut cols[1], |ui| {
                            ui.set_min_height(240.0);
                            ui.label(
                                egui::RichText::new("ENCODER / ADAPTIVE TELEMETRY")
                                    .monospace()
                                    .size(11.0)
                                    .color(muted),
                            );
                            ui.add_space(8.0);

                            ui.horizontal(|ui| {
                                ui.label(egui::RichText::new("CODEC").monospace().size(11.0).color(muted));
                                for c in [VideoCodec::H264, VideoCodec::Hevc] {
                                    let sel = settings.preferred_codec == c;
                                    if ui.selectable_label(sel, egui::RichText::new(c.label()).monospace().size(11.0)).clicked() {
                                        new_codec = Some(c);
                                        self.ctx.restart_pipeline.store(true, Ordering::Relaxed);
                                    }
                                }
                            });

                            ui.horizontal(|ui| {
                                ui.label(egui::RichText::new("CAP RES").monospace().size(11.0).color(muted));
                                for r in [ResolutionTier::P1080, ResolutionTier::P900, ResolutionTier::P720] {
                                    let sel = settings.max_resolution == r;
                                    if ui.selectable_label(sel, egui::RichText::new(r.label()).monospace().size(11.0)).clicked() {
                                        new_res = Some(r);
                                    }
                                }
                            });

                            ui.horizontal(|ui| {
                                ui.label(egui::RichText::new("FPS").monospace().size(11.0).color(muted));
                                for f in [60u16, 90u16, 120u16] {
                                    let sel = settings.target_fps == f;
                                    if ui.selectable_label(sel, egui::RichText::new(format!("{f}")).monospace().size(11.0)).clicked() {
                                        new_fps = Some(f);
                                    }
                                }
                            });

                            ui.horizontal(|ui| {
                                ui.label(egui::RichText::new("MAX MBPS").monospace().size(11.0).color(muted));
                                let mut mbps = settings.max_bitrate_kbps / 1000;
                                if ui.add(egui::Slider::new(&mut mbps, 3..=25)).changed() {
                                    new_bitrate = Some(mbps * 1000);
                                }
                                if ui.button(egui::RichText::new("FORCE IDR").monospace().size(10.0)).clicked() {
                                    self.ctx.force_idr.store(true, Ordering::Relaxed);
                                }
                            });

                            ui.add_space(6.0);
                            // Industrial Oscilloscope RTT / Bitrate plot
                            let (plot_rect, _) = ui.allocate_exact_size(
                                Vec2::new(ui.available_width(), 68.0),
                                egui::Sense::hover(),
                            );
                            ui.painter().rect_filled(plot_rect, 0.0, bg);
                            ui.painter().rect_stroke(
                                plot_rect,
                                0.0,
                                Stroke::new(1.0_f32, border),
                            );
                            // Center baseline grid
                            let mid_y = plot_rect.center().y;
                            ui.painter().line_segment(
                                [
                                    Pos2::new(plot_rect.left(), mid_y),
                                    Pos2::new(plot_rect.right(), mid_y),
                                ],
                                Stroke::new(1.0_f32, border),
                            );
                            if telem.history.len() >= 2 {
                                let count = telem.history.len();
                                let mut rtt_pts = Vec::with_capacity(count);
                                let mut mbps_pts = Vec::with_capacity(count);
                                for (i, &(rtt, mbps)) in telem.history.iter().enumerate() {
                                    let x = plot_rect.left()
                                        + (i as f32 / (count - 1).max(1) as f32) * plot_rect.width();
                                    let r_norm = (rtt / 80.0).clamp(0.0, 1.0);
                                    let m_norm = (mbps / 40.0).clamp(0.0, 1.0);
                                    rtt_pts.push(Pos2::new(x, plot_rect.bottom() - r_norm * plot_rect.height()));
                                    mbps_pts.push(Pos2::new(x, plot_rect.bottom() - m_norm * plot_rect.height()));
                                }
                                ui.painter().add(egui::Shape::line(mbps_pts, Stroke::new(1.5_f32, fg)));
                                ui.painter().add(egui::Shape::line(rtt_pts, Stroke::new(1.5_f32, SIGNAL_ORANGE)));
                            }
                        });
                });
            });

        if new_streaming_enabled.is_some()
            || new_require_pin.is_some()
            || new_codec.is_some()
            || new_res.is_some()
            || new_fps.is_some()
            || new_bitrate.is_some()
        {
            let mut s = self.ctx.settings.lock();
            if let Some(v) = new_streaming_enabled {
                s.streaming_enabled = v;
            }
            if let Some(v) = new_require_pin {
                s.require_pin = v;
            }
            if let Some(v) = new_codec {
                s.preferred_codec = v;
            }
            if let Some(v) = new_res {
                s.max_resolution = v;
            }
            if let Some(v) = new_fps {
                s.target_fps = v;
            }
            if let Some(v) = new_bitrate {
                s.max_bitrate_kbps = v;
            }
        }
    }
}

fn metric_cell(ui: &mut egui::Ui, label: &str, value: &str, fg: Color32, muted: Color32) {
    ui.vertical(|ui| {
        ui.label(egui::RichText::new(label).monospace().size(10.0).color(muted));
        ui.label(
            egui::RichText::new(value)
                .monospace()
                .size(14.0)
                .strong()
                .color(fg),
        );
    });
}
