#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod capture;
mod encode;
mod input;
mod net;
mod ui;

use crate::net::server::{start_host_runtime, SharedContext};
use crate::ui::HostApp;

fn main() -> eframe::Result<()> {
    let ctx = SharedContext::new();
    start_host_runtime(ctx.clone());

    let native_options = eframe::NativeOptions {
        viewport: eframe::egui::ViewportBuilder::default()
            .with_inner_size([760.0, 420.0])
            .with_min_inner_size([680.0, 380.0])
            .with_title("StreamLink Host"),
        ..Default::default()
    };

    eframe::run_native(
        "StreamLink Host",
        native_options,
        Box::new(move |cc| Ok(Box::new(HostApp::new(cc, ctx.clone())))),
    )
}

#[cfg(test)]
mod hw_smoke_tests {
    use crate::capture::dxgi::DxgiCapturer;
    use crate::encode::{EncoderKind, VideoEncoder};
    use crate::input::vigem::ViGEmController;
    use crate::net::protocol::{GamepadInput, VideoCodec};

    extern "C" {
        fn sl_opus_create(sample_rate: i32, channels: i32, bitrate_bps: i32) -> *mut std::ffi::c_void;
        fn sl_opus_encode_float(
            enc: *mut std::ffi::c_void,
            pcm: *const f32,
            frame_size: i32,
            out: *mut u8,
            out_cap: i32,
        ) -> i32;
        fn sl_opus_destroy(enc: *mut std::ffi::c_void);
    }

    #[test]
    fn live_d3d11_nvenc_h264_hevc_and_x264_opus() {
        let mut cap = DxgiCapturer::new().expect("DxgiCapturer::new (D3D11 device)");
        let ptr = cap.nvenc_d3d11_device_ptr();

        // 1. NVENC H.264 on RTX GPU (works on both desktop and Optimus laptops)
        let mut enc_h264 =
            VideoEncoder::create(ptr, 1280, 720, 60, 8000, VideoCodec::H264).expect("H264 encoder");
        assert_eq!(enc_h264.kind(), EncoderKind::Nvenc, "Expected RTX NVENC hardware encoder");
        let _ = cap.capture_to_nvenc_texture(enc_h264.nvenc_input_texture(), 1280, 720, 10);
        let (bytes, is_idr) = enc_h264.encode_nvenc(1000, true).expect("encode_nvenc H264");
        assert!(is_idr);
        assert!(bytes.len() > 32);
        assert_eq!(&bytes[0..4], &[0, 0, 0, 1], "Expected H.264 Annex-B start code");
        enc_h264.set_bitrate(4000);

        // 2. NVENC HEVC on RTX GPU
        let mut enc_hevc =
            VideoEncoder::create(ptr, 1280, 720, 60, 8000, VideoCodec::Hevc).expect("HEVC encoder");
        assert_eq!(enc_hevc.kind(), EncoderKind::Nvenc);
        let (hevc_bytes, is_idr) = enc_hevc.encode_nvenc(2000, true).expect("encode_nvenc HEVC");
        assert!(is_idr);
        assert!(hevc_bytes.len() > 32);

        // 3. Software libx264 fallback path
        let mut enc_sw =
            VideoEncoder::create(std::ptr::null_mut(), 640, 360, 60, 4000, VideoCodec::H264)
                .expect("x264 fallback");
        assert_eq!(enc_sw.kind(), EncoderKind::X264);
        let bgra = vec![128u8; 640 * 360 * 4];
        let (sw_bytes, sw_idr) = enc_sw.encode_bgra(&bgra, 640 * 4, true).expect("encode_bgra");
        assert!(sw_idr);
        assert!(sw_bytes.len() > 16);

        // 4. Opus 48kHz stereo 10ms encode
        unsafe {
            let opus = sl_opus_create(48000, 2, 128_000);
            assert!(!opus.is_null());
            let pcm = vec![0.05f32; 480 * 2];
            let mut out = vec![0u8; 512];
            let n = sl_opus_encode_float(opus, pcm.as_ptr(), 480, out.as_mut_ptr(), out.len() as i32);
            assert!(n > 2);
            sl_opus_destroy(opus);
        }
    }

    #[test]
    fn live_vigem_xbox360_controller() {
        let mut ctrl = ViGEmController::connect().expect("ViGEmBus connect");
        ctrl.submit_report(&GamepadInput {
            buttons: 0x1000, // A button
            lt: 128,
            rt: 255,
            lx: 12000,
            ly: -12000,
            rx: 0,
            ry: 0,
            seq: 1,
        })
        .expect("submit_report");
    }
}
