//! Video encoding pipeline:
//! Priority: NVIDIA NVENC (zero-copy DirectX11) -> libx264 (ultrafast/zerolatency).

use std::ffi::{c_char, c_int, c_void, CStr};

use crate::net::protocol::VideoCodec;

#[cfg(windows)]
extern "C" {
    fn nvenc_create(
        d3d11_device_ptr: *mut c_void,
        width: u32,
        height: u32,
        fps: u32,
        bitrate_kbps: u32,
        is_hevc: c_int,
        err_buf: *mut c_char,
        err_cap: c_int,
    ) -> *mut c_void;
    fn nvenc_input_texture(ctx: *mut c_void) -> *mut c_void;
    fn nvenc_reconfigure_bitrate(ctx: *mut c_void, bitrate_kbps: u32) -> c_int;
    fn nvenc_encode_frame(
        ctx: *mut c_void,
        pts_us: u64,
        force_idr: c_int,
        out_buf: *mut u8,
        out_cap: u32,
        out_len: *mut u32,
        out_is_idr: *mut c_int,
    ) -> c_int;
    fn nvenc_destroy(ctx: *mut c_void);
}

extern "C" {
    fn sl_x264_create(width: u32, height: u32, fps: u32, bitrate_kbps: u32) -> *mut c_void;
    fn sl_x264_reconfigure_bitrate(ctx: *mut c_void, bitrate_kbps: u32) -> c_int;
    fn sl_x264_encode_bgra(
        ctx: *mut c_void,
        bgra: *const u8,
        stride: u32,
        force_idr: c_int,
        out_buf: *mut u8,
        out_cap: u32,
        out_len: *mut u32,
        out_is_idr: *mut c_int,
    ) -> c_int;
    fn sl_x264_destroy(ctx: *mut c_void);
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EncoderKind {
    Nvenc,
    X264,
}

impl EncoderKind {
    pub fn label(self) -> &'static str {
        match self {
            Self::Nvenc => "NVENC HW",
            Self::X264 => "x264 SW",
        }
    }
}

pub struct VideoEncoder {
    kind: EncoderKind,
    codec: VideoCodec,
    #[allow(dead_code)]
    width: u32,
    #[allow(dead_code)]
    height: u32,
    #[allow(dead_code)]
    fps: u32,
    bitrate_kbps: u32,
    nvenc_ctx: *mut c_void,
    x264_ctx: *mut c_void,
    bitstream_buf: Vec<u8>,
}

unsafe impl Send for VideoEncoder {}

impl VideoEncoder {
    pub fn create(
        d3d11_device_ptr: *mut c_void,
        width: u32,
        height: u32,
        fps: u32,
        bitrate_kbps: u32,
        preferred_codec: VideoCodec,
    ) -> Result<Self, String> {
        #[cfg(windows)]
        if !d3d11_device_ptr.is_null() {
            let mut err = [0i8; 256];
            let ctx = unsafe {
                nvenc_create(
                    d3d11_device_ptr,
                    width,
                    height,
                    fps,
                    bitrate_kbps,
                    if preferred_codec == VideoCodec::Hevc { 1 } else { 0 },
                    err.as_mut_ptr(),
                    err.len() as c_int,
                )
            };
            if !ctx.is_null() {
                return Ok(Self {
                    kind: EncoderKind::Nvenc,
                    codec: preferred_codec,
                    width,
                    height,
                    fps,
                    bitrate_kbps,
                    nvenc_ctx: ctx,
                    x264_ctx: std::ptr::null_mut(),
                    bitstream_buf: vec![0u8; 4 * 1024 * 1024],
                });
            }
            let msg = unsafe { CStr::from_ptr(err.as_ptr()) }.to_string_lossy();
            eprintln!("[encode] NVENC init skipped ({msg}), falling back to libx264");
        }

        // Software libx264 ultrafast zerolatency fallback (H.264 High Profile)
        let x264 = unsafe { sl_x264_create(width, height, fps, bitrate_kbps) };
        if x264.is_null() {
            return Err("Failed to initialize both NVENC and libx264".into());
        }

        Ok(Self {
            kind: EncoderKind::X264,
            codec: VideoCodec::H264,
            width,
            height,
            fps,
            bitrate_kbps,
            nvenc_ctx: std::ptr::null_mut(),
            x264_ctx: x264,
            bitstream_buf: vec![0u8; 4 * 1024 * 1024],
        })
    }

    pub fn kind(&self) -> EncoderKind {
        self.kind
    }

    pub fn codec(&self) -> VideoCodec {
        self.codec
    }

    #[allow(dead_code)]
    pub fn width(&self) -> u32 {
        self.width
    }

    #[allow(dead_code)]
    pub fn height(&self) -> u32 {
        self.height
    }

    #[cfg(windows)]
    pub fn nvenc_input_texture(&self) -> *mut c_void {
        if self.kind == EncoderKind::Nvenc && !self.nvenc_ctx.is_null() {
            unsafe { nvenc_input_texture(self.nvenc_ctx) }
        } else {
            std::ptr::null_mut()
        }
    }

    pub fn set_bitrate(&mut self, bitrate_kbps: u32) {
        if bitrate_kbps == self.bitrate_kbps {
            return;
        }
        self.bitrate_kbps = bitrate_kbps;
        unsafe {
            match self.kind {
                EncoderKind::Nvenc => {
                    let _ = nvenc_reconfigure_bitrate(self.nvenc_ctx, bitrate_kbps);
                }
                EncoderKind::X264 => {
                    let _ = sl_x264_reconfigure_bitrate(self.x264_ctx, bitrate_kbps);
                }
            }
        }
    }

    #[cfg(windows)]
    pub fn encode_nvenc(&mut self, pts_us: u64, force_idr: bool) -> Result<(&[u8], bool), String> {
        let mut out_len = 0u32;
        let mut is_idr = 0i32;
        let rc = unsafe {
            nvenc_encode_frame(
                self.nvenc_ctx,
                pts_us,
                if force_idr { 1 } else { 0 },
                self.bitstream_buf.as_mut_ptr(),
                self.bitstream_buf.len() as u32,
                &mut out_len,
                &mut is_idr,
            )
        };
        if rc != 0 {
            return Err(format!("nvenc_encode_frame error {rc}"));
        }
        Ok((&self.bitstream_buf[..out_len as usize], is_idr != 0))
    }

    pub fn encode_bgra(
        &mut self,
        bgra: &[u8],
        stride: u32,
        force_idr: bool,
    ) -> Result<(&[u8], bool), String> {
        let mut out_len = 0u32;
        let mut is_idr = 0i32;
        let rc = unsafe {
            sl_x264_encode_bgra(
                self.x264_ctx,
                bgra.as_ptr(),
                stride,
                if force_idr { 1 } else { 0 },
                self.bitstream_buf.as_mut_ptr(),
                self.bitstream_buf.len() as u32,
                &mut out_len,
                &mut is_idr,
            )
        };
        if rc != 0 {
            return Err(format!("sl_x264_encode_bgra error {rc}"));
        }
        Ok((&self.bitstream_buf[..out_len as usize], is_idr != 0))
    }
}

impl Drop for VideoEncoder {
    fn drop(&mut self) {
        unsafe {
            #[cfg(windows)]
            if !self.nvenc_ctx.is_null() {
                nvenc_destroy(self.nvenc_ctx);
            }
            if !self.x264_ctx.is_null() {
                sl_x264_destroy(self.x264_ctx);
            }
        }
    }
}
