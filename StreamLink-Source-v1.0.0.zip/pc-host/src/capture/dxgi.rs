//! Zero-copy Windows Desktop Duplication API (`IDXGIOutputDuplication`) capture
//! with Optimus Hybrid-GPU support (separate iGPU capture + NVIDIA dGPU NVENC)
//! and GPU-side scaling via D3D11 `ID3D11VideoProcessor`.

use std::ffi::c_void;
use std::ptr::null_mut;

use windows::core::Interface;
use windows::Win32::Foundation::{HMODULE, HWND, RECT};
use windows::Win32::Graphics::Direct3D::{
    D3D_DRIVER_TYPE_HARDWARE, D3D_DRIVER_TYPE_UNKNOWN, D3D_FEATURE_LEVEL_11_0,
    D3D_FEATURE_LEVEL_11_1,
};
use windows::Win32::Graphics::Direct3D11::{
    D3D11CreateDevice, ID3D11Device, ID3D11DeviceContext, ID3D11Texture2D,
    ID3D11VideoContext, ID3D11VideoDevice, ID3D11VideoProcessor, ID3D11VideoProcessorEnumerator,
    ID3D11VideoProcessorInputView, ID3D11VideoProcessorOutputView, D3D11_CPU_ACCESS_READ,
    D3D11_CREATE_DEVICE_BGRA_SUPPORT, D3D11_CREATE_DEVICE_VIDEO_SUPPORT, D3D11_MAP_READ,
    D3D11_MAPPED_SUBRESOURCE, D3D11_SDK_VERSION, D3D11_TEXTURE2D_DESC, D3D11_USAGE_STAGING,
    D3D11_VIDEO_FRAME_FORMAT_PROGRESSIVE, D3D11_VIDEO_PROCESSOR_CONTENT_DESC,
    D3D11_VIDEO_PROCESSOR_INPUT_VIEW_DESC, D3D11_VIDEO_PROCESSOR_INPUT_VIEW_DESC_0,
    D3D11_VIDEO_PROCESSOR_OUTPUT_VIEW_DESC, D3D11_VIDEO_PROCESSOR_OUTPUT_VIEW_DESC_0,
    D3D11_VIDEO_PROCESSOR_STREAM, D3D11_VIDEO_USAGE_PLAYBACK_NORMAL, D3D11_VPIV_DIMENSION_TEXTURE2D,
    D3D11_VPOV_DIMENSION_TEXTURE2D,
};
use windows::Win32::Graphics::Dxgi::Common::{
    DXGI_FORMAT_B8G8R8A8_UNORM, DXGI_RATIONAL, DXGI_SAMPLE_DESC,
};
use windows::Win32::Graphics::Dxgi::{
    CreateDXGIFactory1, IDXGIDevice, IDXGIFactory1, IDXGIOutput1, IDXGIOutputDuplication,
    DXGI_ERROR_ACCESS_LOST, DXGI_ERROR_WAIT_TIMEOUT, DXGI_OUTDUPL_FRAME_INFO,
};
use windows::Win32::Graphics::Gdi::{
    BitBlt, CreateCompatibleBitmap, CreateCompatibleDC, DeleteDC, DeleteObject, GetDC, GetDIBits,
    ReleaseDC, SelectObject, BITMAPINFO, BITMAPINFOHEADER, BI_RGB, DIB_RGB_COLORS, SRCCOPY,
};

pub struct DxgiCapturer {
    pub device: ID3D11Device,
    pub context: ID3D11DeviceContext,
    pub nvenc_device: ID3D11Device,
    pub nvenc_context: ID3D11DeviceContext,
    pub same_gpu_for_nvenc: bool,

    duplication: Option<IDXGIOutputDuplication>,
    pub desktop_width: u32,
    pub desktop_height: u32,

    video_device: Option<ID3D11VideoDevice>,
    video_context: Option<ID3D11VideoContext>,
    vp_enum: Option<ID3D11VideoProcessorEnumerator>,
    vp: Option<ID3D11VideoProcessor>,
    vp_src_w: u32,
    vp_src_h: u32,
    vp_dst_w: u32,
    vp_dst_h: u32,

    rt_tex: Option<ID3D11Texture2D>,
    staging_tex: Option<ID3D11Texture2D>,
    staging_w: u32,
    staging_h: u32,
    last_good_bgra: Vec<u8>,
    last_good_stride: u32,
    last_tex: Option<ID3D11Texture2D>,
    last_tex_is_bgra8: bool,
}

impl DxgiCapturer {
    pub fn new() -> Result<Self, String> {
        unsafe {
            let feature_levels = [D3D_FEATURE_LEVEL_11_1, D3D_FEATURE_LEVEL_11_0];
            let flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT | D3D11_CREATE_DEVICE_VIDEO_SUPPORT;

            // Default hardware adapter (owns primary desktop output on both desktop & Optimus laptops)
            let mut device: Option<ID3D11Device> = None;
            let mut context: Option<ID3D11DeviceContext> = None;
            D3D11CreateDevice(
                None,
                D3D_DRIVER_TYPE_HARDWARE,
                HMODULE(null_mut()),
                flags,
                Some(&feature_levels),
                D3D11_SDK_VERSION,
                Some(&mut device),
                None,
                Some(&mut context),
            )
            .map_err(|e| format!("D3D11CreateDevice failed: {e}"))?;

            let device = device.ok_or("No D3D11 device")?;
            let context = context.ok_or("No D3D11 context")?;

            // Locate NVIDIA dGPU adapter (VendorId 0x10DE) for NVENC even on Optimus hybrid laptops
            let (nvenc_device, nvenc_context, same_gpu_for_nvenc) =
                find_nvidia_d3d11_device(&device, &context);

            let video_device: Option<ID3D11VideoDevice> = device.cast().ok();
            let video_context: Option<ID3D11VideoContext> = context.cast().ok();

            let mut cap = Self {
                device,
                context,
                nvenc_device,
                nvenc_context,
                same_gpu_for_nvenc,
                duplication: None,
                desktop_width: 1920,
                desktop_height: 1080,
                video_device,
                video_context,
                vp_enum: None,
                vp: None,
                vp_src_w: 0,
                vp_src_h: 0,
                vp_dst_w: 0,
                vp_dst_h: 0,
                rt_tex: None,
                staging_tex: None,
                staging_w: 0,
                staging_h: 0,
                last_good_bgra: Vec::new(),
                last_good_stride: 0,
                last_tex: None,
                last_tex_is_bgra8: true,
            };
            if let Err(e) = cap.init_duplication() {
                eprintln!("[capture] Initial DXGI DuplicateOutput deferred ({e}); GDI fallback active");
            }
            Ok(cap)
        }
    }

    /// Returns the D3D11 device pointer to pass to NVENC (NVIDIA GPU on Optimus or primary GPU).
    pub fn nvenc_d3d11_device_ptr(&self) -> *mut c_void {
        self.nvenc_device.as_raw()
    }

    fn init_duplication(&mut self) -> Result<(), String> {
        unsafe {
            self.duplication = None;
            let dxgi_dev: IDXGIDevice = self
                .device
                .cast()
                .map_err(|e| format!("cast IDXGIDevice: {e}"))?;
            let adapter = dxgi_dev
                .GetAdapter()
                .map_err(|e| format!("GetAdapter: {e}"))?;
            let output = adapter
                .EnumOutputs(0)
                .map_err(|e| format!("EnumOutputs(0): {e}"))?;
            let output1: IDXGIOutput1 = output
                .cast()
                .map_err(|e| format!("cast IDXGIOutput1: {e}"))?;
            let desc = output
                .GetDesc()
                .map_err(|e| format!("Output GetDesc: {e}"))?;
            self.desktop_width = (desc.DesktopCoordinates.right - desc.DesktopCoordinates.left) as u32;
            self.desktop_height = (desc.DesktopCoordinates.bottom - desc.DesktopCoordinates.top) as u32;

            let dup = output1
                .DuplicateOutput(&self.device)
                .map_err(|e| format!("DuplicateOutput: {e}"))?;
            self.duplication = Some(dup);
            Ok(())
        }
    }

    fn ensure_video_processor(&mut self, dst_w: u32, dst_h: u32) -> bool {
        if self.vp.is_some()
            && self.vp_src_w == self.desktop_width
            && self.vp_src_h == self.desktop_height
            && self.vp_dst_w == dst_w
            && self.vp_dst_h == dst_h
        {
            return true;
        }
        let (Some(vdev), Some(_vctx)) = (&self.video_device, &self.video_context) else {
            return false;
        };
        unsafe {
            let content_desc = D3D11_VIDEO_PROCESSOR_CONTENT_DESC {
                InputFrameFormat: D3D11_VIDEO_FRAME_FORMAT_PROGRESSIVE,
                InputFrameRate: DXGI_RATIONAL {
                    Numerator: 60,
                    Denominator: 1,
                },
                InputWidth: self.desktop_width,
                InputHeight: self.desktop_height,
                OutputFrameRate: DXGI_RATIONAL {
                    Numerator: 60,
                    Denominator: 1,
                },
                OutputWidth: dst_w,
                OutputHeight: dst_h,
                Usage: D3D11_VIDEO_USAGE_PLAYBACK_NORMAL,
            };
            let Ok(vp_enum) = vdev.CreateVideoProcessorEnumerator(&content_desc) else {
                return false;
            };
            let Ok(vp) = vdev.CreateVideoProcessor(&vp_enum, 0) else {
                return false;
            };
            self.vp_enum = Some(vp_enum);
            self.vp = Some(vp);
            self.vp_src_w = self.desktop_width;
            self.vp_src_h = self.desktop_height;
            self.vp_dst_w = dst_w;
            self.vp_dst_h = dst_h;
            true
        }
    }

    /// Captures a frame into NVENC's registered D3D11 texture.
    /// Zero-copy on single-GPU systems; GPU-scaled cross-adapter upload on Optimus laptops;
    /// falls back cleanly to GDI BitBlt if DXGI Desktop Duplication is denied.
    pub fn capture_to_nvenc_texture(
        &mut self,
        nvenc_tex_raw: *mut c_void,
        dst_w: u32,
        dst_h: u32,
        timeout_ms: u32,
    ) -> Result<bool, String> {
        if nvenc_tex_raw.is_null() {
            return Err("nvenc_tex_raw is null".into());
        }
        unsafe {
            let dst_tex: ID3D11Texture2D = ID3D11Texture2D::from_raw_borrowed(&nvenc_tex_raw)
                .ok_or("Invalid nvenc_tex_raw")?
                .clone();

            if self.same_gpu_for_nvenc {
                if self.capture_on_primary_gpu(&dst_tex, dst_w, dst_h, timeout_ms)? {
                    return Ok(true);
                }
            } else {
                let nv_ctx = self.nvenc_context.clone();
                if let Some((bgra, stride)) = self.capture_bgra_cpu(dst_w, dst_h, timeout_ms)? {
                    nv_ctx.UpdateSubresource(
                        &dst_tex,
                        0,
                        None,
                        bgra.as_ptr() as *const c_void,
                        stride,
                        0,
                    );
                    return Ok(true);
                }
            }

            // GDI BitBlt fallback if Desktop Duplication is inaccessible (e.g. UAC / restricted session)
            if self.capture_gdi_bgra(dst_w, dst_h) {
                self.nvenc_context.UpdateSubresource(
                    &dst_tex,
                    0,
                    None,
                    self.last_good_bgra.as_ptr() as *const c_void,
                    self.last_good_stride,
                    0,
                );
                return Ok(true);
            }
            Ok(false)
        }
    }

    unsafe fn capture_on_primary_gpu(
        &mut self,
        dst_tex: &ID3D11Texture2D,
        dst_w: u32,
        dst_h: u32,
        timeout_ms: u32,
    ) -> Result<bool, String> {
        if self.duplication.is_none() && self.init_duplication().is_err() {
            return Ok(false);
        }

        let dup = self.duplication.as_ref().unwrap().clone();
        let mut frame_info = DXGI_OUTDUPL_FRAME_INFO::default();
        let mut resource = None;
        match dup.AcquireNextFrame(timeout_ms, &mut frame_info, &mut resource) {
            Ok(()) => {
                if let Some(r) = resource {
                    if let Ok(tex) = r.cast::<ID3D11Texture2D>() {
                        if self.last_tex.is_none() {
                            let mut desc = D3D11_TEXTURE2D_DESC::default();
                            tex.GetDesc(&mut desc);
                            self.last_tex_is_bgra8 = desc.Format == DXGI_FORMAT_B8G8R8A8_UNORM;
                            desc.BindFlags = windows::Win32::Graphics::Direct3D11::D3D11_BIND_RENDER_TARGET.0 as u32
                                | windows::Win32::Graphics::Direct3D11::D3D11_BIND_SHADER_RESOURCE.0 as u32;
                            desc.MiscFlags = 0;
                            let mut clone_tex = None;
                            if self.device.CreateTexture2D(&desc, None, Some(&mut clone_tex)).is_ok() {
                                self.last_tex = clone_tex;
                            }
                        }
                        if let Some(lt) = &self.last_tex {
                            self.context.CopyResource(lt, &tex);
                        }
                    }
                }
                let _ = dup.ReleaseFrame();
            }
            Err(e) if e.code() == DXGI_ERROR_WAIT_TIMEOUT => {}
            Err(e) if e.code() == DXGI_ERROR_ACCESS_LOST => {
                self.last_tex = None;
                self.duplication = None;
                let _ = self.init_duplication();
                return Ok(false);
            }
            Err(e) => return Err(format!("AcquireNextFrame: {e}")),
        }

        let Some(src_tex) = self.last_tex.clone() else {
            return Ok(false);
        };

        if dst_w == self.desktop_width && dst_h == self.desktop_height && self.last_tex_is_bgra8 {
            self.context.CopyResource(dst_tex, &src_tex);
            return Ok(true);
        }

        if self.ensure_video_processor(dst_w, dst_h) {
            let vdev = self.video_device.as_ref().unwrap();
            let vctx = self.video_context.as_ref().unwrap();
            let vp_enum = self.vp_enum.as_ref().unwrap();
            let vp = self.vp.as_ref().unwrap();

            let in_desc = D3D11_VIDEO_PROCESSOR_INPUT_VIEW_DESC {
                FourCC: 0,
                ViewDimension: D3D11_VPIV_DIMENSION_TEXTURE2D,
                Anonymous: D3D11_VIDEO_PROCESSOR_INPUT_VIEW_DESC_0 {
                    Texture2D: windows::Win32::Graphics::Direct3D11::D3D11_TEX2D_VPIV {
                        MipSlice: 0,
                        ArraySlice: 0,
                    },
                },
            };
            let mut in_view: Option<ID3D11VideoProcessorInputView> = None;
            vdev.CreateVideoProcessorInputView(&src_tex, vp_enum, &in_desc, Some(&mut in_view))
                .map_err(|e| format!("CreateVideoProcessorInputView: {e}"))?;

            let out_desc = D3D11_VIDEO_PROCESSOR_OUTPUT_VIEW_DESC {
                ViewDimension: D3D11_VPOV_DIMENSION_TEXTURE2D,
                Anonymous: D3D11_VIDEO_PROCESSOR_OUTPUT_VIEW_DESC_0 {
                    Texture2D: windows::Win32::Graphics::Direct3D11::D3D11_TEX2D_VPOV {
                        MipSlice: 0,
                    },
                },
            };
            let mut out_view: Option<ID3D11VideoProcessorOutputView> = None;
            vdev.CreateVideoProcessorOutputView(dst_tex, vp_enum, &out_desc, Some(&mut out_view))
                .map_err(|e| format!("CreateVideoProcessorOutputView: {e}"))?;

            let src_rect = RECT {
                left: 0,
                top: 0,
                right: self.desktop_width as i32,
                bottom: self.desktop_height as i32,
            };
            let dst_rect = RECT {
                left: 0,
                top: 0,
                right: dst_w as i32,
                bottom: dst_h as i32,
            };
            vctx.VideoProcessorSetStreamSourceRect(vp, 0, true, Some(&src_rect));
            vctx.VideoProcessorSetStreamDestRect(vp, 0, true, Some(&dst_rect));
            vctx.VideoProcessorSetOutputTargetRect(vp, true, Some(&dst_rect));

            let stream = D3D11_VIDEO_PROCESSOR_STREAM {
                Enable: true.into(),
                OutputIndex: 0,
                InputFrameOrField: 0,
                PastFrames: 0,
                FutureFrames: 0,
                ppPastSurfaces: null_mut(),
                pInputSurface: std::mem::ManuallyDrop::new(in_view),
                ppFutureSurfaces: null_mut(),
                ppPastSurfacesRight: null_mut(),
                pInputSurfaceRight: std::mem::ManuallyDrop::new(None),
                ppFutureSurfacesRight: null_mut(),
            };
            let res = vctx.VideoProcessorBlt(vp, out_view.as_ref().unwrap(), 0, std::slice::from_ref(&stream));
            let _ = std::mem::ManuallyDrop::into_inner(stream.pInputSurface);
            res.map_err(|e| format!("VideoProcessorBlt: {e}"))?;
            return Ok(true);
        }

        Ok(false)
    }

    pub fn capture_bgra_cpu(
        &mut self,
        dst_w: u32,
        dst_h: u32,
        timeout_ms: u32,
    ) -> Result<Option<(&[u8], u32)>, String> {
        unsafe {
            if self.staging_tex.is_none() || self.staging_w != dst_w || self.staging_h != dst_h {
                let desc = D3D11_TEXTURE2D_DESC {
                    Width: dst_w,
                    Height: dst_h,
                    MipLevels: 1,
                    ArraySize: 1,
                    Format: DXGI_FORMAT_B8G8R8A8_UNORM,
                    SampleDesc: DXGI_SAMPLE_DESC { Count: 1, Quality: 0 },
                    Usage: D3D11_USAGE_STAGING,
                    BindFlags: 0,
                    CPUAccessFlags: D3D11_CPU_ACCESS_READ.0 as u32,
                    MiscFlags: 0,
                };
                let mut stg = None;
                self.device
                    .CreateTexture2D(&desc, None, Some(&mut stg))
                    .map_err(|e| format!("Create staging tex: {e}"))?;
                self.staging_tex = stg;

                let rt_desc = D3D11_TEXTURE2D_DESC {
                    Width: dst_w,
                    Height: dst_h,
                    MipLevels: 1,
                    ArraySize: 1,
                    Format: DXGI_FORMAT_B8G8R8A8_UNORM,
                    SampleDesc: DXGI_SAMPLE_DESC { Count: 1, Quality: 0 },
                    Usage: windows::Win32::Graphics::Direct3D11::D3D11_USAGE_DEFAULT,
                    BindFlags: windows::Win32::Graphics::Direct3D11::D3D11_BIND_RENDER_TARGET.0 as u32,
                    CPUAccessFlags: 0,
                    MiscFlags: 0,
                };
                let mut rt = None;
                self.device
                    .CreateTexture2D(&rt_desc, None, Some(&mut rt))
                    .map_err(|e| format!("Create rt tex: {e}"))?;
                self.rt_tex = rt;

                self.staging_w = dst_w;
                self.staging_h = dst_h;
            }

            let rt_tex = self.rt_tex.as_ref().unwrap().clone();
            if self.capture_on_primary_gpu(&rt_tex, dst_w, dst_h, timeout_ms)? {
                let stg = self.staging_tex.as_ref().unwrap();
                self.context.CopyResource(stg, &rt_tex);

                let mut mapped = D3D11_MAPPED_SUBRESOURCE::default();
                self.context
                    .Map(stg, 0, D3D11_MAP_READ, 0, Some(&mut mapped))
                    .map_err(|e| format!("Map staging: {e}"))?;

                let row_pitch = mapped.RowPitch;
                let total_bytes = (row_pitch * dst_h) as usize;
                self.last_good_bgra.resize(total_bytes, 0);
                std::ptr::copy_nonoverlapping(
                    mapped.pData as *const u8,
                    self.last_good_bgra.as_mut_ptr(),
                    total_bytes,
                );
                self.last_good_stride = row_pitch;
                self.context.Unmap(stg, 0);
                return Ok(Some((&self.last_good_bgra, self.last_good_stride)));
            }

            if self.capture_gdi_bgra(dst_w, dst_h) {
                return Ok(Some((&self.last_good_bgra, self.last_good_stride)));
            }
            Ok(None)
        }
    }

    unsafe fn capture_gdi_bgra(&mut self, dst_w: u32, dst_h: u32) -> bool {
        let hdc_screen = GetDC(HWND(null_mut()));
        if hdc_screen.is_invalid() {
            return false;
        }
        let hdc_mem = CreateCompatibleDC(hdc_screen);
        let hbm = CreateCompatibleBitmap(hdc_screen, dst_w as i32, dst_h as i32);
        let old = SelectObject(hdc_mem, hbm);
        let ok = BitBlt(hdc_mem, 0, 0, dst_w as i32, dst_h as i32, hdc_screen, 0, 0, SRCCOPY).is_ok();
        let stride = dst_w * 4;
        self.last_good_bgra.resize((stride * dst_h) as usize, 0);
        self.last_good_stride = stride;

        if ok {
            let mut bmi = BITMAPINFO::default();
            bmi.bmiHeader = BITMAPINFOHEADER {
                biSize: std::mem::size_of::<BITMAPINFOHEADER>() as u32,
                biWidth: dst_w as i32,
                biHeight: -(dst_h as i32), // top-down BGRA
                biPlanes: 1,
                biBitCount: 32,
                biCompression: BI_RGB.0,
                ..Default::default()
            };
            GetDIBits(
                hdc_mem,
                hbm,
                0,
                dst_h,
                Some(self.last_good_bgra.as_mut_ptr() as *mut c_void),
                &mut bmi,
                DIB_RGB_COLORS,
            );
        }

        SelectObject(hdc_mem, old);
        let _ = DeleteObject(hbm);
        let _ = DeleteDC(hdc_mem);
        ReleaseDC(HWND(null_mut()), hdc_screen);
        ok
    }
}

unsafe fn find_nvidia_d3d11_device(
    primary_dev: &ID3D11Device,
    primary_ctx: &ID3D11DeviceContext,
) -> (ID3D11Device, ID3D11DeviceContext, bool) {
    let primary_luid = primary_dev
        .cast::<IDXGIDevice>()
        .ok()
        .and_then(|d| d.GetAdapter().ok())
        .and_then(|a| a.GetDesc().ok())
        .map(|desc| (desc.AdapterLuid.LowPart, desc.AdapterLuid.HighPart));

    if let Ok(factory) = CreateDXGIFactory1::<IDXGIFactory1>() {
        let mut idx = 0u32;
        while let Ok(adapter) = factory.EnumAdapters1(idx) {
            idx += 1;
            if let Ok(desc) = adapter.GetDesc1() {
                if desc.VendorId == 0x10DE {
                    let nv_luid = (desc.AdapterLuid.LowPart, desc.AdapterLuid.HighPart);
                    if Some(nv_luid) == primary_luid {
                        return (primary_dev.clone(), primary_ctx.clone(), true);
                    }
                    let feature_levels = [D3D_FEATURE_LEVEL_11_1, D3D_FEATURE_LEVEL_11_0];
                    let flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT | D3D11_CREATE_DEVICE_VIDEO_SUPPORT;
                    let mut nv_dev: Option<ID3D11Device> = None;
                    let mut nv_ctx: Option<ID3D11DeviceContext> = None;
                    let adapter_base: windows::Win32::Graphics::Dxgi::IDXGIAdapter =
                        adapter.cast().unwrap();
                    if D3D11CreateDevice(
                        &adapter_base,
                        D3D_DRIVER_TYPE_UNKNOWN,
                        HMODULE(null_mut()),
                        flags,
                        Some(&feature_levels),
                        D3D11_SDK_VERSION,
                        Some(&mut nv_dev),
                        None,
                        Some(&mut nv_ctx),
                    )
                    .is_ok()
                    {
                        if let (Some(d), Some(c)) = (nv_dev, nv_ctx) {
                            return (d, c, false);
                        }
                    }
                }
            }
        }
    }
    (primary_dev.clone(), primary_ctx.clone(), true)
}
