//! Linux PipeWire / X11 SHM capture stub for cross-platform compilation.

pub struct LinuxCapturer;

impl LinuxCapturer {
    pub fn new() -> Result<Self, String> {
        Err("Linux PipeWire/X11 capture requires running on Linux".into())
    }
}
