pub mod audio;
#[cfg(windows)]
pub mod dxgi;
#[cfg(not(windows))]
pub mod linux_capture;

#[allow(dead_code)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CaptureStatus {
    Ready,
    Reacquiring,
    Error,
}
