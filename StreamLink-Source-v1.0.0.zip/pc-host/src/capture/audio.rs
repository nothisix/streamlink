//! System audio capture (WASAPI Loopback on Windows, PipeWire/Pulse stub on Linux)
//! encoded to Opus (48kHz stereo, 10ms ultra-low frame size).

use std::ffi::c_void;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use tokio::sync::mpsc;

extern "C" {
    fn sl_opus_create(sample_rate: i32, channels: i32, bitrate_bps: i32) -> *mut c_void;
    fn sl_opus_encode_float(
        enc: *mut c_void,
        pcm: *const f32,
        frame_size: i32,
        out: *mut u8,
        out_cap: i32,
    ) -> i32;
    fn sl_opus_destroy(enc: *mut c_void);
}

pub fn spawn_audio_capture(running: Arc<AtomicBool>, tx: mpsc::Sender<Vec<u8>>) {
    std::thread::Builder::new()
        .name("wasapi-opus-audio".into())
        .spawn(move || {
            #[cfg(windows)]
            run_wasapi_loopback(running, tx);
            #[cfg(not(windows))]
            {
                let _ = (running, tx);
            }
        })
        .ok();
}

#[cfg(windows)]
fn run_wasapi_loopback(running: Arc<AtomicBool>, tx: mpsc::Sender<Vec<u8>>) {
    use windows::Win32::Media::Audio::{
        eConsole, eRender, IAudioCaptureClient, IAudioClient, IMMDeviceEnumerator,
        MMDeviceEnumerator, AUDCLNT_BUFFERFLAGS_SILENT, AUDCLNT_SHAREMODE_SHARED,
        AUDCLNT_STREAMFLAGS_LOOPBACK, WAVEFORMATEX,
    };
    use windows::Win32::System::Com::{
        CoCreateInstance, CoInitializeEx, CoUninitialize, CLSCTX_ALL, COINIT_MULTITHREADED,
    };

    const AUDCLNT_STREAMFLAGS_AUTOCONVERTPCM: u32 = 0x8000_0000;
    const AUDCLNT_STREAMFLAGS_SRC_DEFAULT_QUALITY: u32 = 0x0800_0000;
    const WAVE_FORMAT_IEEE_FLOAT: u16 = 0x0003;

    unsafe {
        let _ = CoInitializeEx(None, COINIT_MULTITHREADED);

        let opus_enc = sl_opus_create(48000, 2, 128_000);
        if opus_enc.is_null() {
            eprintln!("[audio] Failed to create Opus encoder");
            CoUninitialize();
            return;
        }

        let enumerator: Result<IMMDeviceEnumerator, _> =
            CoCreateInstance(&MMDeviceEnumerator, None, CLSCTX_ALL);
        let Ok(enumerator) = enumerator else {
            sl_opus_destroy(opus_enc);
            CoUninitialize();
            return;
        };

        let Ok(device) = enumerator.GetDefaultAudioEndpoint(eRender, eConsole) else {
            sl_opus_destroy(opus_enc);
            CoUninitialize();
            return;
        };

        let Ok(audio_client) = device.Activate::<IAudioClient>(CLSCTX_ALL, None) else {
            sl_opus_destroy(opus_enc);
            CoUninitialize();
            return;
        };

        let wf = WAVEFORMATEX {
            wFormatTag: WAVE_FORMAT_IEEE_FLOAT,
            nChannels: 2,
            nSamplesPerSec: 48000,
            nAvgBytesPerSec: 48000 * 2 * 4,
            nBlockAlign: 8,
            wBitsPerSample: 32,
            cbSize: 0,
        };

        let flags = AUDCLNT_STREAMFLAGS_LOOPBACK
            | AUDCLNT_STREAMFLAGS_AUTOCONVERTPCM
            | AUDCLNT_STREAMFLAGS_SRC_DEFAULT_QUALITY;

        // 20ms buffer duration in 100ns units
        if let Err(e) = audio_client.Initialize(
            AUDCLNT_SHAREMODE_SHARED,
            flags,
            200_000,
            0,
            &wf,
            None,
        ) {
            eprintln!("[audio] IAudioClient::Initialize failed: {e}");
            sl_opus_destroy(opus_enc);
            CoUninitialize();
            return;
        }

        let Ok(capture_client) = audio_client.GetService::<IAudioCaptureClient>() else {
            sl_opus_destroy(opus_enc);
            CoUninitialize();
            return;
        };

        if audio_client.Start().is_err() {
            sl_opus_destroy(opus_enc);
            CoUninitialize();
            return;
        }

        // 10ms Opus frame = 480 stereo samples = 960 floats
        const FRAME_SAMPLES: usize = 480;
        const CHANNELS: usize = 2;
        let mut ring: Vec<f32> = Vec::with_capacity(FRAME_SAMPLES * CHANNELS * 4);
        let mut opus_out = vec![0u8; 512];

        while running.load(Ordering::Relaxed) {
            let Ok(mut pkt_len) = capture_client.GetNextPacketSize() else {
                break;
            };
            if pkt_len == 0 {
                std::thread::sleep(std::time::Duration::from_millis(2));
                continue;
            }
            while pkt_len > 0 && running.load(Ordering::Relaxed) {
                let mut data_ptr = std::ptr::null_mut();
                let mut num_frames = 0u32;
                let mut buf_flags = 0u32;
                if capture_client
                    .GetBuffer(&mut data_ptr, &mut num_frames, &mut buf_flags, None, None)
                    .is_err()
                {
                    break;
                }
                let sample_count = num_frames as usize * CHANNELS;
                if buf_flags & (AUDCLNT_BUFFERFLAGS_SILENT.0 as u32) != 0 || data_ptr.is_null() {
                    ring.resize(ring.len() + sample_count, 0.0);
                } else {
                    let slice = std::slice::from_raw_parts(data_ptr as *const f32, sample_count);
                    ring.extend_from_slice(slice);
                }
                let _ = capture_client.ReleaseBuffer(num_frames);

                while ring.len() >= FRAME_SAMPLES * CHANNELS {
                    let encoded = sl_opus_encode_float(
                        opus_enc,
                        ring.as_ptr(),
                        FRAME_SAMPLES as i32,
                        opus_out.as_mut_ptr(),
                        opus_out.len() as i32,
                    );
                    ring.drain(..FRAME_SAMPLES * CHANNELS);
                    if encoded > 2 {
                        let _ = tx.try_send(opus_out[..encoded as usize].to_vec());
                    }
                }

                pkt_len = capture_client.GetNextPacketSize().unwrap_or(0);
            }
        }

        let _ = audio_client.Stop();
        sl_opus_destroy(opus_enc);
        CoUninitialize();
    }
}
