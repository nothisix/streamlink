//! Deterministic Cauchy Reed-Solomon erasure coding over GF(2^8)
//! Primitive polynomial: x^8 + x^4 + x^3 + x^2 + 1 (0x11D).
//! Identical math is implemented in Android Kotlin (`ReedSolomonFec.kt`)
//! so host encoding and mobile recovery match 100%.

const PRIM_POLY: u16 = 0x11D;

struct GfTables {
    exp: [u8; 512],
    log: [u8; 256],
}

const fn build_gf_tables() -> GfTables {
    let mut exp = [0u8; 512];
    let mut log = [0u8; 256];
    let mut x: u16 = 1;
    let mut i = 0usize;
    while i < 255 {
        exp[i] = x as u8;
        exp[i + 255] = x as u8;
        log[x as usize] = i as u8;
        x <<= 1;
        if x & 0x100 != 0 {
            x ^= PRIM_POLY;
        }
        i += 1;
    }
    GfTables { exp, log }
}

static GF: GfTables = build_gf_tables();

#[inline]
pub fn gf_mul(a: u8, b: u8) -> u8 {
    if a == 0 || b == 0 {
        0
    } else {
        GF.exp[GF.log[a as usize] as usize + GF.log[b as usize] as usize]
    }
}

#[inline]
pub fn gf_inv(a: u8) -> u8 {
    debug_assert!(a != 0);
    GF.exp[255 - GF.log[a as usize] as usize]
}

/// Cauchy encoding matrix entry for parity row `r` (0..fec_shards) and data col `c` (0..data_shards).
/// Requires data_shards + fec_shards <= 255.
#[inline]
fn cauchy_entry(r: usize, c: usize, data_shards: usize) -> u8 {
    let y = r as u8;
    let x = (data_shards + c) as u8;
    gf_inv(y ^ x)
}

/// Encode `data_shards` equal-length slices into `fec_shards` parity slices.
pub fn encode_parity(data: &[&[u8]], fec_shards: usize) -> Vec<Vec<u8>> {
    let k = data.len();
    if k == 0 || fec_shards == 0 {
        return Vec::new();
    }
    debug_assert!(k + fec_shards <= 255);
    let shard_len = data[0].len();
    let mut parity = vec![vec![0u8; shard_len]; fec_shards];

    for (r, p_row) in parity.iter_mut().enumerate() {
        for (c, d_shard) in data.iter().enumerate() {
            let coeff = cauchy_entry(r, c, k);
            if coeff == 1 {
                for i in 0..shard_len {
                    p_row[i] ^= d_shard[i];
                }
            } else if coeff != 0 {
                for i in 0..shard_len {
                    p_row[i] ^= gf_mul(coeff, d_shard[i]);
                }
            }
        }
    }
    parity
}

/// Recover missing data shards given at least `k` shards out of `k + m`.
/// `shards[0..k]` are data shards, `shards[k..k+m]` are parity shards.
#[allow(dead_code)]
pub fn reconstruct_data(shards: &mut [Option<Vec<u8>>], k: usize, m: usize) -> bool {
    if k == 0 || shards.len() < k + m {
        return false;
    }
    let missing_data: Vec<usize> = (0..k).filter(|&i| shards[i].is_none()).collect();
    if missing_data.is_empty() {
        return true;
    }
    let present: Vec<usize> = (0..(k + m)).filter(|&i| shards[i].is_some()).collect();
    if present.len() < k {
        return false;
    }
    let shard_len = shards[present[0]].as_ref().unwrap().len();
    let chosen = &present[..k];

    // Build k x k submatrix of the systematic Cauchy generator matrix
    let mut mat = vec![0u8; k * k];
    for (row_idx, &shard_id) in chosen.iter().enumerate() {
        if shard_id < k {
            mat[row_idx * k + shard_id] = 1;
        } else {
            let r = shard_id - k;
            for c in 0..k {
                mat[row_idx * k + c] = cauchy_entry(r, c, k);
            }
        }
    }

    // Invert mat via Gauss-Jordan over GF(2^8)
    let mut inv = vec![0u8; k * k];
    for i in 0..k {
        inv[i * k + i] = 1;
    }
    for col in 0..k {
        let pivot = (col..k).find(|&r| mat[r * k + col] != 0);
        let Some(p_row) = pivot else {
            return false;
        };
        if p_row != col {
            for j in 0..k {
                mat.swap(col * k + j, p_row * k + j);
                inv.swap(col * k + j, p_row * k + j);
            }
        }
        let scale = gf_inv(mat[col * k + col]);
        if scale != 1 {
            for j in 0..k {
                mat[col * k + j] = gf_mul(mat[col * k + j], scale);
                inv[col * k + j] = gf_mul(inv[col * k + j], scale);
            }
        }
        for r in 0..k {
            if r == col {
                continue;
            }
            let factor = mat[r * k + col];
            if factor != 0 {
                for j in 0..k {
                    mat[r * k + j] ^= gf_mul(factor, mat[col * k + j]);
                    inv[r * k + j] ^= gf_mul(factor, inv[col * k + j]);
                }
            }
        }
    }

    // Reconstruct missing data rows
    for &target_col in &missing_data {
        let mut recovered = vec![0u8; shard_len];
        for (j, &src_id) in chosen.iter().enumerate() {
            let coeff = inv[target_col * k + j];
            if coeff == 0 {
                continue;
            }
            let src = shards[src_id].as_ref().unwrap();
            if coeff == 1 {
                for i in 0..shard_len {
                    recovered[i] ^= src[i];
                }
            } else {
                for i in 0..shard_len {
                    recovered[i] ^= gf_mul(coeff, src[i]);
                }
            }
        }
        shards[target_col] = Some(recovered);
    }

    true
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_recovers_lost_shards() {
        let d0 = vec![0x11, 0x22, 0x33, 0x44, 0x55, 0x66];
        let d1 = vec![0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF];
        let d2 = vec![0x01, 0x23, 0x45, 0x67, 0x89, 0xAB];
        let d3 = vec![0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54];
        let data = [d0.as_slice(), d1.as_slice(), d2.as_slice(), d3.as_slice()];
        let parity = encode_parity(&data, 2);

        let mut shards: Vec<Option<Vec<u8>>> = vec![
            None, // drop d0
            Some(d1.clone()),
            None, // drop d2
            Some(d3.clone()),
            Some(parity[0].clone()),
            Some(parity[1].clone()),
        ];

        assert!(reconstruct_data(&mut shards, 4, 2));
        assert_eq!(shards[0].as_ref().unwrap(), &d0);
        assert_eq!(shards[2].as_ref().unwrap(), &d2);
    }
}
