//! Shared host state and UDP streaming/telemetry/input server loop.

use std::collections::VecDeque;
use std::net::{Ipv4Addr, SocketAddr};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use parking_lot::Mutex;
use tokio::net::UdpSocket;
use tokio::sync::mpsc;

use crate::capture::audio::spawn_audio_capture;
use crate::encode::{EncoderKind, VideoEncoder};
use crate::input::InputInjector;
use crate::net::abr::{AbrEngine, ResolutionTier};
use crate::net::discovery::{detect_lan_ipv4, spawn_discovery_services, HostAdvertisement};
use crate::net::fec::encode_parity;
use crate::net::protocol::{
    encode_audio_packet, encode_stream_meta, encode_video_shard, parse_header, write_header,
    GamepadInput, KeyboardInput, MouseAbsInput, MouseRelInput, PairAck, PairReq, PacketType,
    StreamConfigMsg, TelemetryFeedback, VideoCodec, DEFAULT_STREAM_PORT, MAX_SHARD_PAYLOAD,
};

#[derive(Debug, Clone)]
pub struct HostSettings {
    pub pin: [u8; 4],
    pub require_pin: bool,
    pub stream_port: u16,
    pub preferred_codec: VideoCodec,
    pub max_resolution: ResolutionTier,
    pub target_fps: u16,
    pub max_bitrate_kbps: u32,
    pub streaming_enabled: bool,
}

impl Default for HostSettings {
    fn default() -> Self {
        use rand::Rng;
        let mut rng = rand::thread_rng();
        let pin_num: u16 = rng.gen_range(1000..=9999);
        let pin_s = format!("{pin_num:04}");
        let b = pin_s.as_bytes();
        Self {
            pin: [b[0], b[1], b[2], b[3]],
            require_pin: true,
            stream_port: DEFAULT_STREAM_PORT,
            preferred_codec: VideoCodec::H264,
            max_resolution: ResolutionTier::P1080,
            target_fps: 60,
            max_bitrate_kbps: 10_000,
            streaming_enabled: true,
        }
    }
}

#[derive(Debug, Clone)]
pub struct HostTelemetry {
    pub lan_ip: String,
    pub host_name: String,
    pub client_connected: bool,
    pub client_name: String,
    pub client_addr: String,
    pub encoder_label: String,
    pub active_codec: VideoCodec,
    pub active_width: u32,
    pub active_height: u32,
    pub active_fps: u16,
    pub bitrate_kbps: u32,
    pub rtt_ms: f32,
    pub jitter_ms: f32,
    pub loss_pct: f32,
    pub fec_pct: u8,
    pub client_decode_ms: f32,
    pub vigem_ready: bool,
    pub status_line: String,
    pub history: VecDeque<(f32, f32)>, // (rtt_ms, bitrate_mbps)
}

impl Default for HostTelemetry {
    fn default() -> Self {
        Self {
            lan_ip: detect_lan_ipv4(),
            host_name: std::env::var("COMPUTERNAME").unwrap_or_else(|_| "StreamLink-PC".into()),
            client_connected: false,
            client_name: "-".into(),
            client_addr: "-".into(),
            encoder_label: "INIT".into(),
            active_codec: VideoCodec::H264,
            active_width: 1920,
            active_height: 1080,
            active_fps: 60,
            bitrate_kbps: 10_000,
            rtt_ms: 0.0,
            jitter_ms: 0.0,
            loss_pct: 0.0,
            fec_pct: 15,
            client_decode_ms: 0.0,
            vigem_ready: false,
            status_line: "LISTENING FOR ANDROID CLIENT".into(),
            history: VecDeque::with_capacity(120),
        }
    }
}

pub struct SharedContext {
    pub settings: Mutex<HostSettings>,
    pub telemetry: Mutex<HostTelemetry>,
    pub force_idr: AtomicBool,
    pub restart_pipeline: AtomicBool,
}

impl SharedContext {
    pub fn new() -> Arc<Self> {
        Arc::new(Self {
            settings: Mutex::new(HostSettings::default()),
            telemetry: Mutex::new(HostTelemetry::default()),
            force_idr: AtomicBool::new(false),
            restart_pipeline: AtomicBool::new(false),
        })
    }

    pub fn regenerate_pin(&self) {
        use rand::Rng;
        let pin_num: u16 = rand::thread_rng().gen_range(1000..=9999);
        let s = format!("{pin_num:04}");
        let b = s.as_bytes();
        self.settings.lock().pin = [b[0], b[1], b[2], b[3]];
    }

    pub fn set_pin_str(&self, s: &str) {
        let digits: Vec<u8> = s.bytes().filter(|b| b.is_ascii_digit()).take(4).collect();
        if digits.len() == 4 {
            self.settings.lock().pin = [digits[0], digits[1], digits[2], digits[3]];
        }
    }
}

struct ActiveSession {
    session_id: u32,
    peer: SocketAddr,
    codec: VideoCodec,
    max_fps: u16,
    last_rx: Instant,
    abr: AbrEngine,
}

pub fn start_host_runtime(ctx: Arc<SharedContext>) {
    std::thread::Builder::new()
        .name("streamlink-tokio".into())
        .spawn(move || {
            let rt = tokio::runtime::Builder::new_multi_thread()
                .enable_all()
                .build()
                .expect("tokio runtime");
            rt.block_on(async move {
                run_server(ctx).await;
            });
        })
        .expect("spawn tokio thread");
}

async fn run_server(ctx: Arc<SharedContext>) {
    let settings_snap = ctx.settings.lock().clone();
    let (lan_ip, host_name) = {
        let t = ctx.telemetry.lock();
        (t.lan_ip.clone(), t.host_name.clone())
    };

    let adv = Arc::new(HostAdvertisement {
        host_name: host_name.clone(),
        stream_port: settings_snap.stream_port,
        lan_ip: lan_ip.clone(),
        codec_mask: 0x03, // H264 + HEVC
    });
    spawn_discovery_services(adv);

    let bind_addr = SocketAddr::from((Ipv4Addr::UNSPECIFIED, settings_snap.stream_port));
    let std_sock = match std::net::UdpSocket::bind(bind_addr) {
        Ok(s) => s,
        Err(e) => {
            ctx.telemetry.lock().status_line = format!("UDP BIND ERROR: {e}");
            return;
        }
    };
    let _ = std_sock.set_nonblocking(true);
    let video_sock = Arc::new(std_sock.try_clone().expect("clone udp socket"));
    let sock = match UdpSocket::from_std(std_sock) {
        Ok(s) => Arc::new(s),
        Err(e) => {
            ctx.telemetry.lock().status_line = format!("TOKIO UDP ERROR: {e}");
            return;
        }
    };

    let session: Arc<Mutex<Option<ActiveSession>>> = Arc::new(Mutex::new(None));
    let start_instant = Instant::now();

    // Audio capture channel
    let audio_running = Arc::new(AtomicBool::new(true));
    let (audio_tx, mut audio_rx) = mpsc::channel::<Vec<u8>>(64);
    spawn_audio_capture(audio_running.clone(), audio_tx);

    // Input injector lives on dedicated low-latency OS thread so ViGEm IOCTLs / SendInput never stall UDP recv_from
    #[derive(Clone, Copy)]
    enum InputEvent {
        Reset,
        Gamepad(GamepadInput),
        MouseRel(MouseRelInput),
        MouseAbs(MouseAbsInput),
        Keyboard(KeyboardInput),
    }

    let (input_tx, input_rx) = std::sync::mpsc::sync_channel::<InputEvent>(512);
    {
        let mut injector = InputInjector::new();
        ctx.telemetry.lock().vigem_ready = injector.vigem_ready();
        std::thread::Builder::new()
            .name("input-injector".into())
            .spawn(move || {
                while let Ok(ev) = input_rx.recv() {
                    match ev {
                        InputEvent::Reset => injector.reset_session(),
                        InputEvent::Gamepad(g) => injector.inject_gamepad(&g),
                        InputEvent::MouseRel(m) => injector.inject_mouse_rel(&m),
                        InputEvent::MouseAbs(m) => injector.inject_mouse_abs(&m),
                        InputEvent::Keyboard(k) => injector.inject_keyboard(&k),
                    }
                }
            })
            .ok();
    }

    // Audio forwarder task
    {
        let sock_a = sock.clone();
        let sess_a = session.clone();
        let ctx_a = ctx.clone();
        tokio::spawn(async move {
            let mut seq = 0u32;
            while let Some(opus_pkt) = audio_rx.recv().await {
                if !ctx_a.settings.lock().streaming_enabled {
                    continue;
                }
                let target = {
                    let guard = sess_a.lock();
                    guard.as_ref().map(|s| (s.session_id, s.peer))
                };
                if let Some((sid, peer)) = target {
                    let ts_us = start_instant.elapsed().as_micros() as u32;
                    let pkt = encode_audio_packet(sid, seq, ts_us, &opus_pkt);
                    seq = seq.wrapping_add(1);
                    let _ = sock_a.send_to(&pkt, peer).await;
                }
            }
        });
    }

    // Video capture + encode + FEC sender thread
    {
        let sock_v = video_sock.clone();
        let sess_v = session.clone();
        let ctx_v = ctx.clone();
        std::thread::Builder::new()
            .name("video-capture-encode".into())
            .spawn(move || {
                video_pipeline_thread(ctx_v, sess_v, sock_v, start_instant);
            })
            .ok();
    }

    // Main UDP packet receiver loop (pairing, pings, telemetry FB, IDR requests, gamepad/mouse/kbd input)
    let mut rx_buf = [0u8; 4096];
    let mut prev_received = 0u32;
    let mut prev_lost = 0u32;

    loop {
        tokio::select! {
            recv = sock.recv_from(&mut rx_buf) => {
                let Ok((n, peer)) = recv else { continue; };
                let Some((ptype, sid, payload)) = parse_header(&rx_buf[..n]) else { continue; };

                match ptype {
                    PacketType::PairReq => {
                        let Some(req) = PairReq::decode(payload) else { continue; };
                        let s_cfg = ctx.settings.lock().clone();
                        if s_cfg.require_pin && req.pin != s_cfg.pin {
                            let rx_pin = String::from_utf8_lossy(&req.pin).into_owned();
                            let host_pin = String::from_utf8_lossy(&s_cfg.pin).into_owned();
                            ctx.telemetry.lock().status_line = format!(
                                "PIN REJECTED FROM {} (GOT '{rx_pin}', HOST '{host_pin}')",
                                peer.ip()
                            );
                            let ack = PairAck {
                                status: 1,
                                session_id: 0,
                                codec: VideoCodec::H264,
                                width: 1920,
                                height: 1080,
                                fps: 60,
                                audio_rate: 48000,
                                audio_channels: 2,
                                audio_frame_ms: 10,
                                client_nonce: req.client_nonce,
                            };
                            let _ = sock.send_to(&ack.encode(), peer).await;
                            continue;
                        }

                        let new_sid: u32 = rand::random::<u32>() | 1;
                        let negotiated_codec = if s_cfg.preferred_codec == VideoCodec::Hevc && (req.codec_mask & 0x02) != 0 {
                            VideoCodec::Hevc
                        } else {
                            VideoCodec::H264
                        };
                        let fps = s_cfg.target_fps.min(req.max_fps.max(30));
                        let (w, h) = s_cfg.max_resolution.dimensions(1920, 1080);

                        let ack = PairAck {
                            status: 0,
                            session_id: new_sid,
                            codec: negotiated_codec,
                            width: w as u16,
                            height: h as u16,
                            fps,
                            audio_rate: 48000,
                            audio_channels: 2,
                            audio_frame_ms: 10,
                            client_nonce: req.client_nonce,
                        };
                        let _ = sock.send_to(&ack.encode(), peer).await;

                        let abr = AbrEngine::new(s_cfg.max_bitrate_kbps, s_cfg.max_resolution);
                        *session.lock() = Some(ActiveSession {
                            session_id: new_sid,
                            peer,
                            codec: negotiated_codec,
                            max_fps: fps,
                            last_rx: Instant::now(),
                            abr,
                        });
                        prev_received = 0;
                        prev_lost = 0;
                        let _ = input_tx.try_send(InputEvent::Reset);
                        ctx.force_idr.store(true, Ordering::Relaxed);
                        ctx.restart_pipeline.store(true, Ordering::Relaxed);

                        let mut t = ctx.telemetry.lock();
                        t.client_connected = true;
                        t.client_name = req.client_name;
                        t.client_addr = peer.to_string();
                        t.active_codec = negotiated_codec;
                        t.active_fps = fps;
                        t.status_line = "STREAMING LIVE".into();
                    }

                    PacketType::Ping => {
                        if payload.len() >= 8 {
                            let mut pong = Vec::with_capacity(16);
                            write_header(&mut pong, PacketType::Pong, sid);
                            pong.extend_from_slice(&payload[..8]);
                            let _ = sock.send_to(&pong, peer).await;
                        }
                        if let Some(s) = session.lock().as_mut() {
                            if s.session_id == sid {
                                s.last_rx = Instant::now();
                            }
                        }
                    }

                    PacketType::TelemetryFb => {
                        let Some(fb) = TelemetryFeedback::decode(payload) else { continue; };
                        let now_us = start_instant.elapsed().as_micros() as u64;
                        let rtt_ms = if (fb.echo_ts_us & (1u64 << 63)) != 0 {
                            ((fb.echo_ts_us & !(1u64 << 63)) as f32 / 1000.0).min(999.0)
                        } else if fb.echo_ts_us > 0 && now_us >= fb.echo_ts_us {
                            ((now_us - fb.echo_ts_us) as f32 / 1000.0).min(999.0)
                        } else {
                            0.0
                        };

                        let d_rx = fb.packets_received.saturating_sub(prev_received);
                        let d_lost = fb.packets_lost.saturating_sub(prev_lost);
                        prev_received = fb.packets_received;
                        prev_lost = fb.packets_lost;
                        let total_window = d_rx + d_lost;
                        let loss_pct = if total_window > 0 {
                            (d_lost as f32 / total_window as f32) * 100.0
                        } else {
                            0.0
                        };
                        let jitter_ms = fb.jitter_us as f32 / 1000.0;
                        let decode_ms = fb.decode_time_us as f32 / 1000.0;

                        let decision = {
                            let mut guard = session.lock();
                            if let Some(s) = guard.as_mut() {
                                if s.session_id != sid {
                                    continue;
                                }
                                s.last_rx = Instant::now();
                                s.peer = peer;
                                Some(s.abr.on_telemetry(
                                    Instant::now(),
                                    rtt_ms,
                                    loss_pct,
                                    jitter_ms,
                                    fb.idr_requested != 0,
                                ))
                            } else {
                                None
                            }
                        };

                        if let Some(dec) = decision {
                            if dec.force_idr {
                                ctx.force_idr.store(true, Ordering::Relaxed);
                            }
                            let mut t = ctx.telemetry.lock();
                            t.rtt_ms = rtt_ms;
                            t.jitter_ms = jitter_ms;
                            t.loss_pct = loss_pct;
                            t.bitrate_kbps = dec.target_bitrate_kbps;
                            t.fec_pct = (dec.fec_ratio * 100.0).round() as u8;
                            t.client_decode_ms = decode_ms;
                            if fb.fps_rendered > 0 {
                                t.active_fps = fb.fps_rendered;
                            }
                            if t.history.len() >= 120 {
                                t.history.pop_front();
                            }
                            t.history.push_back((rtt_ms, dec.target_bitrate_kbps as f32 / 1000.0));
                        }
                    }

                    PacketType::IdrReq => {
                        ctx.force_idr.store(true, Ordering::Relaxed);
                    }

                    PacketType::InputGamepad => {
                        if let Some(g) = GamepadInput::decode(payload) {
                            let _ = input_tx.try_send(InputEvent::Gamepad(g));
                        }
                    }

                    PacketType::InputMouseRel => {
                        if let Some(m) = MouseRelInput::decode(payload) {
                            let _ = input_tx.try_send(InputEvent::MouseRel(m));
                        }
                    }

                    PacketType::InputMouseAbs => {
                        if let Some(m) = MouseAbsInput::decode(payload) {
                            let _ = input_tx.try_send(InputEvent::MouseAbs(m));
                        }
                    }

                    PacketType::InputKeyboard => {
                        if let Some(k) = KeyboardInput::decode(payload) {
                            let _ = input_tx.try_send(InputEvent::Keyboard(k));
                        }
                    }

                    PacketType::StreamConfig => {
                        if let Some(cfg) = StreamConfigMsg::decode(payload) {
                            let mut guard = session.lock();
                            if let Some(s) = guard.as_mut() {
                                if s.session_id == sid {
                                    let locked = if cfg.lock_bitrate_kbps == 0 {
                                        None
                                    } else {
                                        Some(cfg.lock_bitrate_kbps)
                                    };
                                    s.abr.set_locked_bitrate(locked);
                                    if cfg.codec_pref == 0 || cfg.codec_pref == 1 {
                                        s.codec = VideoCodec::from_u8(cfg.codec_pref);
                                        ctx.settings.lock().preferred_codec = s.codec;
                                        ctx.restart_pipeline.store(true, Ordering::Relaxed);
                                    }
                                }
                            }
                        }
                    }

                    PacketType::KeepAlive => {
                        if let Some(s) = session.lock().as_mut() {
                            if s.session_id == sid {
                                s.last_rx = Instant::now();
                            }
                        }
                    }

                    PacketType::Disconnect => {
                        let mut guard = session.lock();
                        if guard.as_ref().map(|s| s.session_id) == Some(sid) {
                            *guard = None;
                            let mut t = ctx.telemetry.lock();
                            t.client_connected = false;
                            t.client_name = "-".into();
                            t.client_addr = "-".into();
                            t.status_line = "CLIENT DISCONNECTED".into();
                        }
                    }

                    _ => {}
                }
            }

            _ = tokio::time::sleep(Duration::from_secs(1)) => {
                let mut guard = session.lock();
                if let Some(s) = guard.as_ref() {
                    if s.last_rx.elapsed() > Duration::from_secs(6) {
                        *guard = None;
                        let mut t = ctx.telemetry.lock();
                        t.client_connected = false;
                        t.client_name = "-".into();
                        t.client_addr = "-".into();
                        t.status_line = "SESSION TIMED OUT — LISTENING".into();
                    }
                }
            }
        }
    }
}

fn video_pipeline_thread(
    ctx: Arc<SharedContext>,
    session: Arc<Mutex<Option<ActiveSession>>>,
    sock: Arc<std::net::UdpSocket>,
    start_instant: Instant,
) {
    #[cfg(windows)]
    let mut capturer = match crate::capture::dxgi::DxgiCapturer::new() {
        Ok(c) => c,
        Err(e) => {
            ctx.telemetry.lock().status_line = format!("DXGI INIT ERROR: {e}");
            return;
        }
    };

    #[cfg(windows)]
    let (base_w, base_h, d3d_ptr) = (
        capturer.desktop_width,
        capturer.desktop_height,
        capturer.nvenc_d3d11_device_ptr(),
    );
    #[cfg(not(windows))]
    let (base_w, base_h, d3d_ptr) = (1920u32, 1080u32, std::ptr::null_mut());

    let mut encoder: Option<VideoEncoder> = None;
    let mut enc_w = 0u32;
    let mut enc_h = 0u32;
    let mut enc_codec = VideoCodec::H264;
    let mut enc_fps = 60u16;

    let mut frame_id = 0u32;
    let mut pkt_seq = 0u32;
    let mut fps_counter = 0u16;
    let mut fps_timer = Instant::now();

    loop {
        let s_cfg = ctx.settings.lock().clone();
        if !s_cfg.streaming_enabled {
            std::thread::sleep(Duration::from_millis(50));
            continue;
        }

        let active = {
            let mut guard = session.lock();
            guard.as_mut().map(|s| {
                s.abr.set_limits(s_cfg.max_bitrate_kbps, s_cfg.max_resolution);
                (
                    s.session_id,
                    s.peer,
                    s.codec,
                    s.max_fps,
                    s.abr.current_bitrate_kbps(),
                    s.abr.current_resolution(),
                    s.abr.current_fec_ratio(),
                )
            })
        };

        let Some((sid, peer, codec, max_fps, bitrate_kbps, res_tier, fec_ratio)) = active else {
            encoder = None;
            std::thread::sleep(Duration::from_millis(40));
            continue;
        };

        let (target_w, target_h) = res_tier.dimensions(base_w, base_h);
        let target_fps = s_cfg.target_fps.min(max_fps).max(30);
        let need_recreate = encoder.is_none()
            || enc_w != target_w
            || enc_h != target_h
            || enc_codec != codec
            || enc_fps != target_fps
            || ctx.restart_pipeline.swap(false, Ordering::Relaxed);

        if need_recreate {
            encoder = None;
            match VideoEncoder::create(
                d3d_ptr,
                target_w,
                target_h,
                target_fps as u32,
                bitrate_kbps,
                codec,
            ) {
                Ok(enc) => {
                    enc_w = target_w;
                    enc_h = target_h;
                    enc_codec = enc.codec();
                    enc_fps = target_fps;
                    {
                        let mut t = ctx.telemetry.lock();
                        t.encoder_label = enc.kind().label().to_string();
                        t.active_codec = enc.codec();
                        t.active_width = target_w;
                        t.active_height = target_h;
                    }
                    let meta = encode_stream_meta(
                        sid,
                        enc.codec(),
                        target_w as u16,
                        target_h as u16,
                        target_fps,
                        bitrate_kbps,
                    );
                    let _ = sock.send_to(&meta, peer);
                    ctx.force_idr.store(true, Ordering::Relaxed);
                    encoder = Some(enc);
                }
                Err(e) => {
                    ctx.telemetry.lock().status_line = format!("ENCODER ERROR: {e}");
                    std::thread::sleep(Duration::from_millis(250));
                    continue;
                }
            }
        }

        let Some(enc) = encoder.as_mut() else { continue; };
        enc.set_bitrate(bitrate_kbps);

        let frame_start = Instant::now();
        let frame_interval = Duration::from_micros(1_000_000 / target_fps as u64);
        let force_idr = ctx.force_idr.swap(false, Ordering::Relaxed);

        let encoded: Option<(Vec<u8>, bool)> = {
            #[cfg(windows)]
            {
                if enc.kind() == EncoderKind::Nvenc {
                    let dst_tex = enc.nvenc_input_texture();
                    match capturer.capture_to_nvenc_texture(dst_tex, enc_w, enc_h, 8) {
                        Ok(true) => {
                            let pts_us = start_instant.elapsed().as_micros() as u64;
                            match enc.encode_nvenc(pts_us, force_idr) {
                                Ok((bytes, is_idr)) => Some((bytes.to_vec(), is_idr)),
                                Err(e) => {
                                    eprintln!("[encode] nvenc err: {e}");
                                    None
                                }
                            }
                        }
                        Ok(false) => None,
                        Err(e) => {
                            eprintln!("[capture] gpu cap err: {e}");
                            None
                        }
                    }
                } else {
                    match capturer.capture_bgra_cpu(enc_w, enc_h, 8) {
                        Ok(Some((bgra, stride))) => match enc.encode_bgra(bgra, stride, force_idr) {
                            Ok((bytes, is_idr)) => Some((bytes.to_vec(), is_idr)),
                            Err(_) => None,
                        },
                        _ => None,
                    }
                }
            }
            #[cfg(not(windows))]
            {
                None
            }
        };

        if let Some((nal_bytes, is_idr)) = encoded {
            if !nal_bytes.is_empty() {
                send_frame_with_fec(
                    &sock,
                    peer,
                    sid,
                    frame_id,
                    &mut pkt_seq,
                    start_instant.elapsed().as_micros() as u32,
                    &nal_bytes,
                    is_idr,
                    enc.codec(),
                    fec_ratio,
                );
                frame_id = frame_id.wrapping_add(1);
                fps_counter += 1;
            }
        }

        if fps_timer.elapsed() >= Duration::from_secs(1) {
            ctx.telemetry.lock().active_fps = fps_counter;
            fps_counter = 0;
            fps_timer = Instant::now();
        }

        let elapsed = frame_start.elapsed();
        if elapsed < frame_interval {
            std::thread::sleep(frame_interval - elapsed);
        }
    }
}

fn send_frame_with_fec(
    sock: &std::net::UdpSocket,
    peer: SocketAddr,
    session_id: u32,
    frame_id: u32,
    pkt_seq: &mut u32,
    timestamp_us: u32,
    frame_bytes: &[u8],
    is_idr: bool,
    codec: VideoCodec,
    fec_ratio: f32,
) {
    let total = frame_bytes.len();
    if total == 0 {
        return;
    }

    // Ensure data_shards fits comfortably inside RS GF(2^8) limit (<= 255 total shards)
    let shard_width = if total <= 180 * MAX_SHARD_PAYLOAD {
        MAX_SHARD_PAYLOAD
    } else {
        ((total + 179) / 180).min(1380)
    };

    let data_shards = (total + shard_width - 1) / shard_width;
    if data_shards > 250 {
        // Extremely rare oversized frame: drop/skip FEC safely
        return;
    }

    let rem = total % shard_width;
    let last_shard_len = if rem == 0 { shard_width } else { rem } as u16;
    let fec_shards = ((data_shards as f32 * fec_ratio).ceil() as usize)
        .max(1)
        .min(255 - data_shards);

    let mut flags = if is_idr { 0x01 } else { 0x00 };
    if codec == VideoCodec::Hevc {
        flags |= 0x02;
    }

    // Build padded uniform shards for RS parity computation
    let mut padded_storage: Vec<Vec<u8>> = Vec::with_capacity(data_shards);
    for idx in 0..data_shards {
        let start = idx * shard_width;
        let end = (start + shard_width).min(total);
        let mut s = vec![0u8; shard_width];
        s[..(end - start)].copy_from_slice(&frame_bytes[start..end]);

        // Send exact unpadded data slice for the final shard to save wire bandwidth
        let pkt = encode_video_shard(
            session_id,
            false,
            frame_id,
            *pkt_seq,
            timestamp_us,
            idx as u8,
            data_shards as u8,
            fec_shards as u8,
            flags,
            last_shard_len,
            &frame_bytes[start..end],
        );
        *pkt_seq = pkt_seq.wrapping_add(1);
        let _ = sock.send_to(&pkt, peer);

        padded_storage.push(s);
    }

    let refs: Vec<&[u8]> = padded_storage.iter().map(|v| v.as_slice()).collect();
    let parity = encode_parity(&refs, fec_shards);
    for (p_idx, p_shard) in parity.iter().enumerate() {
        let pkt = encode_video_shard(
            session_id,
            true,
            frame_id,
            *pkt_seq,
            timestamp_us,
            (data_shards + p_idx) as u8,
            data_shards as u8,
            fec_shards as u8,
            flags,
            last_shard_len,
            p_shard,
        );
        *pkt_seq = pkt_seq.wrapping_add(1);
        let _ = sock.send_to(&pkt, peer);
    }
}
