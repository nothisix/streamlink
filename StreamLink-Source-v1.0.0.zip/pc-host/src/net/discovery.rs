//! LAN discovery via mDNS (_streamlink._udp.local.) and UDP broadcast responder.

use std::net::{Ipv4Addr, SocketAddr};
use std::sync::Arc;
use tokio::net::UdpSocket;

use crate::net::protocol::{DEFAULT_DISCOVERY_PORT, DISCOVER_PROBE_MAGIC, DISCOVER_RESP_MAGIC};

pub struct HostAdvertisement {
    pub host_name: String,
    pub stream_port: u16,
    pub lan_ip: String,
    pub codec_mask: u8,
}

pub fn detect_lan_ipv4() -> String {
    if let Ok(ifaces) = local_ip_address::list_afinet_netifas() {
        let mut fallback: Option<String> = None;
        for (name, ip) in ifaces {
            if let std::net::IpAddr::V4(v4) = ip {
                if v4.is_loopback() || v4.is_link_local() {
                    continue;
                }
                let lower = name.to_ascii_lowercase();
                let oct = v4.octets();
                let is_virtual = lower.contains("vethernet")
                    || lower.contains("virtualbox")
                    || lower.contains("vmware")
                    || lower.contains("wsl")
                    || lower.contains("docker")
                    || lower.contains("loopback")
                    || (oct[0] == 192 && oct[1] == 168 && oct[2] == 56);
                if !is_virtual {
                    return v4.to_string();
                }
                if fallback.is_none() {
                    fallback = Some(v4.to_string());
                }
            }
        }
        if let Some(ip) = fallback {
            return ip;
        }
    }
    if let Ok(ip) = local_ip_address::local_ip() {
        if let std::net::IpAddr::V4(v4) = ip {
            return v4.to_string();
        }
    }
    "127.0.0.1".to_string()
}

pub fn spawn_discovery_services(adv: Arc<HostAdvertisement>) {
    // 1. mDNS advertisement (_streamlink._udp.local.)
    let adv_mdns = adv.clone();
    std::thread::Builder::new()
        .name("mdns-advertiser".into())
        .spawn(move || {
            let Ok(daemon) = mdns_sd::ServiceDaemon::new() else {
                eprintln!("[discovery] Failed to start mDNS daemon");
                return;
            };
            let service_type = "_streamlink._udp.local.";
            let instance_name = adv_mdns.host_name.clone();
            let host_fqdn = format!("{}.local.", adv_mdns.host_name.replace(' ', "-"));
            let port_str = adv_mdns.stream_port.to_string();
            let props = [
                ("ver", "1"),
                ("port", port_str.as_str()),
                ("pin", "1"),
                ("codecs", "h264,hevc"),
            ];
            if let Ok(info) = mdns_sd::ServiceInfo::new(
                service_type,
                &instance_name,
                &host_fqdn,
                adv_mdns.lan_ip.as_str(),
                adv_mdns.stream_port,
                &props[..],
            ) {
                let _ = daemon.register(info);
            }
            loop {
                std::thread::sleep(std::time::Duration::from_secs(60));
            }
        })
        .ok();

    // 2. Fast UDP broadcast responder on 0.0.0.0:47990 (<1s LAN discovery)
    tokio::spawn(async move {
        let bind_addr = SocketAddr::from((Ipv4Addr::UNSPECIFIED, DEFAULT_DISCOVERY_PORT));
        let Ok(sock) = UdpSocket::bind(bind_addr).await else {
            eprintln!("[discovery] Could not bind UDP discovery port {DEFAULT_DISCOVERY_PORT}");
            return;
        };
        let _ = sock.set_broadcast(true);
        let mut buf = [0u8; 512];
        loop {
            let Ok((len, peer)) = sock.recv_from(&mut buf).await else {
                continue;
            };
            if len >= DISCOVER_PROBE_MAGIC.len()
                && &buf[..DISCOVER_PROBE_MAGIC.len()] == DISCOVER_PROBE_MAGIC
            {
                let mut resp = Vec::with_capacity(96);
                resp.extend_from_slice(DISCOVER_RESP_MAGIC);
                resp.extend_from_slice(&adv.stream_port.to_be_bytes());
                resp.push(adv.codec_mask);
                let name_bytes = adv.host_name.as_bytes();
                let nlen = name_bytes.len().min(48) as u8;
                resp.push(nlen);
                resp.extend_from_slice(&name_bytes[..nlen as usize]);
                let _ = sock.send_to(&resp, peer).await;
            }
        }
    });
}
