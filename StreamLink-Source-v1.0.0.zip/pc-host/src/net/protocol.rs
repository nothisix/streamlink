//! StreamLink binary UDP protocol v1.
//! All multi-byte integers are network byte order (big-endian).

pub const PROTOCOL_MAGIC: u16 = 0x534C; // 'SL'
pub const PROTOCOL_VERSION: u8 = 1;
pub const DEFAULT_DISCOVERY_PORT: u16 = 47990;
pub const DEFAULT_STREAM_PORT: u16 = 47991;
pub const MAX_SHARD_PAYLOAD: usize = 1200;

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PacketType {
    PairReq = 0x01,
    PairAck = 0x02,
    Ping = 0x03,
    Pong = 0x04,
    VideoData = 0x10,
    VideoFec = 0x11,
    AudioData = 0x12,
    StreamMeta = 0x13,
    TelemetryFb = 0x20,
    IdrReq = 0x21,
    InputGamepad = 0x30,
    InputMouseRel = 0x31,
    InputKeyboard = 0x32,
    StreamConfig = 0x33,
    KeepAlive = 0x34,
    InputMouseAbs = 0x35,
    Disconnect = 0xFF,
}

impl PacketType {
    pub fn from_u8(v: u8) -> Option<Self> {
        match v {
            0x01 => Some(Self::PairReq),
            0x02 => Some(Self::PairAck),
            0x03 => Some(Self::Ping),
            0x04 => Some(Self::Pong),
            0x10 => Some(Self::VideoData),
            0x11 => Some(Self::VideoFec),
            0x12 => Some(Self::AudioData),
            0x13 => Some(Self::StreamMeta),
            0x20 => Some(Self::TelemetryFb),
            0x21 => Some(Self::IdrReq),
            0x30 => Some(Self::InputGamepad),
            0x31 => Some(Self::InputMouseRel),
            0x32 => Some(Self::InputKeyboard),
            0x33 => Some(Self::StreamConfig),
            0x34 => Some(Self::KeepAlive),
            0x35 => Some(Self::InputMouseAbs),
            0xFF => Some(Self::Disconnect),
            _ => None,
        }
    }
}

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VideoCodec {
    H264 = 0,
    Hevc = 1,
}

impl VideoCodec {
    pub fn from_u8(v: u8) -> Self {
        match v {
            1 => Self::Hevc,
            _ => Self::H264,
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            Self::H264 => "H.264",
            Self::Hevc => "HEVC",
        }
    }
}

/// Discovery probe (LAN UDP broadcast on port 47990)
pub const DISCOVER_PROBE_MAGIC: &[u8] = b"SL_DISC_REQ_V1";
pub const DISCOVER_RESP_MAGIC: &[u8] = b"SL_DISC_RSP_V1";

#[allow(dead_code)]
#[derive(Debug, Clone)]
pub struct PairReq {
    pub pin: [u8; 4],
    pub codec_mask: u8, // bit 0 = H264, bit 1 = HEVC
    pub max_fps: u16,
    pub req_width: u16,
    pub req_height: u16,
    pub client_nonce: u32,
    pub client_name: String,
}

impl PairReq {
    pub fn decode(payload: &[u8]) -> Option<Self> {
        if payload.len() < 16 {
            return None;
        }
        let pin = [payload[0], payload[1], payload[2], payload[3]];
        let codec_mask = payload[4];
        let max_fps = u16::from_be_bytes([payload[5], payload[6]]);
        let req_width = u16::from_be_bytes([payload[7], payload[8]]);
        let req_height = u16::from_be_bytes([payload[9], payload[10]]);
        let client_nonce = u32::from_be_bytes([payload[11], payload[12], payload[13], payload[14]]);
        let name_len = payload[15] as usize;
        if payload.len() < 16 + name_len {
            return None;
        }
        let client_name = String::from_utf8_lossy(&payload[16..16 + name_len]).into_owned();
        Some(Self {
            pin,
            codec_mask,
            max_fps,
            req_width,
            req_height,
            client_nonce,
            client_name,
        })
    }
}

#[derive(Debug, Clone)]
pub struct PairAck {
    pub status: u8, // 0 = OK, 1 = BAD_PIN, 2 = BUSY
    pub session_id: u32,
    pub codec: VideoCodec,
    pub width: u16,
    pub height: u16,
    pub fps: u16,
    pub audio_rate: u32,
    pub audio_channels: u8,
    pub audio_frame_ms: u8,
    pub client_nonce: u32,
}

impl PairAck {
    pub fn encode(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(24);
        write_header(&mut out, PacketType::PairAck, self.session_id);
        out.push(self.status);
        out.push(self.codec as u8);
        out.extend_from_slice(&self.width.to_be_bytes());
        out.extend_from_slice(&self.height.to_be_bytes());
        out.extend_from_slice(&self.fps.to_be_bytes());
        out.extend_from_slice(&self.audio_rate.to_be_bytes());
        out.push(self.audio_channels);
        out.push(self.audio_frame_ms);
        out.extend_from_slice(&self.client_nonce.to_be_bytes());
        out
    }
}

/// 8-byte common header: magic(2) + ver(1) + type(1) + session_id(4)
#[inline]
pub fn write_header(buf: &mut Vec<u8>, ptype: PacketType, session_id: u32) {
    buf.extend_from_slice(&PROTOCOL_MAGIC.to_be_bytes());
    buf.push(PROTOCOL_VERSION);
    buf.push(ptype as u8);
    buf.extend_from_slice(&session_id.to_be_bytes());
}

#[inline]
pub fn parse_header(pkt: &[u8]) -> Option<(PacketType, u32, &[u8])> {
    if pkt.len() < 8 {
        return None;
    }
    let magic = u16::from_be_bytes([pkt[0], pkt[1]]);
    if magic != PROTOCOL_MAGIC || pkt[2] != PROTOCOL_VERSION {
        return None;
    }
    let ptype = PacketType::from_u8(pkt[3])?;
    let session_id = u32::from_be_bytes([pkt[4], pkt[5], pkt[6], pkt[7]]);
    Some((ptype, session_id, &pkt[8..]))
}

/// Video shard header (16 bytes after 8-byte common header = 24 bytes overhead):
/// frame_id(u32), seq(u32), timestamp_us(u32), shard_idx(u8), data_shards(u8), fec_shards(u8), flags(u8), orig_shard_len(u16)
/// Total video subheader = 18 bytes.
/// flags: bit 0 = is_keyframe (IDR), bit 1 = codec_hevc
pub fn encode_video_shard(
    session_id: u32,
    is_fec: bool,
    frame_id: u32,
    seq: u32,
    timestamp_us: u32,
    shard_idx: u8,
    data_shards: u8,
    fec_shards: u8,
    flags: u8,
    orig_shard_len: u16,
    payload: &[u8],
) -> Vec<u8> {
    let mut out = Vec::with_capacity(26 + payload.len());
    write_header(
        &mut out,
        if is_fec {
            PacketType::VideoFec
        } else {
            PacketType::VideoData
        },
        session_id,
    );
    out.extend_from_slice(&frame_id.to_be_bytes());
    out.extend_from_slice(&seq.to_be_bytes());
    out.extend_from_slice(&timestamp_us.to_be_bytes());
    out.push(shard_idx);
    out.push(data_shards);
    out.push(fec_shards);
    out.push(flags);
    out.extend_from_slice(&orig_shard_len.to_be_bytes());
    out.extend_from_slice(payload);
    out
}

pub fn encode_audio_packet(session_id: u32, seq: u32, timestamp_us: u32, opus_frame: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(16 + opus_frame.len());
    write_header(&mut out, PacketType::AudioData, session_id);
    out.extend_from_slice(&seq.to_be_bytes());
    out.extend_from_slice(&timestamp_us.to_be_bytes());
    out.extend_from_slice(opus_frame);
    out
}

pub fn encode_stream_meta(
    session_id: u32,
    codec: VideoCodec,
    width: u16,
    height: u16,
    fps: u16,
    bitrate_kbps: u32,
) -> Vec<u8> {
    let mut out = Vec::with_capacity(20);
    write_header(&mut out, PacketType::StreamMeta, session_id);
    out.push(codec as u8);
    out.extend_from_slice(&width.to_be_bytes());
    out.extend_from_slice(&height.to_be_bytes());
    out.extend_from_slice(&fps.to_be_bytes());
    out.extend_from_slice(&bitrate_kbps.to_be_bytes());
    out
}

#[allow(dead_code)]
#[derive(Debug, Clone, Copy)]
pub struct TelemetryFeedback {
    pub echo_ts_us: u64,
    pub highest_seq: u32,
    pub packets_received: u32,
    pub packets_lost: u32,
    pub jitter_us: u32,
    pub decode_time_us: u32,
    pub fps_rendered: u16,
    pub idr_requested: u8,
}

impl TelemetryFeedback {
    pub fn decode(payload: &[u8]) -> Option<Self> {
        if payload.len() < 31 {
            return None;
        }
        Some(Self {
            echo_ts_us: u64::from_be_bytes(payload[0..8].try_into().ok()?),
            highest_seq: u32::from_be_bytes(payload[8..12].try_into().ok()?),
            packets_received: u32::from_be_bytes(payload[12..16].try_into().ok()?),
            packets_lost: u32::from_be_bytes(payload[16..20].try_into().ok()?),
            jitter_us: u32::from_be_bytes(payload[20..24].try_into().ok()?),
            decode_time_us: u32::from_be_bytes(payload[24..28].try_into().ok()?),
            fps_rendered: u16::from_be_bytes(payload[28..30].try_into().ok()?),
            idr_requested: payload[30],
        })
    }
}

#[derive(Debug, Clone, Copy)]
pub struct GamepadInput {
    pub buttons: u16,
    pub lt: u8,
    pub rt: u8,
    pub lx: i16,
    pub ly: i16,
    pub rx: i16,
    pub ry: i16,
    pub seq: u32,
}

impl GamepadInput {
    pub fn decode(payload: &[u8]) -> Option<Self> {
        if payload.len() < 16 {
            return None;
        }
        Some(Self {
            buttons: u16::from_be_bytes([payload[0], payload[1]]),
            lt: payload[2],
            rt: payload[3],
            lx: i16::from_be_bytes([payload[4], payload[5]]),
            ly: i16::from_be_bytes([payload[6], payload[7]]),
            rx: i16::from_be_bytes([payload[8], payload[9]]),
            ry: i16::from_be_bytes([payload[10], payload[11]]),
            seq: u32::from_be_bytes([payload[12], payload[13], payload[14], payload[15]]),
        })
    }
}

#[derive(Debug, Clone, Copy)]
pub struct MouseRelInput {
    pub dx: i16,
    pub dy: i16,
    pub wheel: i8,
    pub h_wheel: i8,
    pub buttons: u8, // bit 0=L, bit 1=R, bit 2=M
}

impl MouseRelInput {
    pub fn decode(payload: &[u8]) -> Option<Self> {
        if payload.len() < 6 {
            return None;
        }
        let (wheel, h_wheel, buttons) = if payload.len() >= 7 {
            (payload[4] as i8, payload[5] as i8, payload[6])
        } else {
            (payload[4] as i8, 0, payload[5])
        };
        Some(Self {
            dx: i16::from_be_bytes([payload[0], payload[1]]),
            dy: i16::from_be_bytes([payload[2], payload[3]]),
            wheel,
            h_wheel,
            buttons,
        })
    }
}

#[derive(Debug, Clone, Copy)]
pub struct MouseAbsInput {
    pub x_norm: u16, // 0..65535 normalized virtual screen X
    pub y_norm: u16, // 0..65535 normalized virtual screen Y
    pub buttons: u8, // bit 0=L, bit 1=R, bit 2=M
    pub wheel: i8,
    pub h_wheel: i8,
}

impl MouseAbsInput {
    pub fn decode(payload: &[u8]) -> Option<Self> {
        if payload.len() < 7 {
            return None;
        }
        Some(Self {
            x_norm: u16::from_be_bytes([payload[0], payload[1]]),
            y_norm: u16::from_be_bytes([payload[2], payload[3]]),
            buttons: payload[4],
            wheel: payload[5] as i8,
            h_wheel: payload[6] as i8,
        })
    }
}

#[derive(Debug, Clone, Copy)]
pub struct KeyboardInput {
    pub vk_code: u16,
    pub scan_code: u16,
    pub is_down: bool,
}

impl KeyboardInput {
    pub fn decode(payload: &[u8]) -> Option<Self> {
        if payload.len() < 5 {
            return None;
        }
        Some(Self {
            vk_code: u16::from_be_bytes([payload[0], payload[1]]),
            scan_code: u16::from_be_bytes([payload[2], payload[3]]),
            is_down: payload[4] != 0,
        })
    }
}

#[derive(Debug, Clone, Copy)]
pub struct StreamConfigMsg {
    pub lock_bitrate_kbps: u32, // 0 = auto ABR
    pub codec_pref: u8,         // 0xFF = unchanged, 0 = H264, 1 = HEVC
}

impl StreamConfigMsg {
    pub fn decode(payload: &[u8]) -> Option<Self> {
        if payload.len() < 5 {
            return None;
        }
        Some(Self {
            lock_bitrate_kbps: u32::from_be_bytes([payload[0], payload[1], payload[2], payload[3]]),
            codec_pref: payload[4],
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mouse_rel_and_abs_decode() {
        let rel = MouseRelInput::decode(&[0xFF, 0xF6, 0x00, 0x0A, 0xFF, 0x01, 0x03]).unwrap();
        assert_eq!(rel.dx, -10);
        assert_eq!(rel.dy, 10);
        assert_eq!(rel.wheel, -1);
        assert_eq!(rel.h_wheel, 1);
        assert_eq!(rel.buttons, 3);

        let abs = MouseAbsInput::decode(&[0x80, 0x00, 0x40, 0x00, 0x01, 0x00, 0x00]).unwrap();
        assert_eq!(abs.x_norm, 0x8000);
        assert_eq!(abs.y_norm, 0x4000);
        assert_eq!(abs.buttons, 1);
    }
}
