//! Dynamic Anti-Lag & Auto-Graphics Engine.
//! Adapts encoder bitrate, resolution tier, and FEC redundancy using
//! 50ms RTCP-style telemetry feedback packets.

use std::time::{Duration, Instant};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ResolutionTier {
    P1080,
    P900,
    P720,
}

impl ResolutionTier {
    pub fn dimensions(self, base_w: u32, base_h: u32) -> (u32, u32) {
        let (target_w, target_h) = match self {
            Self::P1080 => (base_w, base_h),
            Self::P900 => (1600, 900),
            Self::P720 => (1280, 720),
        };
        // Clamp so we never upscale beyond user's base capture size, and align to 2px
        let w = target_w.min(base_w) & !1;
        let h = target_h.min(base_h) & !1;
        (w.max(640), h.max(360))
    }

    pub fn label(self) -> &'static str {
        match self {
            Self::P1080 => "1080p",
            Self::P900 => "900p",
            Self::P720 => "720p",
        }
    }

    pub fn step_down(self) -> Self {
        match self {
            Self::P1080 => Self::P900,
            Self::P900 | Self::P720 => Self::P720,
        }
    }

    pub fn step_up(self, max_tier: Self) -> Self {
        let next = match self {
            Self::P720 => Self::P900,
            Self::P900 | Self::P1080 => Self::P1080,
        };
        match (next, max_tier) {
            (Self::P1080, Self::P900) => Self::P900,
            (Self::P1080 | Self::P900, Self::P720) => Self::P720,
            _ => next,
        }
    }
}

/// Bitrate tiers (kbps): 12M -> 10M -> 8M -> 5M -> 3M (cloud-gaming thermal-safe ladder)
const BITRATE_TIERS_KBPS: [u32; 5] = [12_000, 10_000, 8_000, 5_000, 3_000];

#[allow(dead_code)]
#[derive(Debug, Clone)]
pub struct AbrDecision {
    pub target_bitrate_kbps: u32,
    pub resolution_tier: ResolutionTier,
    pub fec_ratio: f32,
    pub force_idr: bool,
    pub changed_bitrate: bool,
    pub changed_resolution: bool,
}

pub struct AbrEngine {
    max_bitrate_kbps: u32,
    max_resolution: ResolutionTier,
    locked_bitrate_kbps: Option<u32>,

    tier_idx: usize,
    res_tier: ResolutionTier,
    fec_ratio: f32,

    baseline_rtt_ms: f32,
    last_rtt_ms: f32,
    last_loss_pct: f32,
    last_jitter_ms: f32,

    stable_since: Option<Instant>,
    last_step_down: Option<Instant>,
    last_step_up: Option<Instant>,
}

impl AbrEngine {
    pub fn new(max_bitrate_kbps: u32, max_resolution: ResolutionTier) -> Self {
        let tier_idx = BITRATE_TIERS_KBPS
            .iter()
            .position(|&b| b <= max_bitrate_kbps)
            .unwrap_or(0);
        Self {
            max_bitrate_kbps,
            max_resolution,
            locked_bitrate_kbps: None,
            tier_idx,
            res_tier: max_resolution,
            fec_ratio: 0.15,
            baseline_rtt_ms: 0.0,
            last_rtt_ms: 0.0,
            last_loss_pct: 0.0,
            last_jitter_ms: 0.0,
            stable_since: None,
            last_step_down: None,
            last_step_up: None,
        }
    }

    pub fn set_limits(&mut self, max_bitrate_kbps: u32, max_resolution: ResolutionTier) {
        self.max_bitrate_kbps = max_bitrate_kbps;
        self.max_resolution = max_resolution;
        if self.current_bitrate_kbps() > max_bitrate_kbps {
            self.tier_idx = BITRATE_TIERS_KBPS
                .iter()
                .position(|&b| b <= max_bitrate_kbps)
                .unwrap_or(BITRATE_TIERS_KBPS.len() - 1);
        }
        match (self.res_tier, max_resolution) {
            (ResolutionTier::P1080, ResolutionTier::P900) => self.res_tier = ResolutionTier::P900,
            (ResolutionTier::P1080 | ResolutionTier::P900, ResolutionTier::P720) => {
                self.res_tier = ResolutionTier::P720
            }
            _ => {}
        }
    }

    pub fn set_locked_bitrate(&mut self, locked_kbps: Option<u32>) {
        self.locked_bitrate_kbps = locked_kbps;
    }

    pub fn current_bitrate_kbps(&self) -> u32 {
        if let Some(locked) = self.locked_bitrate_kbps {
            return locked;
        }
        BITRATE_TIERS_KBPS[self.tier_idx].min(self.max_bitrate_kbps)
    }

    pub fn current_resolution(&self) -> ResolutionTier {
        self.res_tier
    }

    pub fn current_fec_ratio(&self) -> f32 {
        self.fec_ratio
    }

    pub fn on_telemetry(
        &mut self,
        now: Instant,
        rtt_ms: f32,
        loss_pct: f32,
        jitter_ms: f32,
        client_idr_req: bool,
    ) -> AbrDecision {
        if self.baseline_rtt_ms <= 0.01 {
            self.baseline_rtt_ms = rtt_ms.max(1.0);
        } else if rtt_ms < self.baseline_rtt_ms {
            // Track baseline downward quickly, upward very slowly
            self.baseline_rtt_ms = self.baseline_rtt_ms * 0.8 + rtt_ms * 0.2;
        } else {
            self.baseline_rtt_ms = self.baseline_rtt_ms * 0.995 + rtt_ms * 0.005;
        }

        self.last_rtt_ms = rtt_ms;
        self.last_loss_pct = loss_pct;
        self.last_jitter_ms = jitter_ms;

        let rtt_delta = (rtt_ms - self.baseline_rtt_ms).max(0.0);
        let prev_bitrate = self.current_bitrate_kbps();
        let prev_res = self.res_tier;
        let mut force_idr = client_idr_req;

        let congested = rtt_delta > 35.0 || loss_pct > 1.0;
        let stable = loss_pct <= 0.05 && rtt_delta < 15.0 && jitter_ms < 12.0;

        if congested && self.locked_bitrate_kbps.is_none() {
            self.stable_since = None;
            let cooldown_ok = self
                .last_step_down
                .map(|t| now.duration_since(t) >= Duration::from_millis(600))
                .unwrap_or(true);
            if cooldown_ok {
                self.last_step_down = Some(now);
                // Immediate smooth step-down
                if self.tier_idx + 1 < BITRATE_TIERS_KBPS.len() {
                    self.tier_idx += 1;
                }
                // Downscale capture/encode resolution when bitrate drops to <= 8 Mbps or severe loss
                if BITRATE_TIERS_KBPS[self.tier_idx] <= 8_000 || loss_pct > 3.0 {
                    self.res_tier = self.res_tier.step_down();
                }
                self.fec_ratio = (self.fec_ratio + 0.10).min(0.40);
                if loss_pct > 1.0 {
                    force_idr = true;
                }
            }
        } else if stable && self.locked_bitrate_kbps.is_none() {
            let start = *self.stable_since.get_or_insert(now);
            // Hold stability for 3 consecutive seconds before ramping back up
            if now.duration_since(start) >= Duration::from_secs(3) {
                let ramp_cooldown = self
                    .last_step_up
                    .map(|t| now.duration_since(t) >= Duration::from_secs(2))
                    .unwrap_or(true);
                if ramp_cooldown {
                    self.last_step_up = Some(now);
                    if self.tier_idx > 0 {
                        let next_idx = self.tier_idx - 1;
                        if BITRATE_TIERS_KBPS[next_idx] <= self.max_bitrate_kbps {
                            self.tier_idx = next_idx;
                        }
                    }
                    if BITRATE_TIERS_KBPS[self.tier_idx] >= 10_000 {
                        self.res_tier = self.res_tier.step_up(self.max_resolution);
                    }
                    self.fec_ratio = (self.fec_ratio - 0.05).max(0.15);
                }
            }
        } else {
            self.stable_since = None;
        }

        let new_bitrate = self.current_bitrate_kbps();
        let new_res = self.res_tier;

        AbrDecision {
            target_bitrate_kbps: new_bitrate,
            resolution_tier: new_res,
            fec_ratio: self.fec_ratio,
            force_idr,
            changed_bitrate: new_bitrate != prev_bitrate,
            changed_resolution: new_res != prev_res,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn abr_steps_down_on_loss_and_recovers_after_3s() {
        let mut abr = AbrEngine::new(12_000, ResolutionTier::P1080);
        let t0 = Instant::now();
        // Establish 10ms baseline
        let d0 = abr.on_telemetry(t0, 10.0, 0.0, 1.0, false);
        assert_eq!(d0.target_bitrate_kbps, 12_000);

        // RTT spikes +50ms (>35ms delta) and 2% loss
        let d1 = abr.on_telemetry(t0 + Duration::from_millis(700), 60.0, 2.0, 5.0, false);
        assert_eq!(d1.target_bitrate_kbps, 10_000);
        assert!(d1.force_idr);

        // Stable for 2.5s -> should NOT ramp up yet
        let t_stable = t0 + Duration::from_secs(1);
        abr.on_telemetry(t_stable, 10.0, 0.0, 1.0, false);
        let d2 = abr.on_telemetry(t_stable + Duration::from_millis(2500), 10.0, 0.0, 1.0, false);
        assert_eq!(d2.target_bitrate_kbps, 10_000);

        // Stable for >= 3.0s -> ramps back up to 12_000
        let d3 = abr.on_telemetry(t_stable + Duration::from_millis(3100), 10.0, 0.0, 1.0, false);
        assert_eq!(d3.target_bitrate_kbps, 12_000);
    }
}
