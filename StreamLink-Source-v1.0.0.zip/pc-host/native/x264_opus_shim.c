#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <x264.h>
#include <opus/opus.h>

typedef struct X264Ctx {
    x264_t* enc;
    x264_param_t param;
    x264_picture_t pic_in;
    x264_picture_t pic_out;
    uint32_t width;
    uint32_t height;
    int64_t pts;
} X264Ctx;

X264Ctx* sl_x264_create(uint32_t width, uint32_t height, uint32_t fps, uint32_t bitrate_kbps) {
    X264Ctx* ctx = (X264Ctx*)calloc(1, sizeof(X264Ctx));
    if (!ctx) return NULL;
    ctx->width = width;
    ctx->height = height;

    if (x264_param_default_preset(&ctx->param, "ultrafast", "zerolatency") < 0) {
        free(ctx);
        return NULL;
    }

    ctx->param.i_csp = X264_CSP_I420;
    ctx->param.i_width = (int)width;
    ctx->param.i_height = (int)height;
    ctx->param.i_fps_num = fps > 0 ? fps : 60;
    ctx->param.i_fps_den = 1;
    ctx->param.b_vfr_input = 0;
    ctx->param.b_repeat_headers = 1;
    ctx->param.b_annexb = 1;

    // Infinite GOP + 0 B-frames; IDR injected explicitly on demand
    ctx->param.i_keyint_max = X264_KEYINT_MAX_INFINITE;
    ctx->param.i_keyint_min = X264_KEYINT_MAX_INFINITE;
    ctx->param.i_bframe = 0;
    ctx->param.b_intra_refresh = 0;

    ctx->param.rc.i_rc_method = X264_RC_ABR;
    ctx->param.rc.i_bitrate = (int)bitrate_kbps;
    ctx->param.rc.i_vbv_max_bitrate = (int)bitrate_kbps;
    ctx->param.rc.i_vbv_buffer_size = (int)(bitrate_kbps / (fps > 0 ? fps : 60));
    if (ctx->param.rc.i_vbv_buffer_size < 200) ctx->param.rc.i_vbv_buffer_size = 200;

    ctx->param.i_threads = 4;
    ctx->param.b_sliced_threads = 1;

    x264_param_apply_profile(&ctx->param, "high");

    ctx->enc = x264_encoder_open(&ctx->param);
    if (!ctx->enc) {
        free(ctx);
        return NULL;
    }

    if (x264_picture_alloc(&ctx->pic_in, X264_CSP_I420, (int)width, (int)height) < 0) {
        x264_encoder_close(ctx->enc);
        free(ctx);
        return NULL;
    }
    return ctx;
}

int sl_x264_reconfigure_bitrate(X264Ctx* ctx, uint32_t bitrate_kbps) {
    if (!ctx || !ctx->enc) return -1;
    ctx->param.rc.i_bitrate = (int)bitrate_kbps;
    ctx->param.rc.i_vbv_max_bitrate = (int)bitrate_kbps;
    ctx->param.rc.i_vbv_buffer_size = (int)(bitrate_kbps / (ctx->param.i_fps_num > 0 ? ctx->param.i_fps_num : 60));
    if (ctx->param.rc.i_vbv_buffer_size < 200) ctx->param.rc.i_vbv_buffer_size = 200;
    return x264_encoder_reconfig(ctx->enc, &ctx->param);
}

// Converts BGRA frame directly into pic_in I420 planes and encodes
int sl_x264_encode_bgra(X264Ctx* ctx, const uint8_t* bgra, uint32_t stride, int force_idr, uint8_t* out_buf, uint32_t out_cap, uint32_t* out_len, int* out_is_idr) {
    if (!ctx || !bgra || !out_buf || !out_len || !out_is_idr) return -1;
    *out_len = 0;
    *out_is_idr = 0;

    const uint32_t w = ctx->width;
    const uint32_t h = ctx->height;
    uint8_t* y_plane = ctx->pic_in.img.plane[0];
    uint8_t* u_plane = ctx->pic_in.img.plane[1];
    uint8_t* v_plane = ctx->pic_in.img.plane[2];
    const int y_stride = ctx->pic_in.img.i_stride[0];
    const int u_stride = ctx->pic_in.img.i_stride[1];
    const int v_stride = ctx->pic_in.img.i_stride[2];

    for (uint32_t y = 0; y < h; y += 2) {
        const uint8_t* row0 = bgra + y * stride;
        const uint8_t* row1 = (y + 1 < h) ? (bgra + (y + 1) * stride) : row0;
        uint8_t* y0 = y_plane + y * y_stride;
        uint8_t* y1 = (y + 1 < h) ? (y_plane + (y + 1) * y_stride) : y0;
        uint8_t* u_row = u_plane + (y >> 1) * u_stride;
        uint8_t* v_row = v_plane + (y >> 1) * v_stride;

        for (uint32_t x = 0; x < w; x += 2) {
            const uint8_t* p00 = row0 + x * 4;
            const uint8_t* p01 = row0 + (x + 1) * 4;
            const uint8_t* p10 = row1 + x * 4;
            const uint8_t* p11 = row1 + (x + 1) * 4;

            int b00 = p00[0], g00 = p00[1], r00 = p00[2];
            int b01 = p01[0], g01 = p01[1], r01 = p01[2];
            int b10 = p10[0], g10 = p10[1], r10 = p10[2];
            int b11 = p11[0], g11 = p11[1], r11 = p11[2];

            y0[x]     = (uint8_t)(((66 * r00 + 129 * g00 + 25 * b00 + 128) >> 8) + 16);
            y0[x + 1] = (uint8_t)(((66 * r01 + 129 * g01 + 25 * b01 + 128) >> 8) + 16);
            y1[x]     = (uint8_t)(((66 * r10 + 129 * g10 + 25 * b10 + 128) >> 8) + 16);
            y1[x + 1] = (uint8_t)(((66 * r11 + 129 * g11 + 25 * b11 + 128) >> 8) + 16);

            int r = (r00 + r01 + r10 + r11) >> 2;
            int g = (g00 + g01 + g10 + g11) >> 2;
            int b = (b00 + b01 + b10 + b11) >> 2;
            u_row[x >> 1] = (uint8_t)(((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128);
            v_row[x >> 1] = (uint8_t)(((112 * r - 94 * g - 18 * b + 128) >> 8) + 128);
        }
    }

    ctx->pic_in.i_pts = ctx->pts++;
    ctx->pic_in.i_type = force_idr ? X264_TYPE_IDR : X264_TYPE_AUTO;

    x264_nal_t* nals = NULL;
    int i_nals = 0;
    int frame_size = x264_encoder_encode(ctx->enc, &nals, &i_nals, &ctx->pic_in, &ctx->pic_out);
    if (frame_size < 0) return frame_size;

    uint32_t total = 0;
    for (int i = 0; i < i_nals; i++) {
        uint32_t nsz = (uint32_t)nals[i].i_payload;
        if (total + nsz <= out_cap) {
            memcpy(out_buf + total, nals[i].p_payload, nsz);
            total += nsz;
        }
    }
    *out_len = total;
    *out_is_idr = ctx->pic_out.b_keyframe ? 1 : 0;
    return 0;
}

void sl_x264_destroy(X264Ctx* ctx) {
    if (!ctx) return;
    if (ctx->enc) x264_encoder_close(ctx->enc);
    x264_picture_clean(&ctx->pic_in);
    free(ctx);
}

// ---- Opus wrapper ----
OpusEncoder* sl_opus_create(int32_t sample_rate, int channels, int bitrate_bps) {
    int err = 0;
    OpusEncoder* enc = opus_encoder_create(sample_rate, channels, OPUS_APPLICATION_RESTRICTED_LOWDELAY, &err);
    if (!enc || err != OPUS_OK) return NULL;
    opus_encoder_ctl(enc, OPUS_SET_BITRATE(bitrate_bps));
    opus_encoder_ctl(enc, OPUS_SET_COMPLEXITY(5));
    opus_encoder_ctl(enc, OPUS_SET_SIGNAL(OPUS_SIGNAL_MUSIC));
    return enc;
}

int sl_opus_encode_float(OpusEncoder* enc, const float* pcm, int frame_size, uint8_t* out, int out_cap) {
    if (!enc) return -1;
    return opus_encode_float(enc, pcm, frame_size, out, out_cap);
}

void sl_opus_destroy(OpusEncoder* enc) {
    if (enc) opus_encoder_destroy(enc);
}
