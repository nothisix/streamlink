#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ref/nvEncodeAPI_12_0.h"

typedef NVENCSTATUS (NVENCAPI *PFN_NvEncodeAPICreateInstance)(NV_ENCODE_API_FUNCTION_LIST*);
typedef NVENCSTATUS (NVENCAPI *PFN_NvEncodeAPIGetMaxSupportedVersion)(uint32_t*);

typedef struct NvencCtx {
    HMODULE dll;
    NV_ENCODE_API_FUNCTION_LIST fn;
    void* encoder;
    ID3D11Device* d3d_dev;
    ID3D11Texture2D* tex_copy;
    NV_ENC_REGISTERED_PTR reg_res;
    NV_ENC_OUTPUT_PTR bs_buf;
    uint32_t width;
    uint32_t height;
    uint32_t fps;
    uint32_t bitrate_bps;
    int is_hevc;
    NV_ENC_INITIALIZE_PARAMS init_params;
    NV_ENC_CONFIG encode_config;
} NvencCtx;

static int guid_eq(const GUID* a, const GUID* b) {
    return memcmp(a, b, sizeof(GUID)) == 0;
}

NvencCtx* nvenc_create(void* d3d11_device_ptr, uint32_t width, uint32_t height, uint32_t fps, uint32_t bitrate_kbps, int is_hevc, char* err_buf, int err_cap) {
    if (!d3d11_device_ptr || width == 0 || height == 0) {
        if (err_buf) snprintf(err_buf, err_cap, "Invalid args");
        return NULL;
    }

    HMODULE dll = LoadLibraryA("nvEncodeAPI64.dll");
    if (!dll) {
        if (err_buf) snprintf(err_buf, err_cap, "nvEncodeAPI64.dll not found");
        return NULL;
    }

    PFN_NvEncodeAPIGetMaxSupportedVersion pGetMaxVer =
        (PFN_NvEncodeAPIGetMaxSupportedVersion)GetProcAddress(dll, "NvEncodeAPIGetMaxSupportedVersion");
    PFN_NvEncodeAPICreateInstance pCreate =
        (PFN_NvEncodeAPICreateInstance)GetProcAddress(dll, "NvEncodeAPICreateInstance");
    if (!pCreate) {
        if (err_buf) snprintf(err_buf, err_cap, "NvEncodeAPICreateInstance missing");
        FreeLibrary(dll);
        return NULL;
    }

    if (pGetMaxVer) {
        uint32_t max_ver = 0;
        if (pGetMaxVer(&max_ver) == NV_ENC_SUCCESS) {
            uint32_t cur_ver = (NVENCAPI_MAJOR_VERSION << 4) | NVENCAPI_MINOR_VERSION;
            if (max_ver < cur_ver) {
                if (err_buf) snprintf(err_buf, err_cap, "Driver NVENC max_ver=0x%x < 0x%x", max_ver, cur_ver);
                FreeLibrary(dll);
                return NULL;
            }
        }
    }

    NvencCtx* ctx = (NvencCtx*)calloc(1, sizeof(NvencCtx));
    if (!ctx) {
        FreeLibrary(dll);
        return NULL;
    }
    ctx->dll = dll;
    ctx->d3d_dev = (ID3D11Device*)d3d11_device_ptr;
    ctx->width = width;
    ctx->height = height;
    ctx->fps = fps > 0 ? fps : 60;
    ctx->bitrate_bps = bitrate_kbps * 1000u;
    ctx->is_hevc = is_hevc ? 1 : 0;

    ctx->fn.version = NV_ENCODE_API_FUNCTION_LIST_VER;
    NVENCSTATUS st = pCreate(&ctx->fn);
    if (st != NV_ENC_SUCCESS) {
        if (err_buf) snprintf(err_buf, err_cap, "NvEncodeAPICreateInstance err=%d", (int)st);
        free(ctx);
        FreeLibrary(dll);
        return NULL;
    }

    NV_ENC_OPEN_ENCODE_SESSION_EX_PARAMS sess_params;
    memset(&sess_params, 0, sizeof(sess_params));
    sess_params.version = NV_ENC_OPEN_ENCODE_SESSION_EX_PARAMS_VER;
    sess_params.deviceType = NV_ENC_DEVICE_TYPE_DIRECTX;
    sess_params.device = d3d11_device_ptr;
    sess_params.apiVersion = NVENCAPI_VERSION;

    st = ctx->fn.nvEncOpenEncodeSessionEx(&sess_params, &ctx->encoder);
    if (st != NV_ENC_SUCCESS || !ctx->encoder) {
        if (err_buf) snprintf(err_buf, err_cap, "nvEncOpenEncodeSessionEx err=%d", (int)st);
        free(ctx);
        FreeLibrary(dll);
        return NULL;
    }

    GUID codec_guid = ctx->is_hevc ? NV_ENC_CODEC_HEVC_GUID : NV_ENC_CODEC_H264_GUID;
    GUID preset_guid = NV_ENC_PRESET_P1_GUID; // Fastest hardware preset for ultra-low latency

    NV_ENC_PRESET_CONFIG preset_cfg;
    memset(&preset_cfg, 0, sizeof(preset_cfg));
    preset_cfg.version = NV_ENC_PRESET_CONFIG_VER;
    preset_cfg.presetCfg.version = NV_ENC_CONFIG_VER;

    st = ctx->fn.nvEncGetEncodePresetConfigEx(
        ctx->encoder,
        codec_guid,
        preset_guid,
        NV_ENC_TUNING_INFO_ULTRA_LOW_LATENCY,
        &preset_cfg
    );
    if (st != NV_ENC_SUCCESS) {
        if (err_buf) snprintf(err_buf, err_cap, "nvEncGetEncodePresetConfigEx err=%d", (int)st);
        ctx->fn.nvEncDestroyEncoder(ctx->encoder);
        free(ctx);
        FreeLibrary(dll);
        return NULL;
    }

    memcpy(&ctx->encode_config, &preset_cfg.presetCfg, sizeof(NV_ENC_CONFIG));
    ctx->encode_config.version = NV_ENC_CONFIG_VER;
    ctx->encode_config.gopLength = NVENC_INFINITE_GOPLENGTH;
    ctx->encode_config.frameIntervalP = 1; // 0 B-frames (IPP...)
    ctx->encode_config.rcParams.rateControlMode = NV_ENC_PARAMS_RC_CBR;
    ctx->encode_config.rcParams.averageBitRate = ctx->bitrate_bps;
    ctx->encode_config.rcParams.maxBitRate = ctx->bitrate_bps;
    ctx->encode_config.rcParams.vbvBufferSize = ctx->bitrate_bps / ctx->fps;
    ctx->encode_config.rcParams.vbvInitialDelay = ctx->encode_config.rcParams.vbvBufferSize;
    ctx->encode_config.rcParams.lowDelayKeyFrameScale = 1;

    if (ctx->is_hevc) {
        ctx->encode_config.profileGUID = NV_ENC_HEVC_PROFILE_MAIN_GUID;
        ctx->encode_config.encodeCodecConfig.hevcConfig.idrPeriod = NVENC_INFINITE_GOPLENGTH;
        ctx->encode_config.encodeCodecConfig.hevcConfig.repeatSPSPPS = 1;
        ctx->encode_config.encodeCodecConfig.hevcConfig.chromaFormatIDC = 1;
    } else {
        ctx->encode_config.profileGUID = NV_ENC_H264_PROFILE_HIGH_GUID;
        ctx->encode_config.encodeCodecConfig.h264Config.idrPeriod = NVENC_INFINITE_GOPLENGTH;
        ctx->encode_config.encodeCodecConfig.h264Config.repeatSPSPPS = 1;
        ctx->encode_config.encodeCodecConfig.h264Config.chromaFormatIDC = 1;
        ctx->encode_config.encodeCodecConfig.h264Config.entropyCodingMode = NV_ENC_H264_ENTROPY_CODING_MODE_CABAC;
    }

    memset(&ctx->init_params, 0, sizeof(ctx->init_params));
    ctx->init_params.version = NV_ENC_INITIALIZE_PARAMS_VER;
    ctx->init_params.encodeGUID = codec_guid;
    ctx->init_params.presetGUID = preset_guid;
    ctx->init_params.encodeWidth = width;
    ctx->init_params.encodeHeight = height;
    ctx->init_params.darWidth = width;
    ctx->init_params.darHeight = height;
    ctx->init_params.frameRateNum = ctx->fps;
    ctx->init_params.frameRateDen = 1;
    ctx->init_params.enablePTD = 1;
    ctx->init_params.enableEncodeAsync = 0;
    ctx->init_params.encodeConfig = &ctx->encode_config;
    ctx->init_params.maxEncodeWidth = width;
    ctx->init_params.maxEncodeHeight = height;
    ctx->init_params.tuningInfo = NV_ENC_TUNING_INFO_ULTRA_LOW_LATENCY;

    st = ctx->fn.nvEncInitializeEncoder(ctx->encoder, &ctx->init_params);
    if (st != NV_ENC_SUCCESS) {
        if (err_buf) snprintf(err_buf, err_cap, "nvEncInitializeEncoder err=%d", (int)st);
        ctx->fn.nvEncDestroyEncoder(ctx->encoder);
        free(ctx);
        FreeLibrary(dll);
        return NULL;
    }

    // Create dedicated GPU texture owned by our session and register once (zero-copy GPU->GPU)
    D3D11_TEXTURE2D_DESC desc;
    memset(&desc, 0, sizeof(desc));
    desc.Width = width;
    desc.Height = height;
    desc.MipLevels = 1;
    desc.ArraySize = 1;
    desc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.Usage = D3D11_USAGE_DEFAULT;
    desc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;

    HRESULT hr = ctx->d3d_dev->lpVtbl->CreateTexture2D(ctx->d3d_dev, &desc, NULL, &ctx->tex_copy);
    if (FAILED(hr) || !ctx->tex_copy) {
        if (err_buf) snprintf(err_buf, err_cap, "CreateTexture2D failed hr=0x%08lx", (unsigned long)hr);
        ctx->fn.nvEncDestroyEncoder(ctx->encoder);
        free(ctx);
        FreeLibrary(dll);
        return NULL;
    }

    NV_ENC_REGISTER_RESOURCE reg;
    memset(&reg, 0, sizeof(reg));
    reg.version = NV_ENC_REGISTER_RESOURCE_VER;
    reg.resourceType = NV_ENC_INPUT_RESOURCE_TYPE_DIRECTX;
    reg.width = width;
    reg.height = height;
    reg.pitch = 0;
    reg.subResourceIndex = 0;
    reg.resourceToRegister = (void*)ctx->tex_copy;
    reg.bufferFormat = NV_ENC_BUFFER_FORMAT_ARGB;
    reg.bufferUsage = NV_ENC_INPUT_IMAGE;

    st = ctx->fn.nvEncRegisterResource(ctx->encoder, &reg);
    if (st != NV_ENC_SUCCESS) {
        if (err_buf) snprintf(err_buf, err_cap, "nvEncRegisterResource err=%d", (int)st);
        ctx->tex_copy->lpVtbl->Release(ctx->tex_copy);
        ctx->fn.nvEncDestroyEncoder(ctx->encoder);
        free(ctx);
        FreeLibrary(dll);
        return NULL;
    }
    ctx->reg_res = reg.registeredResource;

    NV_ENC_CREATE_BITSTREAM_BUFFER bs;
    memset(&bs, 0, sizeof(bs));
    bs.version = NV_ENC_CREATE_BITSTREAM_BUFFER_VER;
    st = ctx->fn.nvEncCreateBitstreamBuffer(ctx->encoder, &bs);
    if (st != NV_ENC_SUCCESS) {
        if (err_buf) snprintf(err_buf, err_cap, "nvEncCreateBitstreamBuffer err=%d", (int)st);
        ctx->fn.nvEncUnregisterResource(ctx->encoder, ctx->reg_res);
        ctx->tex_copy->lpVtbl->Release(ctx->tex_copy);
        ctx->fn.nvEncDestroyEncoder(ctx->encoder);
        free(ctx);
        FreeLibrary(dll);
        return NULL;
    }
    ctx->bs_buf = bs.bitstreamBuffer;

    return ctx;
}

void* nvenc_input_texture(NvencCtx* ctx) {
    return ctx ? (void*)ctx->tex_copy : NULL;
}

int nvenc_reconfigure_bitrate(NvencCtx* ctx, uint32_t bitrate_kbps) {
    if (!ctx) return -1;
    uint32_t bps = bitrate_kbps * 1000u;
    if (bps == ctx->bitrate_bps) return 0;
    ctx->bitrate_bps = bps;
    ctx->encode_config.rcParams.averageBitRate = bps;
    ctx->encode_config.rcParams.maxBitRate = bps;
    ctx->encode_config.rcParams.vbvBufferSize = bps / (ctx->fps > 0 ? ctx->fps : 60);
    ctx->encode_config.rcParams.vbvInitialDelay = ctx->encode_config.rcParams.vbvBufferSize;

    NV_ENC_RECONFIGURE_PARAMS rec;
    memset(&rec, 0, sizeof(rec));
    rec.version = NV_ENC_RECONFIGURE_PARAMS_VER;
    memcpy(&rec.reInitEncodeParams, &ctx->init_params, sizeof(NV_ENC_INITIALIZE_PARAMS));
    rec.reInitEncodeParams.encodeConfig = &ctx->encode_config;

    NVENCSTATUS st = ctx->fn.nvEncReconfigureEncoder(ctx->encoder, &rec);
    return (st == NV_ENC_SUCCESS) ? 0 : -(int)st;
}

int nvenc_encode_frame(NvencCtx* ctx, uint64_t pts_us, int force_idr, uint8_t* out_buf, uint32_t out_cap, uint32_t* out_len, int* out_is_idr) {
    if (!ctx || !out_buf || !out_len || !out_is_idr) return -1;
    *out_len = 0;
    *out_is_idr = 0;

    NV_ENC_MAP_INPUT_RESOURCE map;
    memset(&map, 0, sizeof(map));
    map.version = NV_ENC_MAP_INPUT_RESOURCE_VER;
    map.registeredResource = ctx->reg_res;
    NVENCSTATUS st = ctx->fn.nvEncMapInputResource(ctx->encoder, &map);
    if (st != NV_ENC_SUCCESS) {
        return -(int)st;
    }

    NV_ENC_PIC_PARAMS pic;
    memset(&pic, 0, sizeof(pic));
    pic.version = NV_ENC_PIC_PARAMS_VER;
    pic.inputWidth = ctx->width;
    pic.inputHeight = ctx->height;
    pic.inputPitch = ctx->width;
    pic.inputTimeStamp = pts_us;
    pic.inputBuffer = map.mappedResource;
    pic.outputBitstream = ctx->bs_buf;
    pic.bufferFmt = map.mappedBufferFmt;
    pic.pictureStruct = NV_ENC_PIC_STRUCT_FRAME;
    if (force_idr) {
        pic.encodePicFlags = NV_ENC_PIC_FLAG_FORCEIDR | NV_ENC_PIC_FLAG_OUTPUT_SPSPPS;
    }

    st = ctx->fn.nvEncEncodePicture(ctx->encoder, &pic);
    if (st != NV_ENC_SUCCESS) {
        ctx->fn.nvEncUnmapInputResource(ctx->encoder, map.mappedResource);
        return -(int)st;
    }

    NV_ENC_LOCK_BITSTREAM lock;
    memset(&lock, 0, sizeof(lock));
    lock.version = NV_ENC_LOCK_BITSTREAM_VER;
    lock.outputBitstream = ctx->bs_buf;
    st = ctx->fn.nvEncLockBitstream(ctx->encoder, &lock);
    if (st == NV_ENC_SUCCESS) {
        uint32_t sz = lock.bitstreamSizeInBytes;
        if (sz <= out_cap && lock.bitstreamBufferPtr) {
            memcpy(out_buf, lock.bitstreamBufferPtr, sz);
            *out_len = sz;
            *out_is_idr = (lock.pictureType == NV_ENC_PIC_TYPE_IDR) ? 1 : 0;
        }
        ctx->fn.nvEncUnlockBitstream(ctx->encoder, ctx->bs_buf);
    }

    ctx->fn.nvEncUnmapInputResource(ctx->encoder, map.mappedResource);
    return (st == NV_ENC_SUCCESS) ? 0 : -(int)st;
}

void nvenc_destroy(NvencCtx* ctx) {
    if (!ctx) return;
    if (ctx->encoder) {
        if (ctx->bs_buf) ctx->fn.nvEncDestroyBitstreamBuffer(ctx->encoder, ctx->bs_buf);
        if (ctx->reg_res) ctx->fn.nvEncUnregisterResource(ctx->encoder, ctx->reg_res);
        ctx->fn.nvEncDestroyEncoder(ctx->encoder);
    }
    if (ctx->tex_copy) ctx->tex_copy->lpVtbl->Release(ctx->tex_copy);
    if (ctx->dll) FreeLibrary(ctx->dll);
    free(ctx);
}
