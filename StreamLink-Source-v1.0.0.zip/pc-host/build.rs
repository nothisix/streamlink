fn main() {
    println!("cargo:rerun-if-changed=native/nvenc_shim.c");
    println!("cargo:rerun-if-changed=native/x264_opus_shim.c");

    let target_os = std::env::var("CARGO_CFG_TARGET_OS").unwrap_or_default();
    let target_env = std::env::var("CARGO_CFG_TARGET_ENV").unwrap_or_default();
    let mingw_inc = "C:/msys64/mingw64/include";
    let mingw_lib = "C:/msys64/mingw64/lib";

    let mut build = cc::Build::new();
    build.file("native/x264_opus_shim.c");
    if target_os == "windows" {
        build.include(mingw_inc);
    }
    build.warnings(false);
    // Compile shims BEFORE emitting -lx264 / -lopus so GNU ld resolves symbols cleanly
    build.compile("x264_opus_shim");

    if target_os == "windows" {
        let mut nv = cc::Build::new();
        nv.file("native/nvenc_shim.c")
            .include("ref")
            .include(mingw_inc)
            .warnings(false);
        nv.compile("nvenc_shim");

        println!("cargo:rustc-link-search=native={mingw_lib}");
        println!("cargo:rustc-link-lib=static=x264");
        println!("cargo:rustc-link-lib=static=opus");
        println!("cargo:rustc-link-lib=dxgi");
        println!("cargo:rustc-link-lib=d3d11");
        println!("cargo:rustc-link-lib=setupapi");

        if target_env == "gnu" {
            println!("cargo:rustc-link-arg=-static-libgcc");
            println!("cargo:rustc-link-arg=-Wl,-Bstatic");
            println!("cargo:rustc-link-arg=-lwinpthread");
            println!("cargo:rustc-link-arg=-Wl,-Bdynamic");
        }
    } else {
        let _ = pkg_config::Config::new().probe("x264");
        let _ = pkg_config::Config::new().probe("opus");
    }
}
