package com.streamlink.client.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class DiscoveredHost(
    val name: String,
    val ip: String,
    val port: Int,
    val supportsHevc: Boolean,
    val lastSeenMs: Long = System.currentTimeMillis()
)

class HostDiscovery(private val context: Context) {
    private val _hosts = MutableStateFlow<List<DiscoveredHost>>(emptyList())
    val hosts: StateFlow<List<DiscoveredHost>> = _hosts

    private var scanJob: Job? = null
    private var nsdManager: NsdManager? = null
    private var nsdListener: NsdManager.DiscoveryListener? = null

    fun start(scope: CoroutineScope) {
        stop()
        startNsd()
        scanJob = scope.launch(Dispatchers.IO) {
            var sock: DatagramSocket? = null
            try {
                sock = DatagramSocket().apply {
                    broadcast = true
                    soTimeout = 350
                }
                val recvBuf = ByteArray(256)
                while (isActive) {
                    sendProbes(sock)
                    val deadline = System.currentTimeMillis() + 500
                    while (System.currentTimeMillis() < deadline && isActive) {
                        try {
                            val pkt = DatagramPacket(recvBuf, recvBuf.size)
                            sock.receive(pkt)
                            parseProbeResponse(pkt)?.let { upsertHost(it) }
                        } catch (_: Exception) {
                            break
                        }
                    }
                    // Prune stale LAN hosts > 8s old
                    val now = System.currentTimeMillis()
                    _hosts.value = _hosts.value.filter { now - it.lastSeenMs < 8000 }
                    delay(450)
                }
            } catch (_: Exception) {
            } finally {
                sock?.close()
            }
        }
    }

    fun stop() {
        scanJob?.cancel()
        scanJob = null
        try {
            nsdListener?.let { nsdManager?.stopServiceDiscovery(it) }
        } catch (_: Exception) {
        }
        nsdListener = null
    }

    private fun sendProbes(sock: DatagramSocket) {
        val probe = Protocol.DISCOVER_PROBE_MAGIC
        val targets = mutableSetOf<InetAddress>()
        try {
            targets.add(InetAddress.getByName("255.255.255.255"))
            val ifaces = NetworkInterface.getNetworkInterfaces()
            while (ifaces.hasMoreElements()) {
                val iface = ifaces.nextElement()
                if (!iface.isUp || iface.isLoopback) continue
                for (addr in iface.interfaceAddresses) {
                    addr.broadcast?.let { targets.add(it) }
                }
            }
        } catch (_: Exception) {
        }
        for (addr in targets) {
            try {
                sock.send(DatagramPacket(probe, probe.size, addr, Protocol.DEFAULT_DISCOVERY_PORT))
            } catch (_: Exception) {
            }
        }
    }

    private fun parseProbeResponse(pkt: DatagramPacket): DiscoveredHost? {
        val data = pkt.data
        val len = pkt.length
        val magic = Protocol.DISCOVER_RESP_MAGIC
        if (len < magic.size + 4) return null
        for (i in magic.indices) {
            if (data[i] != magic[i]) return null
        }
        val bb = ByteBuffer.wrap(data, magic.size, len - magic.size).order(ByteOrder.BIG_ENDIAN)
        val port = bb.short.toInt() and 0xFFFF
        val codecMask = bb.get().toInt() and 0xFF
        val nameLen = (bb.get().toInt() and 0xFF).coerceAtMost(bb.remaining())
        val nameBytes = ByteArray(nameLen)
        bb.get(nameBytes)
        val ip = pkt.address.hostAddress ?: return null
        return DiscoveredHost(
            name = nameBytes.decodeToString(),
            ip = ip,
            port = port,
            supportsHevc = (codecMask and 0x02) != 0
        )
    }

    private fun startNsd() {
        try {
            val mgr = context.getSystemService(Context.NSD_SERVICE) as? NsdManager ?: return
            nsdManager = mgr
            val listener = object : NsdManager.DiscoveryListener {
                override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) {}
                override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) {}
                override fun onDiscoveryStarted(serviceType: String?) {}
                override fun onDiscoveryStopped(serviceType: String?) {}
                override fun onServiceLost(serviceInfo: NsdServiceInfo?) {}
                override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                    @Suppress("DEPRECATION")
                    mgr.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(si: NsdServiceInfo?, errorCode: Int) {}
                        override fun onServiceResolved(si: NsdServiceInfo) {
                            val ip = si.host?.hostAddress ?: return
                            val port = if (si.port > 0) si.port else Protocol.DEFAULT_STREAM_PORT
                            upsertHost(
                                DiscoveredHost(
                                    name = si.serviceName ?: "StreamLink-PC",
                                    ip = ip,
                                    port = port,
                                    supportsHevc = true
                                )
                            )
                        }
                    })
                }
            }
            nsdListener = listener
            mgr.discoverServices("_streamlink._udp.", NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (_: Exception) {
        }
    }

    private fun upsertHost(host: DiscoveredHost) {
        val list = _hosts.value.toMutableList()
        val idx = list.indexOfFirst { it.ip == host.ip && it.port == host.port }
        if (idx >= 0) {
            list[idx] = host
        } else {
            list.add(host)
        }
        _hosts.value = list
    }
}
