package com.streamlink.client.media

import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Build
import android.view.Surface
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Hardware MediaCodec decoder outputting directly to a SurfaceView Surface
 * with Android 11+ KEY_LOW_LATENCY, vendor low-latency flags, Surface.setFrameRate lock,
 * and immediate buffer drop if a frame misses its VSync render deadline.
 */
class VideoDecoderRenderer {
    private val running = AtomicBoolean(false)
    private var surface: Surface? = null
    private var codecType: Int = 0 // 0=H264, 1=HEVC
    private var width: Int = 1920
    private var height: Int = 1080
    private var targetFps: Int = 60

    private data class EncodedFrame(val data: ByteArray, val isIdr: Boolean, val enqueueNs: Long)

    // Tiny bounded queue; stale frames are immediately evicted so screen always shows newest frame
    private val frameQueue = ArrayBlockingQueue<EncodedFrame>(3)
    private var decodeThread: Thread? = null
    private var hasReceivedIdr = false

    val lastDecodeTimeUs = AtomicInteger(0)
    private val framesRenderedCounter = AtomicInteger(0)
    private val lastFpsSampleMs = AtomicLong(System.currentTimeMillis())
    val measuredFps = AtomicInteger(0)

    @Synchronized
    fun configure(surface: Surface, isHevc: Boolean, w: Int, h: Int, fps: Int) {
        stop()
        this.surface = surface
        this.codecType = if (isHevc) 1 else 0
        this.width = w.coerceAtLeast(320)
        this.height = h.coerceAtLeast(240)
        this.targetFps = fps.coerceIn(30, 120)
        this.hasReceivedIdr = false

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                surface.setFrameRate(
                    this.targetFps.toFloat(),
                    Surface.FRAME_RATE_COMPATIBILITY_DEFAULT
                )
            } catch (_: Exception) {
            }
        }

        running.set(true)
        decodeThread = Thread({ decoderLoop() }, "streamlink-mediacodec").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun submitFrame(nalData: ByteArray, isIdr: Boolean) {
        if (!running.get() || nalData.isEmpty()) return
        if (!hasReceivedIdr) {
            if (!isIdr) return
            hasReceivedIdr = true
        }
        val item = EncodedFrame(nalData, isIdr, System.nanoTime())
        // Strict frame-drop pacing: if queue already has frames waiting, drop stale non-IDR frames
        while (!frameQueue.offer(item)) {
            val dropped = frameQueue.poll()
            if (dropped != null && dropped.isIdr && !isIdr) {
                frameQueue.offer(dropped)
                return
            }
        }
    }

    @Synchronized
    fun stop() {
        running.set(false)
        frameQueue.clear()
        try {
            decodeThread?.join(400)
        } catch (_: InterruptedException) {
        }
        decodeThread = null
    }

    private fun decoderLoop() {
        var codec: MediaCodec? = null
        try {
            val mime = if (codecType == 1) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
            val format = MediaFormat.createVideoFormat(mime, width, height).apply {
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 2 * 1024 * 1024)
                setInteger(MediaFormat.KEY_OPERATING_RATE, targetFps)
                setInteger(MediaFormat.KEY_PRIORITY, 0) // real-time priority
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
                }
                // Vendor low-latency hints (Qualcomm / MediaTek / Exynos)
                setInteger("low-latency", 1)
                setInteger("vendor.qti-ext-dec-low-latency.enable", 1)
                setInteger("vendor.rtc-ext-dec-low-latency.enable", 1)
                setInteger("vendor.low-latency.enable", 1)
            }

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, surface, null, 0)
            codec.start()

            val bufInfo = MediaCodec.BufferInfo()
            var ptsUs = 0L
            val vsyncBudgetNs = 1_000_000_000L / targetFps.toLong()
            var lastRenderNs = System.nanoTime()

            while (running.get()) {
                val frame = frameQueue.poll()
                if (frame != null) {
                    val inIdx = codec.dequeueInputBuffer(3000)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)
                        inBuf?.clear()
                        inBuf?.put(frame.data)
                        val flags = if (frame.isIdr) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                        codec.queueInputBuffer(inIdx, 0, frame.data.size, ptsUs, flags)
                        ptsUs += (1_000_000L / targetFps)
                    }
                } else {
                    Thread.sleep(1)
                }

                // Drain all decoded output buffers; drop older or VSync-missed frames immediately
                var latestOutIdx = -1
                var latestPts = 0L
                while (running.get()) {
                    val outIdx = codec.dequeueOutputBuffer(bufInfo, 0)
                    if (outIdx >= 0) {
                        if (latestOutIdx >= 0) {
                            codec.releaseOutputBuffer(latestOutIdx, false)
                        }
                        latestOutIdx = outIdx
                        latestPts = System.nanoTime()
                    } else {
                        break
                    }
                }

                if (latestOutIdx >= 0) {
                    val missedVsyncAndNewerPending =
                        (latestPts - lastRenderNs) > (vsyncBudgetNs * 2L) && frameQueue.isNotEmpty()
                    if (missedVsyncAndNewerPending) {
                        codec.releaseOutputBuffer(latestOutIdx, false)
                    } else {
                        codec.releaseOutputBuffer(latestOutIdx, true)
                        lastRenderNs = latestPts
                    }
                    if (frame != null) {
                        val decUs = ((latestPts - frame.enqueueNs) / 1000L).toInt().coerceIn(0, 100_000)
                        lastDecodeTimeUs.set(decUs)
                    }
                    val cnt = framesRenderedCounter.incrementAndGet()
                    val nowMs = System.currentTimeMillis()
                    val prevMs = lastFpsSampleMs.get()
                    if (nowMs - prevMs >= 1000L) {
                        measuredFps.set(cnt)
                        framesRenderedCounter.set(0)
                        lastFpsSampleMs.set(nowMs)
                    }
                }
            }
        } catch (_: Throwable) {
            hasReceivedIdr = false
        } finally {
            try { codec?.stop(); codec?.release() } catch (_: Exception) {}
        }
    }
}
