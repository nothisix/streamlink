package com.streamlink.client.ui

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private object WinVk {
    const val BACK = 0x08
    const val TAB = 0x09
    const val RETURN = 0x0D
    const val SHIFT = 0x10
    const val CONTROL = 0x11
    const val MENU = 0x12 // ALT
    const val ESCAPE = 0x1B
    const val SPACE = 0x20
    const val LEFT = 0x25
    const val UP = 0x26
    const val RIGHT = 0x27
    const val DOWN = 0x28
    const val DELETE = 0x2E
    const val LWIN = 0x5B
    const val F1 = 0x70
    const val F2 = 0x71
    const val F3 = 0x72
    const val F4 = 0x73
    const val F5 = 0x74
}

/**
 * Hidden native Android View acting as an IME InputConnection bridge so users get the full
 * device keyboard (Gboard / SwiftKey / AOSP) while also providing a compact 1-row PC modifier strip.
 */
class StreamImeView(
    context: Context,
    private val onSendKey: (vk: Int, scan: Int, down: Boolean) -> Unit
) : View(context) {

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun onCheckIsTextEditor(): Boolean = true

    private fun tapVk(vk: Int) {
        onSendKey(vk, 0, true)
        onSendKey(vk, 0, false)
    }

    private fun sendChar(ch: Char) {
        when (ch) {
            '\n', '\r' -> tapVk(WinVk.RETURN)
            '\t' -> tapVk(WinVk.TAB)
            ' ' -> tapVk(WinVk.SPACE)
            in 'a'..'z' -> tapVk(ch.uppercaseChar().code)
            in 'A'..'Z' -> {
                onSendKey(WinVk.SHIFT, 0, true)
                tapVk(ch.code)
                onSendKey(WinVk.SHIFT, 0, false)
            }
            in '0'..'9' -> tapVk(ch.code)
            else -> {
                // Uses Win32 KEYEVENTF_UNICODE on host when vk == 0 && scan != 0
                val code = ch.code
                if (code > 0) {
                    onSendKey(0, code, true)
                    onSendKey(0, code, false)
                }
            }
        }
    }

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        outAttrs.imeOptions = EditorInfo.IME_ACTION_NONE or
            EditorInfo.IME_FLAG_NO_EXTRACT_UI or
            EditorInfo.IME_FLAG_NO_FULLSCREEN

        return object : BaseInputConnection(this, false) {
            private var prevComposing = ""

            override fun setComposingText(text: CharSequence?, newCursorPosition: Int): Boolean {
                val next = text?.toString() ?: ""
                if (next != prevComposing) {
                    // Replace previous composing characters cleanly with backspaces + new chars
                    var common = 0
                    val minLen = minOf(prevComposing.length, next.length)
                    while (common < minLen && prevComposing[common] == next[common]) {
                        common++
                    }
                    val deletes = prevComposing.length - common
                    repeat(deletes) { tapVk(WinVk.BACK) }
                    for (i in common until next.length) {
                        sendChar(next[i])
                    }
                    prevComposing = next
                }
                return true
            }

            override fun finishComposingText(): Boolean {
                prevComposing = ""
                return true
            }

            override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
                val next = text?.toString() ?: ""
                if (prevComposing.isNotEmpty()) {
                    var common = 0
                    val minLen = minOf(prevComposing.length, next.length)
                    while (common < minLen && prevComposing[common] == next[common]) {
                        common++
                    }
                    repeat(prevComposing.length - common) { tapVk(WinVk.BACK) }
                    for (i in common until next.length) {
                        sendChar(next[i])
                    }
                    prevComposing = ""
                } else {
                    for (ch in next) {
                        sendChar(ch)
                    }
                }
                return true
            }

            override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
                if (prevComposing.isNotEmpty()) {
                    val drop = minOf(beforeLength, prevComposing.length)
                    prevComposing = prevComposing.dropLast(drop)
                }
                repeat(beforeLength.coerceAtLeast(1)) {
                    tapVk(WinVk.BACK)
                }
                return true
            }

            override fun sendKeyEvent(event: KeyEvent): Boolean {
                val isDown = when (event.action) {
                    KeyEvent.ACTION_DOWN -> true
                    KeyEvent.ACTION_UP -> false
                    else -> return super.sendKeyEvent(event)
                }
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DEL -> onSendKey(WinVk.BACK, 0, isDown)
                    KeyEvent.KEYCODE_FORWARD_DEL -> onSendKey(WinVk.DELETE, 0, isDown)
                    KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> onSendKey(WinVk.RETURN, 0, isDown)
                    KeyEvent.KEYCODE_TAB -> onSendKey(WinVk.TAB, 0, isDown)
                    KeyEvent.KEYCODE_ESCAPE -> onSendKey(WinVk.ESCAPE, 0, isDown)
                    KeyEvent.KEYCODE_DPAD_LEFT -> onSendKey(WinVk.LEFT, 0, isDown)
                    KeyEvent.KEYCODE_DPAD_UP -> onSendKey(WinVk.UP, 0, isDown)
                    KeyEvent.KEYCODE_DPAD_RIGHT -> onSendKey(WinVk.RIGHT, 0, isDown)
                    KeyEvent.KEYCODE_DPAD_DOWN -> onSendKey(WinVk.DOWN, 0, isDown)
                    else -> {
                        if (isDown && event.unicodeChar != 0) {
                            sendChar(event.unicodeChar.toChar())
                        }
                    }
                }
                return true
            }

            override fun performEditorAction(editorAction: Int): Boolean {
                tapVk(WinVk.RETURN)
                return true
            }
        }
    }
}

@Composable
fun ImeKeyboardBridge(
    onKey: (vk: Int, scan: Int, down: Boolean) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val currentOnKey by rememberUpdatedState(onKey)
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    var imeViewRef by remember { mutableStateOf<StreamImeView?>(null) }

    var ctrlHeld by remember { mutableStateOf(false) }
    var altHeld by remember { mutableStateOf(false) }
    var shiftHeld by remember { mutableStateOf(false) }
    var winHeld by remember { mutableStateOf(false) }

    fun releaseLatchedModifiers() {
        if (ctrlHeld) {
            currentOnKey(WinVk.CONTROL, 0, false)
            ctrlHeld = false
        }
        if (altHeld) {
            currentOnKey(WinVk.MENU, 0, false)
            altHeld = false
        }
        if (shiftHeld) {
            currentOnKey(WinVk.SHIFT, 0, false)
            shiftHeld = false
        }
        if (winHeld) {
            currentOnKey(WinVk.LWIN, 0, false)
            winHeld = false
        }
    }

    fun showNativeKeyboard(view: View) {
        view.requestFocus()
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    DisposableEffect(Unit) {
        onDispose {
            releaseLatchedModifiers()
            val v = imeViewRef
            if (v != null) {
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                imm?.hideSoftInputFromWindow(v.windowToken, 0)
                v.clearFocus()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
    ) {
        // 1dp transparent focus anchor hosting the Android soft keyboard InputConnection
        AndroidView(
            modifier = Modifier
                .size(1.dp)
                .align(Alignment.BottomStart),
            factory = { ctx ->
                StreamImeView(ctx) { vk, scan, down ->
                    currentOnKey(vk, scan, down)
                }.also { view ->
                    imeViewRef = view
                    mainHandler.postDelayed({ showNativeKeyboard(view) }, 60L)
                }
            }
        )

        // Compact 1-row industrial PC special-key & sticky modifier strip docked above IME
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(IndustrialColors.ObsidianBg.copy(alpha = 0.96f))
                .border(1.dp, IndustrialColors.ObsidianBorder)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SpecKeyChip("IME", accent = true) {
                imeViewRef?.let { showNativeKeyboard(it) }
            }
            ModToggleChip("CTRL", ctrlHeld) {
                ctrlHeld = !ctrlHeld
                currentOnKey(WinVk.CONTROL, 0, ctrlHeld)
            }
            ModToggleChip("ALT", altHeld) {
                altHeld = !altHeld
                currentOnKey(WinVk.MENU, 0, altHeld)
            }
            ModToggleChip("SHIFT", shiftHeld) {
                shiftHeld = !shiftHeld
                currentOnKey(WinVk.SHIFT, 0, shiftHeld)
            }
            ModToggleChip("WIN", winHeld) {
                winHeld = !winHeld
                currentOnKey(WinVk.LWIN, 0, winHeld)
            }

            Box(Modifier.width(1.dp).height(18.dp).background(IndustrialColors.ObsidianBorder))

            val tapKeys = listOf(
                "ESC" to WinVk.ESCAPE,
                "TAB" to WinVk.TAB,
                "DEL" to WinVk.DELETE,
                "←" to WinVk.LEFT,
                "↑" to WinVk.UP,
                "↓" to WinVk.DOWN,
                "→" to WinVk.RIGHT,
                "F1" to WinVk.F1,
                "F2" to WinVk.F2,
                "F3" to WinVk.F3,
                "F4" to WinVk.F4,
                "F5" to WinVk.F5
            )
            for ((label, vk) in tapKeys) {
                SpecKeyChip(label) {
                    currentOnKey(vk, 0, true)
                    currentOnKey(vk, 0, false)
                }
            }

            Spacer(Modifier.width(4.dp))
            SpecKeyChip("CLOSE", accent = true) {
                releaseLatchedModifiers()
                onClose()
            }
        }
    }
}

@Composable
private fun ModToggleChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                if (active) IndustrialColors.SignalOrange else IndustrialColors.ObsidianCard,
                RoundedCornerShape(2.dp)
            )
            .border(
                1.dp,
                if (active) IndustrialColors.SignalOrange else IndustrialColors.ObsidianBorder,
                RoundedCornerShape(2.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 5.dp)
    ) {
        Text(
            label,
            color = if (active) IndustrialColors.ObsidianBg else IndustrialColors.Cream,
            fontFamily = JetBrainsMonoFamily,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun SpecKeyChip(label: String, accent: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(IndustrialColors.ObsidianCard, RoundedCornerShape(2.dp))
            .border(
                1.dp,
                if (accent) IndustrialColors.SignalOrange else IndustrialColors.ObsidianBorder,
                RoundedCornerShape(2.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 5.dp)
    ) {
        Text(
            label,
            color = if (accent) IndustrialColors.SignalOrange else IndustrialColors.Cream,
            fontFamily = JetBrainsMonoFamily,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
