package com.streamlink.client.ui

import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.streamlink.client.R
import com.streamlink.client.net.DiscoveredHost
import com.streamlink.client.net.Protocol

@Composable
fun PairingScreen(
    discoveredHosts: List<DiscoveredHost>,
    statusMessage: String,
    connecting: Boolean,
    onConnect: (ip: String, port: Int, pin: String, preferHevc: Boolean, maxFps: Int) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("streamlink_pairing", Context.MODE_PRIVATE) }

    var hostIp by remember { mutableStateOf(prefs.getString("last_ip", "") ?: "") }
    var hostPort by remember { mutableStateOf(prefs.getString("last_port", Protocol.DEFAULT_STREAM_PORT.toString()) ?: Protocol.DEFAULT_STREAM_PORT.toString()) }
    var pin by remember { mutableStateOf(prefs.getString("last_pin", "") ?: "") }
    var preferHevc by remember { mutableStateOf(false) }
    var maxFps by remember { mutableStateOf(60) }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialColors.ObsidianBg)
            .padding(18.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Panel: Discovered LAN Hosts
        Column(
            modifier = Modifier
                .weight(0.46f)
                .fillMaxHeight()
                .background(IndustrialColors.ObsidianCard, RoundedCornerShape(2.dp))
                .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(IndustrialColors.SignalOrange, CircleShape)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "STREAMLINK // LAN RADAR",
                    color = IndustrialColors.Cream,
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "AUTO-SCANNING mDNS + UDP 47990",
                color = IndustrialColors.Muted,
                fontFamily = JetBrainsMonoFamily,
                fontSize = 10.sp
            )
            Spacer(Modifier.height(12.dp))

            if (discoveredHosts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "SEARCHING FOR PC HOST...\nUSE DIRECT IP FOR TAILSCALE / TUNNELS",
                        color = IndustrialColors.Muted,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 11.sp
                    )
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(discoveredHosts) { h ->
                        val selected = hostIp == h.ip && hostPort == h.port.toString()
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (selected) IndustrialColors.ObsidianBorder else IndustrialColors.ObsidianBg,
                                    RoundedCornerShape(2.dp)
                                )
                                .border(
                                    1.dp,
                                    if (selected) IndustrialColors.SignalOrange else IndustrialColors.ObsidianBorder,
                                    RoundedCornerShape(2.dp)
                                )
                                .clickable {
                                    hostIp = h.ip
                                    hostPort = h.port.toString()
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    h.name.uppercase(),
                                    color = IndustrialColors.Cream,
                                    fontFamily = SpaceGroteskFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    "${h.ip}:${h.port}",
                                    color = IndustrialColors.Muted,
                                    fontFamily = JetBrainsMonoFamily,
                                    fontSize = 11.sp
                                )
                            }
                            Icon(
                                painter = painterResource(R.drawable.ic_wifi),
                                contentDescription = null,
                                tint = IndustrialColors.Cream,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        // Right Panel: Direct Endpoint, PIN & Link Config
        Column(
            modifier = Modifier
                .weight(0.54f)
                .fillMaxHeight()
                .background(IndustrialColors.ObsidianCard, RoundedCornerShape(2.dp))
                .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "PAIRING TERMINAL",
                        color = IndustrialColors.Cream,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                            .clickable {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                val clip = cm?.primaryClip?.getItemAt(0)?.text?.toString() ?: return@clickable
                                val uri = Uri.parse(clip.trim())
                                if (uri.scheme == "streamlink") {
                                    uri.getQueryParameter("ip")?.let { hostIp = it.trim() }
                                    uri.getQueryParameter("port")?.let { hostPort = it.filter { c -> c in '0'..'9' } }
                                    uri.getQueryParameter("pin")?.let { pin = it.filter { c -> c in '0'..'9' }.take(4) }
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            "PASTE PAIR URI",
                            color = IndustrialColors.Cream,
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 10.sp
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IndustrialInputField(
                        label = "HOST IP / TUNNEL",
                        value = hostIp,
                        onValueChange = { hostIp = it.trim() },
                        placeholder = "192.168.1.10",
                        keyboardType = KeyboardType.Ascii,
                        modifier = Modifier.weight(0.7f)
                    )
                    IndustrialInputField(
                        label = "PORT",
                        value = hostPort,
                        onValueChange = { hostPort = it.filter { ch -> ch in '0'..'9' }.take(5) },
                        placeholder = "47991",
                        keyboardType = KeyboardType.Number,
                        modifier = Modifier.weight(0.3f)
                    )
                }

                IndustrialInputField(
                    label = "4-DIGIT PAIRING PIN",
                    value = pin,
                    onValueChange = { pin = it.filter { ch -> ch in '0'..'9' }.take(4) },
                    placeholder = "0000",
                    keyboardType = KeyboardType.Number,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "CODEC",
                        color = IndustrialColors.Muted,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 10.sp
                    )
                    ToggleChip("H.264", !preferHevc) { preferHevc = false }
                    ToggleChip("HEVC", preferHevc) { preferHevc = true }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "HZ",
                        color = IndustrialColors.Muted,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 10.sp
                    )
                    for (fps in listOf(60, 90, 120)) {
                        ToggleChip("$fps", maxFps == fps) { maxFps = fps }
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (statusMessage.isNotBlank()) {
                    Text(
                        statusMessage,
                        color = IndustrialColors.SignalOrange,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 11.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .background(
                            if (connecting) IndustrialColors.ObsidianBorder else IndustrialColors.SignalOrange,
                            RoundedCornerShape(2.dp)
                        )
                        .clickable(enabled = !connecting) {
                            val cleanPin = pin.filter { it in '0'..'9' }.take(4)
                            val cleanIp = hostIp.trim()
                            val p = hostPort.toIntOrNull() ?: Protocol.DEFAULT_STREAM_PORT
                            prefs.edit()
                                .putString("last_ip", cleanIp)
                                .putString("last_port", p.toString())
                                .putString("last_pin", cleanPin)
                                .apply()
                            onConnect(cleanIp, p, cleanPin, preferHevc, maxFps)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (connecting) "HANDSHAKING..." else "ENGAGE STREAM",
                        color = if (connecting) IndustrialColors.Cream else IndustrialColors.ObsidianBg,
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun IndustrialInputField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    keyboardType: KeyboardType,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            label,
            color = IndustrialColors.Muted,
            fontFamily = JetBrainsMonoFamily,
            fontSize = 10.sp
        )
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(IndustrialColors.ObsidianBg, RoundedCornerShape(2.dp))
                .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                .padding(horizontal = 10.dp, vertical = 9.dp)
        ) {
            if (value.isEmpty()) {
                Text(
                    placeholder,
                    color = IndustrialColors.Muted.copy(alpha = 0.5f),
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 13.sp
                )
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = keyboardType,
                    autoCorrectEnabled = false
                ),
                cursorBrush = SolidColor(IndustrialColors.SignalOrange),
                textStyle = TextStyle(
                    color = IndustrialColors.Cream,
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 13.sp
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ToggleChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                if (selected) IndustrialColors.Cream else IndustrialColors.ObsidianBg,
                RoundedCornerShape(2.dp)
            )
            .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 5.dp)
    ) {
        Text(
            label,
            color = if (selected) IndustrialColors.ObsidianBg else IndustrialColors.Cream,
            fontFamily = JetBrainsMonoFamily,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
