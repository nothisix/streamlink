package com.streamlink.client.net

import java.nio.ByteBuffer
import java.nio.ByteOrder

object Protocol {
    const val MAGIC: Short = 0x534C.toShort()
    const val VERSION: Byte = 1
    const val DEFAULT_DISCOVERY_PORT = 47990
    const val DEFAULT_STREAM_PORT = 47991
    const val MAX_SHARD_PAYLOAD = 1200

    val DISCOVER_PROBE_MAGIC = "SL_DISC_REQ_V1".encodeToByteArray()
    val DISCOVER_RESP_MAGIC = "SL_DISC_RSP_V1".encodeToByteArray()

    const val PKT_PAIR_REQ: Byte = 0x01
    const val PKT_PAIR_ACK: Byte = 0x02
    const val PKT_PING: Byte = 0x03
    const val PKT_PONG: Byte = 0x04
    const val PKT_VIDEO_DATA: Byte = 0x10
    const val PKT_VIDEO_FEC: Byte = 0x11
    const val PKT_AUDIO_DATA: Byte = 0x12
    const val PKT_STREAM_META: Byte = 0x13
    const val PKT_TELEMETRY_FB: Byte = 0x20
    const val PKT_IDR_REQ: Byte = 0x21
    const val PKT_INPUT_GAMEPAD: Byte = 0x30
    const val PKT_INPUT_MOUSE_REL: Byte = 0x31
    const val PKT_INPUT_KEYBOARD: Byte = 0x32
    const val PKT_STREAM_CONFIG: Byte = 0x33
    const val PKT_KEEP_ALIVE: Byte = 0x34
    const val PKT_INPUT_MOUSE_ABS: Byte = 0x35
    const val PKT_DISCONNECT: Byte = 0xFF.toByte()

    data class ParsedHeader(
        val type: Byte,
        val sessionId: Int,
        val payloadOffset: Int
    )

    fun parseHeader(buf: ByteArray, len: Int): ParsedHeader? {
        if (len < 8) return null
        val bb = ByteBuffer.wrap(buf, 0, len).order(ByteOrder.BIG_ENDIAN)
        if (bb.short != MAGIC || bb.get() != VERSION) return null
        val type = bb.get()
        val sessionId = bb.int
        return ParsedHeader(type, sessionId, 8)
    }

    private fun writeHeader(bb: ByteBuffer, type: Byte, sessionId: Int) {
        bb.putShort(MAGIC)
        bb.put(VERSION)
        bb.put(type)
        bb.putInt(sessionId)
    }

    fun sanitizePin(raw: String): String {
        val asciiDigits = raw.trim().filter { it in '0'..'9' }
        return asciiDigits.padStart(4, '0').takeLast(4)
    }

    fun buildPairReq(
        pin: String,
        codecMask: Int,
        maxFps: Int,
        reqWidth: Int,
        reqHeight: Int,
        clientNonce: Int,
        clientName: String
    ): ByteArray {
        val cleanPin = sanitizePin(pin)
        val pinBytes = cleanPin.encodeToByteArray()
        val nameBytes = clientName.encodeToByteArray().take(48).toByteArray()
        val bb = ByteBuffer.allocate(8 + 16 + nameBytes.size).order(ByteOrder.BIG_ENDIAN)
        writeHeader(bb, PKT_PAIR_REQ, 0)
        bb.put(pinBytes)
        bb.put(codecMask.toByte())
        bb.putShort(maxFps.toShort())
        bb.putShort(reqWidth.toShort())
        bb.putShort(reqHeight.toShort())
        bb.putInt(clientNonce)
        bb.put(nameBytes.size.toByte())
        bb.put(nameBytes)
        return bb.array()
    }

    data class PairAck(
        val status: Int,
        val sessionId: Int,
        val codec: Int,
        val width: Int,
        val height: Int,
        val fps: Int,
        val audioRate: Int,
        val audioChannels: Int,
        val audioFrameMs: Int,
        val clientNonce: Int
    )

    fun parsePairAck(buf: ByteArray, len: Int, sessionId: Int, offset: Int): PairAck? {
        if (len - offset < 18) return null
        val bb = ByteBuffer.wrap(buf, offset, len - offset).order(ByteOrder.BIG_ENDIAN)
        return PairAck(
            status = bb.get().toInt() and 0xFF,
            sessionId = sessionId,
            codec = bb.get().toInt() and 0xFF,
            width = bb.short.toInt() and 0xFFFF,
            height = bb.short.toInt() and 0xFFFF,
            fps = bb.short.toInt() and 0xFFFF,
            audioRate = bb.int,
            audioChannels = bb.get().toInt() and 0xFF,
            audioFrameMs = bb.get().toInt() and 0xFF,
            clientNonce = bb.int
        )
    }

    fun buildPing(sessionId: Int, tsUs: Long): ByteArray {
        val bb = ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN)
        writeHeader(bb, PKT_PING, sessionId)
        bb.putLong(tsUs)
        return bb.array()
    }

    fun buildTelemetryFb(
        sessionId: Int,
        echoTsUs: Long,
        highestSeq: Int,
        packetsReceived: Int,
        packetsLost: Int,
        jitterUs: Int,
        decodeTimeUs: Int,
        fpsRendered: Int,
        idrRequested: Boolean
    ): ByteArray {
        val bb = ByteBuffer.allocate(39).order(ByteOrder.BIG_ENDIAN)
        writeHeader(bb, PKT_TELEMETRY_FB, sessionId)
        bb.putLong(echoTsUs)
        bb.putInt(highestSeq)
        bb.putInt(packetsReceived)
        bb.putInt(packetsLost)
        bb.putInt(jitterUs)
        bb.putInt(decodeTimeUs)
        bb.putShort(fpsRendered.toShort())
        bb.put(if (idrRequested) 1 else 0)
        return bb.array()
    }

    fun buildIdrReq(sessionId: Int): ByteArray {
        val bb = ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN)
        writeHeader(bb, PKT_IDR_REQ, sessionId)
        return bb.array()
    }

    fun buildGamepadInput(
        sessionId: Int,
        buttons: Int,
        lt: Int,
        rt: Int,
        lx: Short,
        ly: Short,
        rx: Short,
        ry: Short,
        seq: Int
    ): ByteArray {
        val bb = ByteBuffer.allocate(24).order(ByteOrder.BIG_ENDIAN)
        writeHeader(bb, PKT_INPUT_GAMEPAD, sessionId)
        bb.putShort(buttons.toShort())
        bb.put(lt.coerceIn(0, 255).toByte())
        bb.put(rt.coerceIn(0, 255).toByte())
        bb.putShort(lx)
        bb.putShort(ly)
        bb.putShort(rx)
        bb.putShort(ry)
        bb.putInt(seq)
        return bb.array()
    }

    fun buildMouseRel(
        sessionId: Int,
        dx: Short,
        dy: Short,
        wheel: Byte,
        hWheel: Byte,
        buttons: Int
    ): ByteArray {
        val bb = ByteBuffer.allocate(15).order(ByteOrder.BIG_ENDIAN)
        writeHeader(bb, PKT_INPUT_MOUSE_REL, sessionId)
        bb.putShort(dx)
        bb.putShort(dy)
        bb.put(wheel)
        bb.put(hWheel)
        bb.put(buttons.toByte())
        return bb.array()
    }

    fun buildMouseAbs(
        sessionId: Int,
        xNorm: Int,
        yNorm: Int,
        buttons: Int,
        wheel: Byte = 0,
        hWheel: Byte = 0
    ): ByteArray {
        val bb = ByteBuffer.allocate(15).order(ByteOrder.BIG_ENDIAN)
        writeHeader(bb, PKT_INPUT_MOUSE_ABS, sessionId)
        bb.putShort(xNorm.coerceIn(0, 65535).toShort())
        bb.putShort(yNorm.coerceIn(0, 65535).toShort())
        bb.put(buttons.toByte())
        bb.put(wheel)
        bb.put(hWheel)
        return bb.array()
    }

    fun buildKeyboard(sessionId: Int, vkCode: Int, scanCode: Int, isDown: Boolean): ByteArray {
        val bb = ByteBuffer.allocate(13).order(ByteOrder.BIG_ENDIAN)
        writeHeader(bb, PKT_INPUT_KEYBOARD, sessionId)
        bb.putShort(vkCode.toShort())
        bb.putShort(scanCode.toShort())
        bb.put(if (isDown) 1 else 0)
        return bb.array()
    }

    fun buildStreamConfig(sessionId: Int, lockBitrateKbps: Int, codecPref: Int = 0xFF): ByteArray {
        val bb = ByteBuffer.allocate(13).order(ByteOrder.BIG_ENDIAN)
        writeHeader(bb, PKT_STREAM_CONFIG, sessionId)
        bb.putInt(lockBitrateKbps)
        bb.put(codecPref.toByte())
        return bb.array()
    }

    fun buildDisconnect(sessionId: Int): ByteArray {
        val bb = ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN)
        writeHeader(bb, PKT_DISCONNECT, sessionId)
        return bb.array()
    }
}
