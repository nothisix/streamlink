package com.streamlink.client.net

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.view.Surface
import com.streamlink.client.media.AudioStreamPlayer
import com.streamlink.client.media.VideoDecoderRenderer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

enum class InputMode(val label: String) {
    GAMEPAD("GAMEPAD"),
    TRACKPAD("TRACKPAD"),
    DIRECT_TOUCH("DIRECT")
}

data class TelemetryState(
    val connected: Boolean = false,
    val statusText: String = "IDLE",
    val hostLabel: String = "",
    val rttMs: Float = 0f,
    val fps: Int = 0,
    val bitrateMbps: Float = 10.0f,
    val lossPct: Float = 0f,
    val codecLabel: String = "H.264",
    val width: Int = 1920,
    val height: Int = 1080,
    val bitrateLocked: Boolean = false,
    val audioMuted: Boolean = false
)

class StreamClient(private val appContext: Context? = null) {
    private val _telemetry = MutableStateFlow(TelemetryState())
    val telemetry: StateFlow<TelemetryState> = _telemetry

    private val running = AtomicBoolean(false)
    private var socket: DatagramSocket? = null
    private var hostAddr: InetAddress? = null
    private var hostPort: Int = Protocol.DEFAULT_STREAM_PORT
    @Volatile
    private var sessionId: Int = 0

    private val videoDecoder = VideoDecoderRenderer()
    private val audioPlayer = AudioStreamPlayer()

    private var rxThread: Thread? = null
    private var ctrlThread: Thread? = null
    private var txThread: Thread? = null
    private val txQueue = ArrayBlockingQueue<ByteArray>(256)
    private var currentSurface: Surface? = null
    private var currentMaxFps: Int = 60

    private var wifiLock: WifiManager.WifiLock? = null

    private val gamepadSeq = AtomicInteger(1)
    private val pendingIdrReq = AtomicBoolean(false)

    private class FrameAssembly(
        val frameId: Int,
        val dataShards: Int,
        val fecShards: Int,
        val isIdr: Boolean,
        val isHevc: Boolean,
        val lastShardLen: Int,
        val createdMs: Long = System.currentTimeMillis()
    ) {
        val shards = arrayOfNulls<ByteArray>(dataShards + fecShards)
        var receivedCount = 0
        var shardWidth = Protocol.MAX_SHARD_PAYLOAD
        var completed = false
    }

    private val assemblies = ConcurrentHashMap<Int, FrameAssembly>()
    private var lastSubmittedFrameId = -1

    @Volatile
    private var highestSeq = 0
    @Volatile
    private var packetsRx = 0
    @Volatile
    private var packetsLost = 0
    @Volatile
    private var lastJitterUs = 0
    @Volatile
    private var lastEchoHostTs = 0L

    private fun acquireWifiLock() {
        val ctx = appContext ?: return
        try {
            if (wifiLock == null) {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return
                val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    @Suppress("DEPRECATION")
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                }
                wifiLock = wm.createWifiLock(mode, "StreamLink::LowLatencyWifi").apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld == false) {
                wifiLock?.acquire()
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseWifiLock() {
        try {
            if (wifiLock?.isHeld == true) {
                wifiLock?.release()
            }
        } catch (_: Exception) {
        }
    }

    fun attachSurface(surface: Surface, maxFps: Int) {
        currentSurface = surface
        currentMaxFps = maxFps
        val t = _telemetry.value
        if (t.connected) {
            videoDecoder.configure(surface, t.codecLabel == "HEVC", t.width, t.height, maxFps)
        }
    }

    fun detachSurface() {
        currentSurface = null
        videoDecoder.stop()
    }

    fun connect(
        ip: String,
        port: Int,
        pin: String,
        preferHevc: Boolean,
        maxFps: Int,
        clientName: String,
        onResult: (Boolean, String) -> Unit
    ) {
        disconnect()
        currentMaxFps = maxFps
        Thread({
            try {
                val addr = InetAddress.getByName(ip.trim())
                val sock = DatagramSocket().apply {
                    receiveBufferSize = 2 * 1024 * 1024
                    sendBufferSize = 512 * 1024
                    soTimeout = 1200
                }
                socket = sock
                hostAddr = addr
                hostPort = port

                val nonce = (System.nanoTime() and 0x7FFFFFFF).toInt()
                val codecMask = if (preferHevc) 0x03 else 0x01
                val req = Protocol.buildPairReq(pin, codecMask, maxFps, 1920, 1080, nonce, clientName)

                var ack: Protocol.PairAck? = null
                val buf = ByteArray(2048)
                for (attempt in 0 until 4) {
                    sock.send(DatagramPacket(req, req.size, addr, port))
                    val waitEnd = System.currentTimeMillis() + 1200L
                    while (System.currentTimeMillis() < waitEnd) {
                        try {
                            val dp = DatagramPacket(buf, buf.size)
                            sock.receive(dp)
                            val hdr = Protocol.parseHeader(dp.data, dp.length)
                            if (hdr != null && hdr.type == Protocol.PKT_PAIR_ACK) {
                                val parsed = Protocol.parsePairAck(dp.data, dp.length, hdr.sessionId, hdr.payloadOffset)
                                // Verify nonce matches this exact pairing request to prevent stale ACK mismatch
                                if (parsed != null && parsed.clientNonce == nonce) {
                                    ack = parsed
                                    break
                                }
                            }
                        } catch (_: Exception) {
                            break
                        }
                    }
                    if (ack != null) break
                }

                if (ack == null) {
                    sock.close()
                    onResult(false, "HOST UNREACHABLE ($ip:$port)")
                    return@Thread
                }
                if (ack.status != 0) {
                    sock.close()
                    onResult(false, if (ack.status == 1) "INVALID 4-DIGIT PIN" else "HOST BUSY")
                    return@Thread
                }

                acquireWifiLock()
                sessionId = ack.sessionId
                running.set(true)
                sock.soTimeout = 250

                val isHevc = ack.codec == 1
                _telemetry.value = TelemetryState(
                    connected = true,
                    statusText = "LIVE",
                    hostLabel = "$ip:$port",
                    codecLabel = if (isHevc) "HEVC" else "H.264",
                    width = ack.width,
                    height = ack.height,
                    fps = ack.fps,
                    bitrateMbps = 10.0f
                )

                currentSurface?.let { s ->
                    videoDecoder.configure(s, isHevc, ack.width, ack.height, ack.fps)
                }
                audioPlayer.start()

                rxThread = Thread({ receiverLoop(sock) }, "streamlink-udp-rx").apply {
                    priority = Thread.MAX_PRIORITY
                    start()
                }
                txThread = Thread({ txLoop(sock, addr, port) }, "streamlink-udp-tx").apply {
                    priority = Thread.MAX_PRIORITY
                    start()
                }
                ctrlThread = Thread({ controlLoop(sock, addr, port) }, "streamlink-ctrl").apply {
                    start()
                }
                onResult(true, "CONNECTED")
            } catch (e: Exception) {
                releaseWifiLock()
                onResult(false, e.message ?: "CONNECTION FAILED")
            }
        }, "streamlink-connect").start()
    }

    fun disconnect() {
        val wasRunning = running.getAndSet(false)
        val sid = sessionId
        val sock = socket
        val addr = hostAddr
        if (wasRunning && sock != null && addr != null && sid != 0) {
            Thread {
                try {
                    val pkt = Protocol.buildDisconnect(sid)
                    sock.send(DatagramPacket(pkt, pkt.size, addr, hostPort))
                } catch (_: Exception) {
                }
            }.start()
        }
        sessionId = 0
        try { sock?.close() } catch (_: Exception) {}
        socket = null
        videoDecoder.stop()
        audioPlayer.stop()
        releaseWifiLock()
        txQueue.clear()
        assemblies.clear()
        lastSubmittedFrameId = -1
        _telemetry.value = TelemetryState(connected = false, statusText = "DISCONNECTED")
    }

    fun toggleBitrateLock() {
        val next = !_telemetry.value.bitrateLocked
        _telemetry.value = _telemetry.value.copy(bitrateLocked = next)
        val lockKbps = if (next) (_telemetry.value.bitrateMbps * 1000f).toInt().coerceIn(3000, 25000) else 0
        sendUdp(Protocol.buildStreamConfig(sessionId, lockKbps))
    }

    fun toggleMute() {
        val next = !_telemetry.value.audioMuted
        audioPlayer.muted = next
        _telemetry.value = _telemetry.value.copy(audioMuted = next)
    }

    fun sendGamepad(buttons: Int, lt: Int, rt: Int, lx: Short, ly: Short, rx: Short, ry: Short) {
        if (!running.get() || sessionId == 0) return
        val pkt = Protocol.buildGamepadInput(
            sessionId, buttons, lt, rt, lx, ly, rx, ry, gamepadSeq.getAndIncrement()
        )
        sendUdp(pkt)
    }

    fun sendMouseRel(dx: Int, dy: Int, wheel: Int = 0, hWheel: Int = 0, buttons: Int = 0) {
        if (!running.get() || sessionId == 0) return
        val pkt = Protocol.buildMouseRel(
            sessionId = sessionId,
            dx = dx.coerceIn(-32000, 32000).toShort(),
            dy = dy.coerceIn(-32000, 32000).toShort(),
            wheel = wheel.coerceIn(-127, 127).toByte(),
            hWheel = hWheel.coerceIn(-127, 127).toByte(),
            buttons = buttons
        )
        sendUdp(pkt)
    }

    fun sendMouseAbs(xNorm01: Float, yNorm01: Float, buttons: Int, wheel: Int = 0, hWheel: Int = 0) {
        if (!running.get() || sessionId == 0) return
        val xScaled = (xNorm01.coerceIn(0f, 1f) * 65535f).toInt()
        val yScaled = (yNorm01.coerceIn(0f, 1f) * 65535f).toInt()
        val pkt = Protocol.buildMouseAbs(
            sessionId = sessionId,
            xNorm = xScaled,
            yNorm = yScaled,
            buttons = buttons,
            wheel = wheel.coerceIn(-127, 127).toByte(),
            hWheel = hWheel.coerceIn(-127, 127).toByte()
        )
        sendUdp(pkt)
    }

    fun sendKeyboard(vkCode: Int, isDown: Boolean) {
        if (!running.get() || sessionId == 0) return
        sendUdp(Protocol.buildKeyboard(sessionId, vkCode, 0, isDown))
    }

    private fun sendUdp(data: ByteArray) {
        if (!running.get()) return
        while (!txQueue.offer(data)) {
            txQueue.poll()
        }
    }

    private fun txLoop(sock: DatagramSocket, addr: InetAddress, port: Int) {
        while (running.get()) {
            try {
                val pkt = txQueue.poll(100, TimeUnit.MILLISECONDS) ?: continue
                sock.send(DatagramPacket(pkt, pkt.size, addr, port))
            } catch (_: Exception) {
            }
        }
    }

    private fun receiverLoop(sock: DatagramSocket) {
        val buf = ByteArray(2048)
        var lastSeqInit = false
        var expectedSeq = 0
        var prevArrivalUs = 0L
        var prevTransitUs = 0L
        var jitterAcc = 0f

        while (running.get()) {
            try {
                val dp = DatagramPacket(buf, buf.size)
                sock.receive(dp)
                val hdr = Protocol.parseHeader(dp.data, dp.length) ?: continue
                if (hdr.sessionId != sessionId && hdr.type != Protocol.PKT_PAIR_ACK) continue

                when (hdr.type) {
                    Protocol.PKT_VIDEO_DATA, Protocol.PKT_VIDEO_FEC -> {
                        val isFec = hdr.type == Protocol.PKT_VIDEO_FEC
                        val off = hdr.payloadOffset
                        if (dp.length - off < 18) continue
                        val bb = ByteBuffer.wrap(dp.data, off, dp.length - off).order(ByteOrder.BIG_ENDIAN)
                        val frameId = bb.int
                        val seq = bb.int
                        val hostTsUs = bb.int.toLong() and 0xFFFFFFFFL
                        val shardIdx = bb.get().toInt() and 0xFF
                        val dataShards = bb.get().toInt() and 0xFF
                        val fecShards = bb.get().toInt() and 0xFF
                        val flags = bb.get().toInt() and 0xFF
                        val lastShardLen = bb.short.toInt() and 0xFFFF
                        val payloadLen = dp.length - off - 18
                        if (dataShards <= 0 || shardIdx >= dataShards + fecShards || payloadLen <= 0) continue

                        packetsRx++
                        if (!lastSeqInit) {
                            lastSeqInit = true
                            expectedSeq = seq + 1
                            highestSeq = seq
                        } else {
                            if (seq > expectedSeq) {
                                packetsLost += (seq - expectedSeq)
                                expectedSeq = seq + 1
                            } else if (seq == expectedSeq) {
                                expectedSeq = seq + 1
                            }
                            if (seq > highestSeq) highestSeq = seq
                        }

                        val nowUs = System.nanoTime() / 1000L
                        val transit = nowUs - hostTsUs
                        if (prevArrivalUs != 0L) {
                            val d = abs((transit - prevTransitUs).toFloat())
                            jitterAcc += (d - jitterAcc) / 16f
                            lastJitterUs = jitterAcc.toInt()
                        }
                        prevArrivalUs = nowUs
                        prevTransitUs = transit

                        if (frameId <= lastSubmittedFrameId) continue

                        val payload = ByteArray(payloadLen)
                        bb.get(payload)

                        val isIdr = (flags and 0x01) != 0
                        val isHevc = (flags and 0x02) != 0
                        val asm = assemblies.getOrPut(frameId) {
                            FrameAssembly(frameId, dataShards, fecShards, isIdr, isHevc, lastShardLen)
                        }
                        if (asm.completed) continue

                        if (!isFec && shardIdx < dataShards - 1) {
                            asm.shardWidth = payloadLen
                        } else if (isFec) {
                            asm.shardWidth = payloadLen
                        }

                        if (payloadLen < asm.shardWidth) {
                            val padded = ByteArray(asm.shardWidth)
                            System.arraycopy(payload, 0, padded, 0, payloadLen)
                            asm.shards[shardIdx] = padded
                        } else {
                            asm.shards[shardIdx] = payload
                        }
                        asm.receivedCount++

                        if (asm.receivedCount >= asm.dataShards) {
                            var allDataPresent = true
                            for (i in 0 until asm.dataShards) {
                                if (asm.shards[i] == null) {
                                    allDataPresent = false
                                    break
                                }
                            }
                            val ok = if (allDataPresent) {
                                true
                            } else {
                                ReedSolomonFec.reconstructData(asm.shards, asm.dataShards, asm.fecShards)
                            }
                            if (ok) {
                                asm.completed = true
                                val totalBytes = (asm.dataShards - 1) * asm.shardWidth + asm.lastShardLen
                                val frameBytes = ByteArray(totalBytes)
                                var cursor = 0
                                for (i in 0 until asm.dataShards) {
                                    val chunk = asm.shards[i] ?: break
                                    val copyLen = if (i == asm.dataShards - 1) asm.lastShardLen else asm.shardWidth
                                    val safeLen = copyLen.coerceAtMost(totalBytes - cursor)
                                    if (safeLen > 0) {
                                        System.arraycopy(chunk, 0, frameBytes, cursor, safeLen)
                                        cursor += safeLen
                                    }
                                }
                                lastSubmittedFrameId = frameId
                                videoDecoder.submitFrame(frameBytes, asm.isIdr)
                                pruneStaleAssemblies(frameId)
                            }
                        }

                        val nowMs = System.currentTimeMillis()
                        val staleIt = assemblies.entries.iterator()
                        while (staleIt.hasNext()) {
                            val e = staleIt.next()
                            if (nowMs - e.value.createdMs > 45L) {
                                if (!e.value.completed && e.key > lastSubmittedFrameId) {
                                    pendingIdrReq.set(true)
                                }
                                staleIt.remove()
                            }
                        }
                    }

                    Protocol.PKT_AUDIO_DATA -> {
                        val off = hdr.payloadOffset
                        if (dp.length - off <= 8) continue
                        val opus = dp.data.copyOfRange(off + 8, dp.length)
                        audioPlayer.submitOpusFrame(opus)
                    }

                    Protocol.PKT_STREAM_META -> {
                        val off = hdr.payloadOffset
                        if (dp.length - off < 11) continue
                        val bb = ByteBuffer.wrap(dp.data, off, dp.length - off).order(ByteOrder.BIG_ENDIAN)
                        val codec = bb.get().toInt() and 0xFF
                        val w = bb.short.toInt() and 0xFFFF
                        val h = bb.short.toInt() and 0xFFFF
                        val fps = bb.short.toInt() and 0xFFFF
                        val bitrateKbps = bb.int
                        val isHevc = codec == 1
                        val t = _telemetry.value
                        val resChanged = t.width != w || t.height != h || (t.codecLabel == "HEVC") != isHevc || t.fps != fps
                        _telemetry.value = t.copy(
                            codecLabel = if (isHevc) "HEVC" else "H.264",
                            width = w,
                            height = h,
                            fps = fps,
                            bitrateMbps = bitrateKbps / 1000f
                        )
                        if (resChanged) {
                            currentSurface?.let { s ->
                                videoDecoder.configure(s, isHevc, w, h, fps)
                            }
                        }
                    }

                    Protocol.PKT_PONG -> {
                        val off = hdr.payloadOffset
                        if (dp.length - off >= 8) {
                            val bb = ByteBuffer.wrap(dp.data, off, 8).order(ByteOrder.BIG_ENDIAN)
                            val sentNs = bb.long
                            val rttUs = ((System.nanoTime() - sentNs) / 1000L).coerceIn(0L, 999_000L)
                            lastEchoHostTs = Long.MIN_VALUE or rttUs
                            _telemetry.value = _telemetry.value.copy(rttMs = rttUs / 1000f)
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun pruneStaleAssemblies(upToFrameId: Int) {
        val it = assemblies.entries.iterator()
        while (it.hasNext()) {
            if (it.next().key <= upToFrameId) {
                it.remove()
            }
        }
    }

    private fun controlLoop(sock: DatagramSocket, addr: InetAddress, port: Int) {
        var prevRx = 0
        var prevLost = 0
        while (running.get()) {
            try {
                val nowNs = System.nanoTime()
                val pingPkt = Protocol.buildPing(sessionId, nowNs)
                sock.send(DatagramPacket(pingPkt, pingPkt.size, addr, port))

                val curRx = packetsRx
                val curLost = packetsLost
                val dRx = (curRx - prevRx).coerceAtLeast(0)
                val dLost = (curLost - prevLost).coerceAtLeast(0)
                prevRx = curRx
                prevLost = curLost
                val total = dRx + dLost
                val lossPct = if (total > 0) (dLost.toFloat() / total.toFloat()) * 100f else 0f

                val idr = pendingIdrReq.getAndSet(false)
                val fps = videoDecoder.measuredFps.get()
                val fbPkt = Protocol.buildTelemetryFb(
                    sessionId = sessionId,
                    echoTsUs = lastEchoHostTs,
                    highestSeq = highestSeq,
                    packetsReceived = curRx,
                    packetsLost = curLost,
                    jitterUs = lastJitterUs,
                    decodeTimeUs = videoDecoder.lastDecodeTimeUs.get(),
                    fpsRendered = fps,
                    idrRequested = idr
                )
                sock.send(DatagramPacket(fbPkt, fbPkt.size, addr, port))

                _telemetry.value = _telemetry.value.copy(
                    fps = fps,
                    lossPct = lossPct
                )

                Thread.sleep(50)
            } catch (_: Exception) {
            }
        }
    }
}
