package com.streamlink.client.controller

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class ControlKind {
    LEFT_STICK,
    RIGHT_STICK,
    DPAD,
    BTN_A,
    BTN_B,
    BTN_X,
    BTN_Y,
    BTN_LB,
    BTN_RB,
    BTN_LT,
    BTN_RT,
    BTN_BACK,
    BTN_START,
    BTN_LMB,
    BTN_RMB
}

enum class SensitivityCurve(val label: String) {
    LINEAR("LINEAR"),
    EXPONENTIAL("EXPO"),
    S_CURVE("S-CURVE")
}

data class ControlNode(
    val kind: ControlKind,
    val label: String,
    val xPct: Float,
    val yPct: Float,
    val scale: Float = 1.0f,
    val opacity: Float = 0.78f,
    val visible: Boolean = true
)

data class ControllerProfile(
    val name: String,
    val nodes: List<ControlNode>,
    val deadzone: Float = 0.08f,
    val curve: SensitivityCurve = SensitivityCurve.LINEAR,
    val hapticsEnabled: Boolean = true,
    val rightZoneMouseLook: Boolean = false,
    val rightStickMouseMode: Boolean = false,
    val trackpadSensitivity: Float = 1.25f,
    val hudMinimizedByDefault: Boolean = false
)

object ProfileStore {
    private const val PREF_NAME = "streamlink_profiles_v1"
    private const val KEY_ACTIVE = "active_profile"
    private const val KEY_JSON = "profiles_json"

    val presetNames = listOf("Default FPS", "Racing", "Minimalist", "Custom")

    fun defaultProfile(name: String): ControllerProfile {
        val base = listOf(
            ControlNode(ControlKind.LEFT_STICK, "LS", 0.14f, 0.70f, 1.10f, 0.80f, true),
            ControlNode(ControlKind.DPAD, "DPAD", 0.25f, 0.43f, 0.90f, 0.72f, true),
            ControlNode(ControlKind.RIGHT_STICK, "RS", 0.77f, 0.72f, 1.05f, 0.80f, true),
            ControlNode(ControlKind.BTN_A, "A", 0.88f, 0.66f, 1.00f, 0.82f, true),
            ControlNode(ControlKind.BTN_B, "B", 0.94f, 0.54f, 1.00f, 0.82f, true),
            ControlNode(ControlKind.BTN_X, "X", 0.82f, 0.54f, 1.00f, 0.82f, true),
            ControlNode(ControlKind.BTN_Y, "Y", 0.88f, 0.42f, 1.00f, 0.82f, true),
            ControlNode(ControlKind.BTN_LT, "LT", 0.08f, 0.20f, 1.00f, 0.80f, true),
            ControlNode(ControlKind.BTN_LB, "LB", 0.18f, 0.20f, 0.95f, 0.80f, true),
            ControlNode(ControlKind.BTN_RB, "RB", 0.82f, 0.20f, 0.95f, 0.80f, true),
            ControlNode(ControlKind.BTN_RT, "RT", 0.92f, 0.20f, 1.00f, 0.80f, true),
            ControlNode(ControlKind.BTN_BACK, "VIEW", 0.42f, 0.14f, 0.85f, 0.68f, true),
            ControlNode(ControlKind.BTN_START, "MENU", 0.58f, 0.14f, 0.85f, 0.68f, true),
            ControlNode(ControlKind.BTN_LMB, "LMB", 0.34f, 0.82f, 0.85f, 0.70f, false),
            ControlNode(ControlKind.BTN_RMB, "RMB", 0.44f, 0.82f, 0.85f, 0.70f, false)
        )
        return when (name) {
            "Racing" -> ControllerProfile(
                name = "Racing",
                nodes = base.map {
                    when (it.kind) {
                        ControlKind.LEFT_STICK -> it.copy(xPct = 0.15f, yPct = 0.66f, scale = 1.25f)
                        ControlKind.BTN_LT -> it.copy(xPct = 0.78f, yPct = 0.72f, scale = 1.25f)
                        ControlKind.BTN_RT -> it.copy(xPct = 0.90f, yPct = 0.66f, scale = 1.30f)
                        ControlKind.RIGHT_STICK, ControlKind.DPAD -> it.copy(visible = false)
                        ControlKind.BTN_Y -> it.copy(xPct = 0.88f, yPct = 0.42f, scale = 0.90f)
                        else -> it
                    }
                },
                deadzone = 0.05f,
                curve = SensitivityCurve.LINEAR
            )
            "Minimalist" -> ControllerProfile(
                name = "Minimalist",
                nodes = base.map {
                    val vis = it.kind in setOf(
                        ControlKind.LEFT_STICK,
                        ControlKind.RIGHT_STICK,
                        ControlKind.BTN_A,
                        ControlKind.BTN_B,
                        ControlKind.BTN_LT,
                        ControlKind.BTN_RT,
                        ControlKind.BTN_START
                    )
                    it.copy(visible = vis, opacity = 0.52f)
                },
                deadzone = 0.08f,
                curve = SensitivityCurve.S_CURVE
            )
            "Default FPS" -> ControllerProfile(
                name = "Default FPS",
                nodes = base,
                deadzone = 0.07f,
                curve = SensitivityCurve.EXPONENTIAL,
                rightZoneMouseLook = false,
                rightStickMouseMode = false
            )
            else -> ControllerProfile(name = name, nodes = base)
        }
    }

    fun loadAll(context: Context): Pair<String, MutableMap<String, ControllerProfile>> {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val active = prefs.getString(KEY_ACTIVE, "Default FPS") ?: "Default FPS"
        val map = mutableMapOf<String, ControllerProfile>()
        for (p in presetNames) {
            map[p] = defaultProfile(p)
        }
        val raw = prefs.getString(KEY_JSON, null)
        if (!raw.isNullOrBlank()) {
            try {
                val root = JSONObject(raw)
                for (key in root.keys()) {
                    val obj = root.getJSONObject(key)
                    val nodesArr = obj.getJSONArray("nodes")
                    val nodes = ArrayList<ControlNode>(nodesArr.length())
                    for (i in 0 until nodesArr.length()) {
                        val n = nodesArr.getJSONObject(i)
                        val kind = ControlKind.valueOf(n.getString("kind"))
                        nodes.add(
                            ControlNode(
                                kind = kind,
                                label = n.getString("label"),
                                xPct = n.getDouble("xPct").toFloat(),
                                yPct = n.getDouble("yPct").toFloat(),
                                scale = n.getDouble("scale").toFloat(),
                                opacity = n.getDouble("opacity").toFloat(),
                                visible = n.getBoolean("visible")
                            )
                        )
                    }
                    // Ensure newly added control kinds (e.g. LMB/RMB) exist on migrated profiles
                    val fallback = defaultProfile(key)
                    val presentKinds = nodes.map { it.kind }.toSet()
                    for (defNode in fallback.nodes) {
                        if (defNode.kind !in presentKinds) {
                            nodes.add(defNode)
                        }
                    }
                    map[key] = ControllerProfile(
                        name = key,
                        nodes = nodes,
                        deadzone = obj.optDouble("deadzone", 0.08).toFloat(),
                        curve = SensitivityCurve.valueOf(obj.optString("curve", "LINEAR")),
                        hapticsEnabled = obj.optBoolean("haptics", true),
                        rightZoneMouseLook = obj.optBoolean("rightMouse", false),
                        rightStickMouseMode = obj.optBoolean("rightStickMouse", false),
                        trackpadSensitivity = obj.optDouble("trackpadSens", 1.25).toFloat().coerceIn(0.4f, 3.0f),
                        hudMinimizedByDefault = obj.optBoolean("hudMin", false)
                    )
                }
            } catch (_: Exception) {
            }
        }
        return active to map
    }

    fun saveAll(context: Context, active: String, map: Map<String, ControllerProfile>) {
        val root = JSONObject()
        for ((k, prof) in map) {
            val obj = JSONObject()
            obj.put("deadzone", prof.deadzone.toDouble())
            obj.put("curve", prof.curve.name)
            obj.put("haptics", prof.hapticsEnabled)
            obj.put("rightMouse", prof.rightZoneMouseLook)
            obj.put("rightStickMouse", prof.rightStickMouseMode)
            obj.put("trackpadSens", prof.trackpadSensitivity.toDouble())
            obj.put("hudMin", prof.hudMinimizedByDefault)
            val arr = JSONArray()
            for (node in prof.nodes) {
                arr.put(
                    JSONObject().apply {
                        put("kind", node.kind.name)
                        put("label", node.label)
                        put("xPct", node.xPct.toDouble())
                        put("yPct", node.yPct.toDouble())
                        put("scale", node.scale.toDouble())
                        put("opacity", node.opacity.toDouble())
                        put("visible", node.visible)
                    }
                )
            }
            obj.put("nodes", arr)
            root.put(k, obj)
        }
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACTIVE, active)
            .putString(KEY_JSON, root.toString())
            .apply()
    }
}
