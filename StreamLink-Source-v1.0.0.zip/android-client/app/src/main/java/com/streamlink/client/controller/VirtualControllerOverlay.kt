package com.streamlink.client.controller

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.streamlink.client.net.StreamClient
import com.streamlink.client.ui.IndustrialColors
import com.streamlink.client.ui.JetBrainsMonoFamily
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sign

private object XusbMask {
    const val DPAD_UP = 0x0001
    const val DPAD_DOWN = 0x0002
    const val DPAD_LEFT = 0x0004
    const val DPAD_RIGHT = 0x0008
    const val START = 0x0010
    const val BACK = 0x0020
    const val LB = 0x0100
    const val RB = 0x0200
    const val A = 0x1000
    const val B = 0x2000
    const val X = 0x4000
    const val Y = 0x8000
}

private data class ActiveTouch(
    val pointerId: PointerId,
    val boundNode: ControlKind?,
    val origin: Offset,
    val current: Offset,
    val isRightCameraZone: Boolean = false
)

@Composable
fun VirtualControllerOverlay(
    client: StreamClient,
    profile: ControllerProfile,
    editMode: Boolean,
    visible: Boolean,
    onProfileChange: (ControllerProfile) -> Unit,
    onSelectProfile: (String) -> Unit,
    onExitEditMode: () -> Unit
) {
    if (!visible && !editMode) return

    val context = LocalContext.current
    val density = LocalDensity.current
    val textMeasurer = rememberTextMeasurer()

    val vibrator = remember(context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    fun triggerHaptic(ms: Long = 10L) {
        if (!profile.hapticsEnabled) return
        try {
            vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    val currentProfile by rememberUpdatedState(profile)
    val currentOnProfileChange by rememberUpdatedState(onProfileChange)
    var canvasSize by remember { mutableStateOf(IntSize(1, 1)) }
    val activeTouches = remember { mutableStateMapOf<PointerId, ActiveTouch>() }
    var selectedEditNode by remember { mutableStateOf<ControlKind?>(ControlKind.LEFT_STICK) }
    var dragEditPointer by remember { mutableStateOf<PointerId?>(null) }

    LaunchedEffect(editMode, visible) {
        if (editMode || !visible) {
            activeTouches.clear()
            client.sendVirtualGamepad(0, 0, 0, 0, 0, 0, 0)
            client.sendMouseRel(0, 0, buttons = 0)
        }
    }

    val baseBtnRadiusPx = with(density) { 27.dp.toPx() }
    val baseStickRadiusPx = with(density) { 54.dp.toPx() }
    val baseDpadRadiusPx = with(density) { 52.dp.toPx() }

    fun nodeCenter(node: ControlNode): Offset {
        return Offset(node.xPct * canvasSize.width, node.yPct * canvasSize.height)
    }

    fun nodeRadius(node: ControlNode): Float {
        return when (node.kind) {
            ControlKind.LEFT_STICK, ControlKind.RIGHT_STICK -> baseStickRadiusPx * node.scale
            ControlKind.DPAD -> baseDpadRadiusPx * node.scale
            else -> baseBtnRadiusPx * node.scale
        }
    }

    fun applyCurve(raw: Float, deadzone: Float, curve: SensitivityCurve): Float {
        val mag = abs(raw)
        if (mag <= deadzone) return 0f
        val norm = ((mag - deadzone) / (1f - deadzone)).coerceIn(0f, 1f)
        val shaped = when (curve) {
            SensitivityCurve.LINEAR -> norm
            SensitivityCurve.EXPONENTIAL -> norm.pow(1.8f)
            SensitivityCurve.S_CURVE -> norm * norm * (3f - 2f * norm)
        }
        return sign(raw) * shaped
    }

    // Continuous 60Hz Analog-to-Mouse steering when rightStickMouseMode is active
    LaunchedEffect(profile.rightStickMouseMode, editMode, visible) {
        if (!profile.rightStickMouseMode || editMode || !visible) return@LaunchedEffect
        var prevMouseBtns = 0
        while (true) {
            var dx = 0
            var dy = 0
            var mBtns = 0
            for ((_, t) in activeTouches) {
                when (t.boundNode) {
                    ControlKind.RIGHT_STICK -> {
                        val node = profile.nodes.firstOrNull { it.kind == ControlKind.RIGHT_STICK }
                        if (node != null) {
                            val rad = nodeRadius(node)
                            val rawX = ((t.current.x - t.origin.x) / rad).coerceIn(-1f, 1f)
                            val rawY = ((t.current.y - t.origin.y) / rad).coerceIn(-1f, 1f)
                            dx = (applyCurve(rawX, profile.deadzone, profile.curve) * 22f).toInt()
                            dy = (applyCurve(rawY, profile.deadzone, profile.curve) * 22f).toInt()
                        }
                    }
                    ControlKind.BTN_LMB -> mBtns = mBtns or 0x01
                    ControlKind.BTN_RMB -> mBtns = mBtns or 0x02
                    else -> {}
                }
            }
            if (dx != 0 || dy != 0 || mBtns != prevMouseBtns) {
                client.sendMouseRel(dx, dy, buttons = mBtns)
                prevMouseBtns = mBtns
            }
            delay(16)
        }
    }

    fun emitInputState() {
        if (editMode) return
        var buttons = 0
        var lt = 0
        var rt = 0
        var lx = 0f
        var ly = 0f
        var rx = 0f
        var ry = 0f
        var mouseBtns = 0
        var hasMousePill = false

        for ((_, t) in activeTouches) {
            val node = profile.nodes.firstOrNull { it.kind == t.boundNode } ?: continue
            val center = nodeCenter(node)
            val rad = nodeRadius(node)
            when (node.kind) {
                ControlKind.LEFT_STICK -> {
                    val dx = ((t.current.x - t.origin.x) / rad).coerceIn(-1f, 1f)
                    val dy = ((t.current.y - t.origin.y) / rad).coerceIn(-1f, 1f)
                    lx = applyCurve(dx, profile.deadzone, profile.curve)
                    ly = -applyCurve(dy, profile.deadzone, profile.curve)
                }
                ControlKind.RIGHT_STICK -> {
                    if (!profile.rightStickMouseMode) {
                        val dx = ((t.current.x - t.origin.x) / rad).coerceIn(-1f, 1f)
                        val dy = ((t.current.y - t.origin.y) / rad).coerceIn(-1f, 1f)
                        rx = applyCurve(dx, profile.deadzone, profile.curve)
                        ry = -applyCurve(dy, profile.deadzone, profile.curve)
                    }
                }
                ControlKind.DPAD -> {
                    val dx = t.current.x - center.x
                    val dy = t.current.y - center.y
                    val threshold = rad * 0.25f
                    if (dy < -threshold) buttons = buttons or XusbMask.DPAD_UP
                    if (dy > threshold) buttons = buttons or XusbMask.DPAD_DOWN
                    if (dx < -threshold) buttons = buttons or XusbMask.DPAD_LEFT
                    if (dx > threshold) buttons = buttons or XusbMask.DPAD_RIGHT
                }
                ControlKind.BTN_A -> buttons = buttons or XusbMask.A
                ControlKind.BTN_B -> buttons = buttons or XusbMask.B
                ControlKind.BTN_X -> buttons = buttons or XusbMask.X
                ControlKind.BTN_Y -> buttons = buttons or XusbMask.Y
                ControlKind.BTN_LB -> buttons = buttons or XusbMask.LB
                ControlKind.BTN_RB -> buttons = buttons or XusbMask.RB
                ControlKind.BTN_LT -> lt = 255
                ControlKind.BTN_RT -> rt = 255
                ControlKind.BTN_BACK -> buttons = buttons or XusbMask.BACK
                ControlKind.BTN_START -> buttons = buttons or XusbMask.START
                ControlKind.BTN_LMB -> {
                    mouseBtns = mouseBtns or 0x01
                    hasMousePill = true
                }
                ControlKind.BTN_RMB -> {
                    mouseBtns = mouseBtns or 0x02
                    hasMousePill = true
                }
            }
        }

        client.sendVirtualGamepad(
            buttons = buttons,
            lt = lt,
            rt = rt,
            lx = (lx * 32767f).toInt().coerceIn(-32767, 32767).toShort(),
            ly = (ly * 32767f).toInt().coerceIn(-32767, 32767).toShort(),
            rx = (rx * 32767f).toInt().coerceIn(-32767, 32767).toShort(),
            ry = (ry * 32767f).toInt().coerceIn(-32767, 32767).toShort()
        )
        if (!profile.rightStickMouseMode && (hasMousePill || profile.nodes.any { (it.kind == ControlKind.BTN_LMB || it.kind == ControlKind.BTN_RMB) && it.visible })) {
            client.sendMouseRel(0, 0, buttons = mouseBtns)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .onSizeChanged { canvasSize = it }
                .pointerInput(editMode) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val prof = currentProfile
                            var stateChanged = false
                            for (change in event.changes) {
                                if (editMode) {
                                    if (change.pressed && !change.previousPressed) {
                                        val hit = prof.nodes.lastOrNull { node ->
                                            val c = nodeCenter(node)
                                            hypot(change.position.x - c.x, change.position.y - c.y) <= nodeRadius(node) * 1.15f
                                        }
                                        if (hit != null) {
                                            selectedEditNode = hit.kind
                                            dragEditPointer = change.id
                                            change.consume()
                                        }
                                    } else if (change.pressed && dragEditPointer == change.id) {
                                        val target = selectedEditNode
                                        if (target != null && canvasSize.width > 1 && canvasSize.height > 1) {
                                            val nx = (change.position.x / canvasSize.width).coerceIn(0.04f, 0.96f)
                                            val ny = (change.position.y / canvasSize.height).coerceIn(0.08f, 0.94f)
                                            val updated = prof.nodes.map {
                                                if (it.kind == target) it.copy(xPct = nx, yPct = ny) else it
                                            }
                                            currentOnProfileChange(prof.copy(nodes = updated))
                                            change.consume()
                                        }
                                    } else if (!change.pressed && dragEditPointer == change.id) {
                                        dragEditPointer = null
                                        change.consume()
                                    }
                                    continue
                                }

                                if (change.pressed && !change.previousPressed) {
                                    val hit = prof.nodes.lastOrNull { node ->
                                        if (!node.visible) return@lastOrNull false
                                        val c = nodeCenter(node)
                                        hypot(change.position.x - c.x, change.position.y - c.y) <= nodeRadius(node) * 1.2f
                                    }
                                    if (hit != null) {
                                        activeTouches[change.id] = ActiveTouch(
                                            pointerId = change.id,
                                            boundNode = hit.kind,
                                            origin = if (hit.kind == ControlKind.LEFT_STICK || hit.kind == ControlKind.RIGHT_STICK) {
                                                change.position
                                            } else {
                                                nodeCenter(hit)
                                            },
                                            current = change.position
                                        )
                                        triggerHaptic(10L)
                                        stateChanged = true
                                        change.consume()
                                    } else if (prof.rightZoneMouseLook && change.position.x > canvasSize.width * 0.5f) {
                                        activeTouches[change.id] = ActiveTouch(
                                            pointerId = change.id,
                                            boundNode = null,
                                            origin = change.position,
                                            current = change.position,
                                            isRightCameraZone = true
                                        )
                                        change.consume()
                                    }
                                } else if (change.pressed && activeTouches.containsKey(change.id)) {
                                    val prev = activeTouches[change.id]!!
                                    if (prev.isRightCameraZone) {
                                        val dx = ((change.position.x - prev.current.x) * 1.4f).toInt()
                                        val dy = ((change.position.y - prev.current.y) * 1.4f).toInt()
                                        if (dx != 0 || dy != 0) {
                                            client.sendMouseRel(dx, dy)
                                        }
                                        activeTouches[change.id] = prev.copy(current = change.position)
                                    } else {
                                        activeTouches[change.id] = prev.copy(current = change.position)
                                        stateChanged = true
                                    }
                                    change.consume()
                                } else if (!change.pressed && activeTouches.containsKey(change.id)) {
                                    val removed = activeTouches.remove(change.id)
                                    if (removed?.boundNode != null) {
                                        stateChanged = true
                                    }
                                    change.consume()
                                }
                            }
                            if (stateChanged) {
                                emitInputState()
                            }
                        }
                    }
                }
        ) {
            for (node in profile.nodes) {
                if (!node.visible && !editMode) continue
                val center = nodeCenter(node)
                val rad = nodeRadius(node)
                val alpha = if (!node.visible) 0.25f else node.opacity
                val isSelectedInEdit = editMode && selectedEditNode == node.kind
                val activeTouch = activeTouches.values.firstOrNull { it.boundNode == node.kind }
                val isPressed = activeTouch != null

                val strokeColor = when {
                    isSelectedInEdit || isPressed -> IndustrialColors.SignalOrange
                    else -> IndustrialColors.Cream.copy(alpha = alpha)
                }
                val fillColor = when {
                    isPressed -> IndustrialColors.SignalOrange.copy(alpha = 0.25f)
                    else -> IndustrialColors.ObsidianBg.copy(alpha = alpha * 0.65f)
                }

                when (node.kind) {
                    ControlKind.LEFT_STICK, ControlKind.RIGHT_STICK -> {
                        drawCircle(fillColor, radius = rad, center = center)
                        drawCircle(strokeColor, radius = rad, center = center, style = Stroke(width = 2.5f))
                        drawLine(
                            strokeColor.copy(alpha = alpha * 0.4f),
                            Offset(center.x - rad * 0.7f, center.y),
                            Offset(center.x + rad * 0.7f, center.y),
                            strokeWidth = 1.5f
                        )
                        drawLine(
                            strokeColor.copy(alpha = alpha * 0.4f),
                            Offset(center.x, center.y - rad * 0.7f),
                            Offset(center.x, center.y + rad * 0.7f),
                            strokeWidth = 1.5f
                        )
                        val knobOffset = if (activeTouch != null) {
                            val dx = activeTouch.current.x - activeTouch.origin.x
                            val dy = activeTouch.current.y - activeTouch.origin.y
                            val dist = hypot(dx, dy).coerceAtLeast(1f)
                            val clamped = dist.coerceAtMost(rad * 0.72f)
                            Offset(center.x + (dx / dist) * clamped, center.y + (dy / dist) * clamped)
                        } else {
                            center
                        }
                        drawCircle(
                            if (isPressed) IndustrialColors.SignalOrange else IndustrialColors.Cream.copy(alpha = alpha),
                            radius = rad * 0.36f,
                            center = knobOffset
                        )
                    }
                    ControlKind.DPAD -> {
                        val arm = rad * 0.92f
                        val thick = rad * 0.34f
                        drawRoundRect(
                            color = fillColor,
                            topLeft = Offset(center.x - arm, center.y - thick),
                            size = Size(arm * 2, thick * 2),
                            cornerRadius = CornerRadius(4f, 4f)
                        )
                        drawRoundRect(
                            color = fillColor,
                            topLeft = Offset(center.x - thick, center.y - arm),
                            size = Size(thick * 2, arm * 2),
                            cornerRadius = CornerRadius(4f, 4f)
                        )
                        drawRoundRect(
                            color = strokeColor,
                            topLeft = Offset(center.x - arm, center.y - thick),
                            size = Size(arm * 2, thick * 2),
                            cornerRadius = CornerRadius(4f, 4f),
                            style = Stroke(width = 2f)
                        )
                        drawRoundRect(
                            color = strokeColor,
                            topLeft = Offset(center.x - thick, center.y - arm),
                            size = Size(thick * 2, arm * 2),
                            cornerRadius = CornerRadius(4f, 4f),
                            style = Stroke(width = 2f)
                        )
                    }
                    else -> {
                        val isRectPill = node.kind in setOf(
                            ControlKind.BTN_LB, ControlKind.BTN_RB,
                            ControlKind.BTN_LT, ControlKind.BTN_RT,
                            ControlKind.BTN_BACK, ControlKind.BTN_START,
                            ControlKind.BTN_LMB, ControlKind.BTN_RMB
                        )
                        if (isRectPill) {
                            val w = rad * 2.3f
                            val h = rad * 1.15f
                            val tl = Offset(center.x - w / 2f, center.y - h / 2f)
                            drawRoundRect(fillColor, tl, Size(w, h), CornerRadius(3f, 3f))
                            drawRoundRect(strokeColor, tl, Size(w, h), CornerRadius(3f, 3f), style = Stroke(2f))
                        } else {
                            drawCircle(fillColor, radius = rad, center = center)
                            drawCircle(strokeColor, radius = rad, center = center, style = Stroke(2.2f))
                        }
                        val measured = textMeasurer.measure(
                            node.label,
                            style = TextStyle(
                                color = strokeColor,
                                fontSize = (12f * node.scale).sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = JetBrainsMonoFamily
                            )
                        )
                        drawText(
                            measured,
                            topLeft = Offset(
                                center.x - measured.size.width / 2f,
                                center.y - measured.size.height / 2f
                            )
                        )
                    }
                }
            }
        }

        // In-Stream Layout Editor Drawer
        if (editMode) {
            val selNode = profile.nodes.firstOrNull { it.kind == selectedEditNode }
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(12.dp)
                    .width(610.dp)
                    .background(IndustrialColors.ObsidianBg.copy(alpha = 0.96f), RoundedCornerShape(2.dp))
                    .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LAYOUT EDITOR // DRAG CONTROLS TO POSITION",
                        color = IndustrialColors.Cream,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .background(IndustrialColors.SignalOrange, RoundedCornerShape(2.dp))
                            .clickable { onExitEditMode() }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            "DONE",
                            color = IndustrialColors.ObsidianBg,
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (pname in ProfileStore.presetNames) {
                        val active = profile.name == pname
                        Box(
                            modifier = Modifier
                                .background(
                                    if (active) IndustrialColors.Cream else IndustrialColors.ObsidianCard,
                                    RoundedCornerShape(2.dp)
                                )
                                .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                                .clickable { onSelectProfile(pname) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                pname.uppercase(),
                                color = if (active) IndustrialColors.ObsidianBg else IndustrialColors.Cream,
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                if (selNode != null) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "NODE: ${selNode.label}",
                            color = IndustrialColors.SignalOrange,
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Text("SCALE", color = IndustrialColors.Muted, fontFamily = JetBrainsMonoFamily, fontSize = 10.sp)
                            Slider(
                                value = selNode.scale,
                                onValueChange = { s ->
                                    onProfileChange(
                                        profile.copy(nodes = profile.nodes.map {
                                            if (it.kind == selNode.kind) it.copy(scale = s) else it
                                        })
                                    )
                                },
                                valueRange = 0.6f..1.5f,
                                colors = SliderDefaults.colors(
                                    thumbColor = IndustrialColors.SignalOrange,
                                    activeTrackColor = IndustrialColors.Cream
                                ),
                                modifier = Modifier.height(24.dp)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Text("ALPHA", color = IndustrialColors.Muted, fontFamily = JetBrainsMonoFamily, fontSize = 10.sp)
                            Slider(
                                value = selNode.opacity,
                                onValueChange = { a ->
                                    onProfileChange(
                                        profile.copy(nodes = profile.nodes.map {
                                            if (it.kind == selNode.kind) it.copy(opacity = a) else it
                                        })
                                    )
                                },
                                valueRange = 0.2f..1.0f,
                                colors = SliderDefaults.colors(
                                    thumbColor = IndustrialColors.SignalOrange,
                                    activeTrackColor = IndustrialColors.Cream
                                ),
                                modifier = Modifier.height(24.dp)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                                .background(if (selNode.visible) IndustrialColors.ObsidianCard else IndustrialColors.SignalOrange)
                                .clickable {
                                    onProfileChange(
                                        profile.copy(nodes = profile.nodes.map {
                                            if (it.kind == selNode.kind) it.copy(visible = !it.visible) else it
                                        })
                                    )
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                if (selNode.visible) "VISIBLE" else "HIDDEN",
                                color = IndustrialColors.Cream,
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "DZ ${(profile.deadzone * 100).toInt()}%",
                        color = IndustrialColors.Muted,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 10.sp
                    )
                    Slider(
                        value = profile.deadzone,
                        onValueChange = { onProfileChange(profile.copy(deadzone = it)) },
                        valueRange = 0.0f..0.25f,
                        modifier = Modifier.weight(1f).height(24.dp),
                        colors = SliderDefaults.colors(
                            thumbColor = IndustrialColors.SignalOrange,
                            activeTrackColor = IndustrialColors.Cream
                        )
                    )
                    EditorToggleChip("CURVE: ${profile.curve.label}", false) {
                        val next = SensitivityCurve.entries[(profile.curve.ordinal + 1) % SensitivityCurve.entries.size]
                        onProfileChange(profile.copy(curve = next))
                    }
                    EditorToggleChip(if (profile.hapticsEnabled) "HAPTIC ON" else "HAPTIC OFF", profile.hapticsEnabled) {
                        onProfileChange(profile.copy(hapticsEnabled = !profile.hapticsEnabled))
                    }
                    EditorToggleChip(if (profile.rightZoneMouseLook) "AIM: ON" else "AIM: OFF", profile.rightZoneMouseLook) {
                        onProfileChange(profile.copy(rightZoneMouseLook = !profile.rightZoneMouseLook))
                    }
                    EditorToggleChip(if (profile.rightStickMouseMode) "RS->MOUSE" else "RS->PAD", profile.rightStickMouseMode) {
                        onProfileChange(profile.copy(rightStickMouseMode = !profile.rightStickMouseMode))
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorToggleChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (active) IndustrialColors.ObsidianBorder else IndustrialColors.ObsidianCard, RoundedCornerShape(2.dp))
            .border(1.dp, if (active) IndustrialColors.SignalOrange else IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 7.dp, vertical = 4.dp)
    ) {
        Text(
            label,
            color = if (active) IndustrialColors.SignalOrange else IndustrialColors.Cream,
            fontFamily = JetBrainsMonoFamily,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
