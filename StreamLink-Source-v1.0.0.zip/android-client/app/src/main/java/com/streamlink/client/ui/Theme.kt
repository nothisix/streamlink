package com.streamlink.client.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.streamlink.client.R

object IndustrialColors {
    val ObsidianBg = Color(0xFF111111)
    val ObsidianCard = Color(0xFF181818)
    val ObsidianBorder = Color(0xFF2A2A2A)
    val Cream = Color(0xFFF4F3EE)
    val CreamCard = Color(0xFFEAE8E1)
    val CreamBorder = Color(0xFFD6D4CC)
    val Muted = Color(0xFF88867E)
    val SignalOrange = Color(0xFFFF4D00)
}

val SpaceGroteskFamily = FontFamily(
    Font(R.font.space_grotesk, FontWeight.Normal),
    Font(R.font.space_grotesk, FontWeight.Bold)
)

val JetBrainsMonoFamily = FontFamily(
    Font(R.font.jetbrains_mono_regular, FontWeight.Normal),
    Font(R.font.jetbrains_mono_bold, FontWeight.Bold)
)
