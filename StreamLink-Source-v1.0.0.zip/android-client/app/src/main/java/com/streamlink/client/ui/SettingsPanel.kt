package com.streamlink.client.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.streamlink.client.controller.ControlKind
import com.streamlink.client.controller.ControlNode
import com.streamlink.client.controller.ControllerProfile
import com.streamlink.client.controller.ProfileStore
import com.streamlink.client.controller.SensitivityCurve
import kotlin.math.hypot

@Composable
fun SettingsPanel(
    activeProfileName: String,
    profile: ControllerProfile,
    inStream: Boolean,
    onSelectProfile: (String) -> Unit,
    onProfileChange: (ControllerProfile) -> Unit,
    onOpenTouchDragEditor: (() -> Unit)? = null,
    onClose: () -> Unit
) {
    var selectedKind by remember { mutableStateOf(ControlKind.LEFT_STICK) }
    val currentProfile by rememberUpdatedState(profile)
    val currentOnProfileChange by rememberUpdatedState(onProfileChange)
    val selectedNode = profile.nodes.firstOrNull { it.kind == selectedKind } ?: profile.nodes.first()

    val avgScale = remember(profile.nodes) {
        val visible = profile.nodes.filter { it.visible }.ifEmpty { profile.nodes }
        visible.map { it.scale }.average().toFloat().coerceIn(0.6f, 1.6f)
    }
    val avgOpacity = remember(profile.nodes) {
        val visible = profile.nodes.filter { it.visible }.ifEmpty { profile.nodes }
        visible.map { it.opacity }.average().toFloat().coerceIn(0.15f, 1.0f)
    }

    fun updateNode(kind: ControlKind, transform: (ControlNode) -> ControlNode) {
        val next = currentProfile.nodes.map { if (it.kind == kind) transform(it) else it }
        currentOnProfileChange(currentProfile.copy(nodes = next))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialColors.ObsidianBg.copy(alpha = 0.88f))
            .clickable(enabled = true, onClick = {}) // block pass-through taps
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.92f)
                .background(IndustrialColors.ObsidianBg, RoundedCornerShape(2.dp))
                .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                .padding(12.dp)
        ) {
            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        "CONTROLLER & LAYOUT SETTINGS",
                        color = IndustrialColors.Cream,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "SIZE, POSITION, SENSITIVITY & HUD PREFERENCES",
                        color = IndustrialColors.Muted,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 9.sp
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (inStream && onOpenTouchDragEditor != null) {
                        Box(
                            modifier = Modifier
                                .background(IndustrialColors.ObsidianCard, RoundedCornerShape(2.dp))
                                .border(1.dp, IndustrialColors.SignalOrange, RoundedCornerShape(2.dp))
                                .clickable(onClick = onOpenTouchDragEditor)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                "DRAG OVERLAY",
                                color = IndustrialColors.SignalOrange,
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .background(IndustrialColors.SignalOrange, RoundedCornerShape(2.dp))
                            .clickable(onClick = onClose)
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            "DONE",
                            color = IndustrialColors.ObsidianBg,
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Profile selector row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "PROFILE:",
                    color = IndustrialColors.Muted,
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 10.sp
                )
                for (name in ProfileStore.presetNames) {
                    val active = name == activeProfileName
                    Box(
                        modifier = Modifier
                            .background(
                                if (active) IndustrialColors.SignalOrange else IndustrialColors.ObsidianCard,
                                RoundedCornerShape(2.dp)
                            )
                            .border(
                                1.dp,
                                if (active) IndustrialColors.SignalOrange else IndustrialColors.ObsidianBorder,
                                RoundedCornerShape(2.dp)
                            )
                            .clickable { onSelectProfile(name) }
                            .padding(horizontal = 9.dp, vertical = 5.dp)
                    ) {
                        Text(
                            name.uppercase(),
                            color = if (active) IndustrialColors.ObsidianBg else IndustrialColors.Cream,
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .background(IndustrialColors.ObsidianCard, RoundedCornerShape(2.dp))
                        .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                        .clickable { onProfileChange(ProfileStore.defaultProfile(activeProfileName)) }
                        .padding(horizontal = 9.dp, vertical = 5.dp)
                ) {
                    Text(
                        "RESET PRESET",
                        color = IndustrialColors.Cream,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // Split Main Content: Left = Interactive Mini Layout Canvas + Control Chips; Right = Exact Sliders & Tuning
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Left column: Visual interactive layout map & control picker
                Column(
                    modifier = Modifier
                        .weight(0.50f)
                        .fillMaxHeight()
                ) {
                    Text(
                        "TAP OR DRAG CONTROL ON MINI-MAP (${selectedNode.label})",
                        color = IndustrialColors.Cream,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(6.dp))

                    var mapSize by remember { mutableStateOf(IntSize(1, 1)) }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .background(IndustrialColors.ObsidianCard, RoundedCornerShape(2.dp))
                            .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                            .onSizeChanged { mapSize = it }
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        if (mapSize.width <= 1 || mapSize.height <= 1) return@detectDragGestures
                                        val hit = currentProfile.nodes.minByOrNull { n ->
                                            hypot(
                                                offset.x - n.xPct * mapSize.width,
                                                offset.y - n.yPct * mapSize.height
                                            )
                                        }
                                        if (hit != null) {
                                            selectedKind = hit.kind
                                        }
                                    },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        if (mapSize.width <= 1 || mapSize.height <= 1) return@detectDragGestures
                                        val nx = (change.position.x / mapSize.width).coerceIn(0.04f, 0.96f)
                                        val ny = (change.position.y / mapSize.height).coerceIn(0.08f, 0.94f)
                                        updateNode(selectedKind) { it.copy(xPct = nx, yPct = ny) }
                                    }
                                )
                            }
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Subtle structural grid
                            val cols = 4
                            val rows = 3
                            for (c in 1 until cols) {
                                val x = size.width * c / cols
                                drawLine(IndustrialColors.ObsidianBorder, Offset(x, 0f), Offset(x, size.height), 1f)
                            }
                            for (r in 1 until rows) {
                                val y = size.height * r / rows
                                drawLine(IndustrialColors.ObsidianBorder, Offset(0f, y), Offset(size.width, y), 1f)
                            }

                            for (node in profile.nodes) {
                                val cx = node.xPct * size.width
                                val cy = node.yPct * size.height
                                val baseR = when (node.kind) {
                                    ControlKind.LEFT_STICK, ControlKind.RIGHT_STICK -> 16f
                                    ControlKind.DPAD -> 15f
                                    else -> 10f
                                } * node.scale
                                val isSel = node.kind == selectedKind
                                val alpha = if (node.visible) 0.9f else 0.22f
                                val stroke = if (isSel) IndustrialColors.SignalOrange else IndustrialColors.Cream.copy(alpha = alpha)
                                val fill = if (isSel) IndustrialColors.SignalOrange.copy(alpha = 0.25f) else IndustrialColors.ObsidianBg.copy(alpha = 0.7f)
                                drawCircle(fill, radius = baseR, center = Offset(cx, cy))
                                drawCircle(stroke, radius = baseR, center = Offset(cx, cy), style = Stroke(width = if (isSel) 2.5f else 1.2f))
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        "SELECT CONTROL:",
                        color = IndustrialColors.Muted,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 9.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        for (node in profile.nodes) {
                            val active = node.kind == selectedKind
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (active) IndustrialColors.SignalOrange else IndustrialColors.ObsidianCard,
                                        RoundedCornerShape(2.dp)
                                    )
                                    .border(
                                        1.dp,
                                        when {
                                            active -> IndustrialColors.SignalOrange
                                            node.visible -> IndustrialColors.ObsidianBorder
                                            else -> IndustrialColors.ObsidianBorder.copy(alpha = 0.4f)
                                        },
                                        RoundedCornerShape(2.dp)
                                    )
                                    .clickable { selectedKind = node.kind }
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    node.label + if (!node.visible) "·OFF" else "",
                                    color = when {
                                        active -> IndustrialColors.ObsidianBg
                                        node.visible -> IndustrialColors.Cream
                                        else -> IndustrialColors.Muted
                                    },
                                    fontFamily = JetBrainsMonoFamily,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Right column: Sliders for selected control + Global Scale/Opacity + Input & HUD settings
                Column(
                    modifier = Modifier
                        .weight(0.50f)
                        .fillMaxHeight()
                        .background(IndustrialColors.ObsidianCard, RoundedCornerShape(2.dp))
                        .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                        .verticalScroll(rememberScrollState())
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "SELECTED: ${selectedNode.label}",
                            color = IndustrialColors.SignalOrange,
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        ToggleChip(
                            label = if (selectedNode.visible) "VISIBLE: ON" else "VISIBLE: OFF",
                            active = selectedNode.visible
                        ) {
                            updateNode(selectedKind) { it.copy(visible = !it.visible) }
                        }
                    }

                    MonoSliderRow(
                        label = "CONTROL SIZE",
                        valueText = "${"%.2f".format(selectedNode.scale)}x",
                        value = selectedNode.scale,
                        range = 0.50f..1.80f
                    ) { v ->
                        updateNode(selectedKind) { it.copy(scale = v) }
                    }

                    MonoSliderRow(
                        label = "CONTROL OPACITY",
                        valueText = "${(selectedNode.opacity * 100).toInt()}%",
                        value = selectedNode.opacity,
                        range = 0.15f..1.00f
                    ) { v ->
                        updateNode(selectedKind) { it.copy(opacity = v) }
                    }

                    MonoSliderRow(
                        label = "POSITION X",
                        valueText = "${(selectedNode.xPct * 100).toInt()}%",
                        value = selectedNode.xPct,
                        range = 0.04f..0.96f
                    ) { v ->
                        updateNode(selectedKind) { it.copy(xPct = v) }
                    }

                    MonoSliderRow(
                        label = "POSITION Y",
                        valueText = "${(selectedNode.yPct * 100).toInt()}%",
                        value = selectedNode.yPct,
                        range = 0.08f..0.94f
                    ) { v ->
                        updateNode(selectedKind) { it.copy(yPct = v) }
                    }

                    Box(Modifier.fillMaxWidth().height(1.dp).background(IndustrialColors.ObsidianBorder))

                    Text(
                        "GLOBAL CONTROLLER LAYOUT",
                        color = IndustrialColors.Cream,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    MonoSliderRow(
                        label = "ALL CONTROLS SIZE",
                        valueText = "${"%.2f".format(avgScale)}x",
                        value = avgScale,
                        range = 0.60f..1.60f
                    ) { targetScale ->
                        val ratio = targetScale / avgScale.coerceAtLeast(0.1f)
                        onProfileChange(
                            profile.copy(
                                nodes = profile.nodes.map {
                                    it.copy(scale = (it.scale * ratio).coerceIn(0.50f, 1.80f))
                                }
                            )
                        )
                    }
                    MonoSliderRow(
                        label = "ALL CONTROLS OPACITY",
                        valueText = "${(avgOpacity * 100).toInt()}%",
                        value = avgOpacity,
                        range = 0.15f..1.00f
                    ) { targetOp ->
                        onProfileChange(
                            profile.copy(
                                nodes = profile.nodes.map { it.copy(opacity = targetOp) }
                            )
                        )
                    }

                    Box(Modifier.fillMaxWidth().height(1.dp).background(IndustrialColors.ObsidianBorder))

                    Text(
                        "INPUT & HUD TUNING",
                        color = IndustrialColors.Cream,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    MonoSliderRow(
                        label = "STICK DEADZONE",
                        valueText = "${(profile.deadzone * 100).toInt()}%",
                        value = profile.deadzone,
                        range = 0.00f..0.25f
                    ) { v ->
                        onProfileChange(profile.copy(deadzone = v))
                    }
                    MonoSliderRow(
                        label = "TRACKPAD SENSITIVITY",
                        valueText = "${"%.2f".format(profile.trackpadSensitivity)}x",
                        value = profile.trackpadSensitivity,
                        range = 0.40f..3.00f
                    ) { v ->
                        onProfileChange(profile.copy(trackpadSensitivity = v))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (c in SensitivityCurve.entries) {
                            ToggleChip(c.label, profile.curve == c) {
                                onProfileChange(profile.copy(curve = c))
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ToggleChip("HAPTICS", profile.hapticsEnabled) {
                            onProfileChange(profile.copy(hapticsEnabled = !profile.hapticsEnabled))
                        }
                        ToggleChip("RS->MOUSE", profile.rightStickMouseMode) {
                            onProfileChange(profile.copy(rightStickMouseMode = !profile.rightStickMouseMode))
                        }
                        ToggleChip("TOUCH AIM", profile.rightZoneMouseLook) {
                            onProfileChange(profile.copy(rightZoneMouseLook = !profile.rightZoneMouseLook))
                        }
                    }

                    ToggleChip(
                        if (profile.hudMinimizedByDefault) "HUD DEFAULT: MINIMIZED" else "HUD DEFAULT: EXPANDED",
                        profile.hudMinimizedByDefault
                    ) {
                        onProfileChange(profile.copy(hudMinimizedByDefault = !profile.hudMinimizedByDefault))
                    }
                }
            }
        }
    }
}

@Composable
private fun MonoSliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                label,
                color = IndustrialColors.Muted,
                fontFamily = JetBrainsMonoFamily,
                fontSize = 9.sp
            )
            Text(
                valueText,
                color = IndustrialColors.Cream,
                fontFamily = JetBrainsMonoFamily,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = IndustrialColors.SignalOrange,
                activeTrackColor = IndustrialColors.SignalOrange,
                inactiveTrackColor = IndustrialColors.ObsidianBorder
            ),
            modifier = Modifier.height(26.dp)
        )
    }
}

@Composable
private fun ToggleChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                if (active) IndustrialColors.SignalOrange else IndustrialColors.ObsidianBg,
                RoundedCornerShape(2.dp)
            )
            .border(
                1.dp,
                if (active) IndustrialColors.SignalOrange else IndustrialColors.ObsidianBorder,
                RoundedCornerShape(2.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Text(
            label,
            color = if (active) IndustrialColors.ObsidianBg else IndustrialColors.Cream,
            fontFamily = JetBrainsMonoFamily,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
