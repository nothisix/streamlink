package com.streamlink.client.media

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaFormat
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Low-latency Opus 48kHz stereo audio decoder + AudioTrack player.
 */
class AudioStreamPlayer {
    private val running = AtomicBoolean(false)
    @Volatile
    var muted: Boolean = false

    private val queue = ArrayBlockingQueue<ByteArray>(24)
    private var thread: Thread? = null

    fun start() {
        if (running.getAndSet(true)) return
        thread = Thread({ runLoop() }, "streamlink-audio").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun submitOpusFrame(opusBytes: ByteArray) {
        if (!running.get() || muted) return
        // Never build audio lag: drop oldest packet if queue is full
        while (!queue.offer(opusBytes)) {
            queue.poll()
        }
    }

    fun stop() {
        running.set(false)
        queue.clear()
        try {
            thread?.join(300)
        } catch (_: InterruptedException) {
        }
        thread = null
    }

    private fun runLoop() {
        var codec: MediaCodec? = null
        var track: AudioTrack? = null
        try {
            val sampleRate = 48000
            val channels = 2
            val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_OPUS, sampleRate, channels).apply {
                // RFC 7845 19-byte OpusHead CSD-0
                val opusHead = ByteBuffer.allocate(19).order(ByteOrder.LITTLE_ENDIAN).apply {
                    put("OpusHead".encodeToByteArray())
                    put(1) // version
                    put(channels.toByte())
                    putShort(312) // pre-skip
                    putInt(sampleRate)
                    putShort(0) // gain
                    put(0) // mapping family
                }.array()
                val csd1 = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(6_500_000L).array()
                val csd2 = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(80_000_000L).array()
                setByteBuffer("csd-0", ByteBuffer.wrap(opusHead))
                setByteBuffer("csd-1", ByteBuffer.wrap(csd1))
                setByteBuffer("csd-2", ByteBuffer.wrap(csd2))
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1024)
            }

            codec = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_AUDIO_OPUS)
            codec.configure(format, null, null, 0)
            codec.start()

            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(3840)

            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(minBuf)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
            track.play()

            val info = MediaCodec.BufferInfo()
            var ptsUs = 0L

            while (running.get()) {
                val frame = queue.poll()
                if (frame != null) {
                    val inIdx = codec.dequeueInputBuffer(2000)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)
                        inBuf?.clear()
                        inBuf?.put(frame)
                        codec.queueInputBuffer(inIdx, 0, frame.size, ptsUs, 0)
                        ptsUs += 10_000L
                    }
                } else {
                    Thread.sleep(2)
                }

                while (running.get()) {
                    val outIdx = codec.dequeueOutputBuffer(info, 0)
                    if (outIdx >= 0) {
                        val outBuf = codec.getOutputBuffer(outIdx)
                        if (outBuf != null && info.size > 0 && !muted) {
                            outBuf.position(info.offset)
                            outBuf.limit(info.offset + info.size)
                            track.write(outBuf, info.size, AudioTrack.WRITE_NON_BLOCKING)
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                    } else {
                        break
                    }
                }
            }
        } catch (_: Throwable) {
            // Gracefully silence audio if device lacks Opus MediaCodec
        } finally {
            try { track?.stop(); track?.release() } catch (_: Exception) {}
            try { codec?.stop(); codec?.release() } catch (_: Exception) {}
        }
    }
}
