package com.streamlink.client

import android.os.Build
import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.streamlink.client.controller.ProfileStore
import com.streamlink.client.net.HostDiscovery
import com.streamlink.client.net.StreamClient
import com.streamlink.client.ui.PairingScreen
import com.streamlink.client.ui.SettingsPanel
import com.streamlink.client.ui.StreamScreen
import kotlin.math.abs
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private lateinit var streamClient: StreamClient

    // Physical Android hardware controller state (merged cleanly with touch overlay in StreamClient)
    private var hwKeyBtnMask = 0
    private var hwHatBtnMask = 0
    private var hwLt = 0
    private var hwRt = 0
    private var hwLx: Short = 0
    private var hwLy: Short = 0
    private var hwRx: Short = 0
    private var hwRy: Short = 0

    private fun applyDisplayRefreshRate(targetHz: Int) {
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            display
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay
        } ?: return

        val currentMode = display.mode ?: return
        // Constrain candidates to the EXACT active physical resolution so Android never triggers display zoom/unzoom
        val sameResModes = display.supportedModes.filter {
            it.physicalWidth == currentMode.physicalWidth &&
                it.physicalHeight == currentMode.physicalHeight
        }
        val best = sameResModes.minByOrNull { abs(it.refreshRate - targetHz.toFloat()) } ?: return
        val lp = window.attributes
        if (lp.preferredDisplayModeId != best.modeId) {
            lp.preferredDisplayModeId = best.modeId
            window.attributes = lp
        }
    }

    private fun pushHardwareGamepad() {
        streamClient.sendHardwareGamepad(
            buttons = hwKeyBtnMask or hwHatBtnMask,
            lt = hwLt,
            rt = hwRt,
            lx = hwLx,
            ly = hwLy,
            rx = hwRx,
            ry = hwRy
        )
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (streamClient.telemetry.value.connected) {
            val isControllerSource =
                (event.source and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                    (event.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK

            val mask = when (event.keyCode) {
                KeyEvent.KEYCODE_BUTTON_A -> 0x1000
                KeyEvent.KEYCODE_BUTTON_B -> 0x2000
                KeyEvent.KEYCODE_BUTTON_X -> 0x4000
                KeyEvent.KEYCODE_BUTTON_Y -> 0x8000
                KeyEvent.KEYCODE_BUTTON_L1 -> 0x0100
                KeyEvent.KEYCODE_BUTTON_R1 -> 0x0200
                KeyEvent.KEYCODE_BUTTON_START -> 0x0010
                KeyEvent.KEYCODE_BUTTON_SELECT -> 0x0020
                KeyEvent.KEYCODE_BUTTON_THUMBL -> 0x0040
                KeyEvent.KEYCODE_BUTTON_THUMBR -> 0x0080
                KeyEvent.KEYCODE_DPAD_UP -> if (isControllerSource) 0x0001 else 0
                KeyEvent.KEYCODE_DPAD_DOWN -> if (isControllerSource) 0x0002 else 0
                KeyEvent.KEYCODE_DPAD_LEFT -> if (isControllerSource) 0x0004 else 0
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (isControllerSource) 0x0008 else 0
                else -> 0
            }

            if (mask != 0) {
                if (event.repeatCount == 0) {
                    hwKeyBtnMask = if (event.action == KeyEvent.ACTION_DOWN) {
                        hwKeyBtnMask or mask
                    } else {
                        hwKeyBtnMask and mask.inv()
                    }
                    pushHardwareGamepad()
                }
                return true
            }

            if (event.keyCode == KeyEvent.KEYCODE_BUTTON_L2) {
                hwLt = if (event.action == KeyEvent.ACTION_DOWN) 255 else 0
                pushHardwareGamepad()
                return true
            }
            if (event.keyCode == KeyEvent.KEYCODE_BUTTON_R2) {
                hwRt = if (event.action == KeyEvent.ACTION_DOWN) 255 else 0
                pushHardwareGamepad()
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (
            streamClient.telemetry.value.connected &&
            (event.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            event.action == MotionEvent.ACTION_MOVE
        ) {
            fun axisShort(raw: Float, invert: Boolean = false): Short {
                val adj = if (abs(raw) < 0.06f) 0f else raw.coerceIn(-1f, 1f)
                val v = if (invert) -adj else adj
                return (v * 32767f).toInt().coerceIn(-32767, 32767).toShort()
            }

            val rawRx = event.getAxisValue(MotionEvent.AXIS_Z).let {
                if (abs(it) > 0.01f) it else event.getAxisValue(MotionEvent.AXIS_RX)
            }
            val rawRy = event.getAxisValue(MotionEvent.AXIS_RZ).let {
                if (abs(it) > 0.01f) it else event.getAxisValue(MotionEvent.AXIS_RY)
            }

            hwLx = axisShort(event.getAxisValue(MotionEvent.AXIS_X), invert = false)
            hwLy = axisShort(event.getAxisValue(MotionEvent.AXIS_Y), invert = true)
            hwRx = axisShort(rawRx, invert = false)
            hwRy = axisShort(rawRy, invert = true)

            hwLt = (max(event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_BRAKE))
                .coerceIn(0f, 1f) * 255f).toInt()
            hwRt = (max(event.getAxisValue(MotionEvent.AXIS_RTRIGGER), event.getAxisValue(MotionEvent.AXIS_GAS))
                .coerceIn(0f, 1f) * 255f).toInt()

            val hatX = event.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hatY = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
            var hat = 0
            if (hatY < -0.5f) hat = hat or 0x0001
            if (hatY > 0.5f) hat = hat or 0x0002
            if (hatX < -0.5f) hat = hat or 0x0004
            if (hatX > 0.5f) hat = hat or 0x0008
            hwHatBtnMask = hat

            pushHardwareGamepad()
            return true
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        streamClient = StreamClient(applicationContext)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        applyDisplayRefreshRate(60)

        setContent {
            val scope = rememberCoroutineScope()
            val discovery = remember { HostDiscovery(applicationContext) }
            val hosts by discovery.hosts.collectAsState()
            val telemetry by streamClient.telemetry.collectAsState()

            var statusMsg by remember { mutableStateOf("") }
            var connecting by remember { mutableStateOf(false) }
            var selectedMaxFps by remember { mutableStateOf(60) }
            var showPairingSettings by remember { mutableStateOf(false) }

            val loaded = remember { ProfileStore.loadAll(applicationContext) }
            var activeProfileName by remember { mutableStateOf(loaded.first) }
            var profileMap by remember { mutableStateOf(loaded.second) }
            val activeProf = profileMap[activeProfileName] ?: ProfileStore.defaultProfile(activeProfileName)

            // Apply display refresh rate strictly when selectedMaxFps changes (never on live telemetry FPS jitter)
            LaunchedEffect(selectedMaxFps) {
                applyDisplayRefreshRate(selectedMaxFps)
            }

            DisposableEffect(telemetry.connected) {
                if (!telemetry.connected) {
                    hwKeyBtnMask = 0
                    hwHatBtnMask = 0
                    hwLt = 0
                    hwRt = 0
                    hwLx = 0
                    hwLy = 0
                    hwRx = 0
                    hwRy = 0
                    discovery.start(scope)
                } else {
                    showPairingSettings = false
                    discovery.stop()
                }
                onDispose {
                    discovery.stop()
                }
            }

            if (telemetry.connected) {
                StreamScreen(
                    client = streamClient,
                    telemetry = telemetry,
                    maxFps = selectedMaxFps,
                    activeProfileName = activeProfileName,
                    profile = activeProf,
                    onProfileChange = { updated ->
                        val nextMap = profileMap.toMutableMap()
                        nextMap[updated.name] = updated
                        profileMap = nextMap
                        ProfileStore.saveAll(applicationContext, activeProfileName, nextMap)
                    },
                    onSelectProfile = { name ->
                        activeProfileName = name
                        ProfileStore.saveAll(applicationContext, name, profileMap)
                    },
                    onDisconnect = {
                        streamClient.disconnect()
                    }
                )
            } else {
                Box(modifier = Modifier.fillMaxSize()) {
                    PairingScreen(
                        discoveredHosts = hosts,
                        statusMessage = statusMsg,
                        connecting = connecting,
                        onOpenSettings = { showPairingSettings = true },
                        onConnect = { ip, port, pin, hevc, maxFps ->
                            if (ip.isBlank() || pin.length != 4) {
                                statusMsg = "ENTER VALID IP AND 4-DIGIT PIN"
                                return@PairingScreen
                            }
                            connecting = true
                            statusMsg = "CONNECTING TO $ip:$port..."
                            selectedMaxFps = maxFps
                            streamClient.connect(
                                ip = ip,
                                port = port,
                                pin = pin,
                                preferHevc = hevc,
                                maxFps = maxFps,
                                clientName = Build.MODEL ?: "Android"
                            ) { ok, msg ->
                                runOnUiThread {
                                    connecting = false
                                    statusMsg = if (ok) "" else msg
                                }
                            }
                        }
                    )

                    if (showPairingSettings) {
                        SettingsPanel(
                            activeProfileName = activeProfileName,
                            profile = activeProf,
                            inStream = false,
                            onSelectProfile = { name ->
                                activeProfileName = name
                                ProfileStore.saveAll(applicationContext, name, profileMap)
                            },
                            onProfileChange = { updated ->
                                val nextMap = profileMap.toMutableMap()
                                nextMap[updated.name] = updated
                                profileMap = nextMap
                                ProfileStore.saveAll(applicationContext, activeProfileName, nextMap)
                            },
                            onClose = { showPairingSettings = false }
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        streamClient.disconnect()
    }
}
