package com.streamlink.client

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.streamlink.client.controller.ProfileStore
import com.streamlink.client.net.HostDiscovery
import com.streamlink.client.net.StreamClient
import com.streamlink.client.ui.PairingScreen
import com.streamlink.client.ui.StreamScreen
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private lateinit var streamClient: StreamClient

    private fun applyDisplayRefreshRate(targetHz: Int) {
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            display
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay
        }
        val modes = display?.supportedModes ?: return
        val best = modes.minByOrNull { abs(it.refreshRate - targetHz.toFloat()) } ?: return
        val lp = window.attributes
        if (lp.preferredDisplayModeId != best.modeId) {
            lp.preferredDisplayModeId = best.modeId
            window.attributes = lp
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        streamClient = StreamClient(applicationContext)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        applyDisplayRefreshRate(60)

        setContent {
            val scope = rememberCoroutineScope()
            val discovery = remember { HostDiscovery(applicationContext) }
            val hosts by discovery.hosts.collectAsState()
            val telemetry by streamClient.telemetry.collectAsState()

            var statusMsg by remember { mutableStateOf("") }
            var connecting by remember { mutableStateOf(false) }
            var selectedMaxFps by remember { mutableStateOf(60) }

            val loaded = remember { ProfileStore.loadAll(applicationContext) }
            var activeProfileName by remember { mutableStateOf(loaded.first) }
            var profileMap by remember { mutableStateOf(loaded.second) }

            LaunchedEffect(selectedMaxFps, telemetry.fps) {
                val target = if (telemetry.connected && telemetry.fps >= 30) telemetry.fps else selectedMaxFps
                applyDisplayRefreshRate(target)
            }

            DisposableEffect(telemetry.connected) {
                if (!telemetry.connected) {
                    discovery.start(scope)
                } else {
                    discovery.stop()
                }
                onDispose {
                    discovery.stop()
                }
            }

            if (telemetry.connected) {
                val activeProf = profileMap[activeProfileName] ?: ProfileStore.defaultProfile(activeProfileName)
                StreamScreen(
                    client = streamClient,
                    telemetry = telemetry,
                    maxFps = selectedMaxFps,
                    profile = activeProf,
                    onProfileChange = { updated ->
                        val nextMap = profileMap.toMutableMap()
                        nextMap[updated.name] = updated
                        profileMap = nextMap
                        ProfileStore.saveAll(applicationContext, activeProfileName, nextMap)
                    },
                    onSelectProfile = { name ->
                        activeProfileName = name
                        ProfileStore.saveAll(applicationContext, name, profileMap)
                    },
                    onDisconnect = {
                        streamClient.disconnect()
                    }
                )
            } else {
                PairingScreen(
                    discoveredHosts = hosts,
                    statusMessage = statusMsg,
                    connecting = connecting,
                    onConnect = { ip, port, pin, hevc, maxFps ->
                        if (ip.isBlank() || pin.length != 4) {
                            statusMsg = "ENTER VALID IP AND 4-DIGIT PIN"
                            return@PairingScreen
                        }
                        connecting = true
                        statusMsg = "CONNECTING TO $ip:$port..."
                        selectedMaxFps = maxFps
                        streamClient.connect(
                            ip = ip,
                            port = port,
                            pin = pin,
                            preferHevc = hevc,
                            maxFps = maxFps,
                            clientName = Build.MODEL ?: "Android"
                        ) { ok, msg ->
                            runOnUiThread {
                                connecting = false
                                statusMsg = if (ok) "" else msg
                            }
                        }
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        streamClient.disconnect()
    }
}
