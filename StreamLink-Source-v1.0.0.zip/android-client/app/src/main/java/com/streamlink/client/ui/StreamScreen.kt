package com.streamlink.client.ui

import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.streamlink.client.R
import com.streamlink.client.controller.ControllerProfile
import com.streamlink.client.controller.VirtualControllerOverlay
import com.streamlink.client.net.InputMode
import com.streamlink.client.net.StreamClient
import com.streamlink.client.net.TelemetryState
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sign

@Composable
fun StreamScreen(
    client: StreamClient,
    telemetry: TelemetryState,
    maxFps: Int,
    activeProfileName: String,
    profile: ControllerProfile,
    onProfileChange: (ControllerProfile) -> Unit,
    onSelectProfile: (String) -> Unit,
    onDisconnect: () -> Unit
) {
    var hudMinimized by remember { mutableStateOf(profile.hudMinimizedByDefault) }
    var miniPillOffset by remember { mutableStateOf(Offset.Zero) }
    var editLayout by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showKeyboard by remember { mutableStateOf(false) }
    var inputMode by remember { mutableStateOf(InputMode.GAMEPAD) }

    val currentProfile by rememberUpdatedState(profile)
    val streamAspect = remember(telemetry.width, telemetry.height) {
        if (telemetry.width > 0 && telemetry.height > 0) {
            (telemetry.width.toFloat() / telemetry.height.toFloat()).coerceIn(0.5f, 3.0f)
        } else {
            16f / 9f
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialColors.ObsidianBg)
    ) {
        // Aspect-ratio-aware video container that safely fits inside both wide phones & tablets without overflow/zoom glitch
        var videoSize by remember { mutableStateOf(IntSize(1, 1)) }
        val currentVideoSize by rememberUpdatedState(videoSize)

        BoxWithConstraints(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            val containerAspect = if (maxHeight.value > 0f) maxWidth.value / maxHeight.value else 16f / 9f
            val videoModifier = if (containerAspect > streamAspect) {
                Modifier
                    .fillMaxHeight()
                    .aspectRatio(streamAspect, matchHeightConstraintsFirst = true)
            } else {
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(streamAspect, matchHeightConstraintsFirst = false)
            }

            Box(
                modifier = videoModifier.onSizeChanged { videoSize = it }
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        SurfaceView(ctx).apply {
                            holder.addCallback(object : SurfaceHolder.Callback {
                                override fun surfaceCreated(holder: SurfaceHolder) {
                                    client.attachSurface(holder.surface, maxFps)
                                }
                                override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
                                override fun surfaceDestroyed(holder: SurfaceHolder) {
                                    client.detachSurface()
                                }
                            })
                        }
                    }
                )

                // Direct Touch Mouse Mode layer (aspect-ratio normalized coordinates)
                if (inputMode == InputMode.DIRECT_TOUCH && !editLayout && !showSettings) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                awaitPointerEventScope {
                                    var twoFingerGesture = false
                                    var activeBtns = 0
                                    while (true) {
                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                        val vs = currentVideoSize
                                        val w = vs.width.coerceAtLeast(1)
                                        val h = vs.height.coerceAtLeast(1)
                                        val pressedList = ev.changes.filter { it.pressed }
                                        if (pressedList.size >= 2) {
                                            twoFingerGesture = true
                                        }
                                        for (ch in ev.changes) {
                                            val nx = (ch.position.x / w).coerceIn(0f, 1f)
                                            val ny = (ch.position.y / h).coerceIn(0f, 1f)
                                            if (ch.pressed && !ch.previousPressed) {
                                                if (pressedList.size == 1 && !twoFingerGesture) {
                                                    activeBtns = 0x01
                                                    client.sendMouseAbs(nx, ny, activeBtns)
                                                } else if (pressedList.size == 2) {
                                                    val cx = (pressedList.sumOf { it.position.x.toDouble() } / pressedList.size / w).toFloat()
                                                    val cy = (pressedList.sumOf { it.position.y.toDouble() } / pressedList.size / h).toFloat()
                                                    client.sendMouseAbs(cx, cy, 0x02)
                                                    client.sendMouseAbs(cx, cy, 0x00)
                                                    activeBtns = 0
                                                }
                                                ch.consume()
                                            } else if (ch.pressed && ch.previousPressed) {
                                                if (!twoFingerGesture && pressedList.size == 1) {
                                                    client.sendMouseAbs(nx, ny, activeBtns)
                                                }
                                                ch.consume()
                                            } else if (!ch.pressed && ch.previousPressed) {
                                                if (pressedList.isEmpty()) {
                                                    if (!twoFingerGesture) {
                                                        client.sendMouseAbs(nx, ny, 0)
                                                    }
                                                    activeBtns = 0
                                                    twoFingerGesture = false
                                                }
                                                ch.consume()
                                            }
                                        }
                                    }
                                }
                            }
                    )
                }
            }
        }

        // Trackpad Mode full-screen gesture layer
        if (inputMode == InputMode.TRACKPAD && !editLayout && !showSettings) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        awaitPointerEventScope {
                            val tracked = HashMap<PointerId, Offset>()
                            var downTimeMs = 0L
                            var totalMoved = 0f
                            var maxFingers = 0
                            var lastTapUpMs = 0L
                            var draggingLmb = false
                            var scrollAccY = 0f
                            var scrollAccX = 0f

                            while (true) {
                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                val sens = currentProfile.trackpadSensitivity.coerceIn(0.4f, 3.0f)
                                val currentlyPressed = ev.changes.filter { it.pressed }
                                if (currentlyPressed.size > maxFingers) {
                                    maxFingers = currentlyPressed.size
                                }

                                for (ch in ev.changes) {
                                    if (ch.pressed && !ch.previousPressed) {
                                        val now = System.currentTimeMillis()
                                        if (tracked.isEmpty()) {
                                            downTimeMs = now
                                            totalMoved = 0f
                                            maxFingers = 1
                                            if (now - lastTapUpMs < 260L) {
                                                draggingLmb = true
                                                client.sendMouseRel(0, 0, buttons = 0x01)
                                            }
                                        }
                                        tracked[ch.id] = ch.position
                                        ch.consume()
                                    } else if (ch.pressed && ch.previousPressed) {
                                        val prev = tracked[ch.id] ?: ch.position
                                        val dxRaw = ch.position.x - prev.x
                                        val dyRaw = ch.position.y - prev.y
                                        tracked[ch.id] = ch.position
                                        totalMoved += hypot(dxRaw, dyRaw)

                                        if (currentlyPressed.size == 1 && maxFingers == 1) {
                                            val accelX = sign(dxRaw) * abs(dxRaw).pow(1.22f) * sens
                                            val accelY = sign(dyRaw) * abs(dyRaw).pow(1.22f) * sens
                                            val dx = accelX.toInt()
                                            val dy = accelY.toInt()
                                            if (dx != 0 || dy != 0) {
                                                client.sendMouseRel(dx, dy, buttons = if (draggingLmb) 0x01 else 0)
                                            }
                                        } else if (currentlyPressed.size == 2 && ch.id == currentlyPressed.first().id) {
                                            scrollAccY += dyRaw
                                            scrollAccX += dxRaw
                                            val vTicks = (scrollAccY / 28f).toInt()
                                            val hTicks = (scrollAccX / 28f).toInt()
                                            if (vTicks != 0 || hTicks != 0) {
                                                scrollAccY -= vTicks * 28f
                                                scrollAccX -= hTicks * 28f
                                                client.sendMouseRel(0, 0, wheel = -vTicks, hWheel = hTicks, buttons = 0)
                                            }
                                        }
                                        ch.consume()
                                    } else if (!ch.pressed && ch.previousPressed) {
                                        tracked.remove(ch.id)
                                        if (tracked.isEmpty()) {
                                            val dur = System.currentTimeMillis() - downTimeMs
                                            if (draggingLmb) {
                                                draggingLmb = false
                                                client.sendMouseRel(0, 0, buttons = 0)
                                            } else if (dur < 220L && totalMoved < 20f) {
                                                if (maxFingers >= 2) {
                                                    client.sendMouseRel(0, 0, buttons = 0x02)
                                                    client.sendMouseRel(0, 0, buttons = 0)
                                                } else {
                                                    client.sendMouseRel(0, 0, buttons = 0x01)
                                                    client.sendMouseRel(0, 0, buttons = 0)
                                                    lastTapUpMs = System.currentTimeMillis()
                                                }
                                            }
                                            scrollAccX = 0f
                                            scrollAccY = 0f
                                            maxFingers = 0
                                        }
                                        ch.consume()
                                    }
                                }
                            }
                        }
                    }
            )
        }

        // Multi-touch virtual controller & layout editor
        VirtualControllerOverlay(
            client = client,
            profile = profile,
            editMode = editLayout,
            visible = inputMode == InputMode.GAMEPAD && !showSettings,
            onProfileChange = onProfileChange,
            onSelectProfile = onSelectProfile,
            onExitEditMode = { editLayout = false }
        )

        // Top HUD Toolbar OR Draggable Minimized Floating Pill
        if (hudMinimized) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
                    .offset { IntOffset(miniPillOffset.x.roundToInt(), miniPillOffset.y.roundToInt()) }
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            miniPillOffset += dragAmount
                        }
                    }
                    .background(IndustrialColors.ObsidianBg.copy(alpha = 0.88f), RoundedCornerShape(2.dp))
                    .border(1.dp, IndustrialColors.SignalOrange.copy(alpha = 0.7f), RoundedCornerShape(2.dp))
                    .clickable { hudMinimized = false }
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(IndustrialColors.SignalOrange, CircleShape)
                    )
                    Text(
                        "${telemetry.rttMs.toInt()}ms·${telemetry.fps}fps",
                        color = IndustrialColors.Cream,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .background(IndustrialColors.ObsidianBg.copy(alpha = 0.94f), RoundedCornerShape(2.dp))
                        .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .background(IndustrialColors.SignalOrange, CircleShape)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            text = "${telemetry.rttMs.toInt()}MS | ${telemetry.fps}FPS | ${"%.1f".format(telemetry.bitrateMbps)}M",
                            color = IndustrialColors.Cream,
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Input Mode Switcher: GAMEPAD | TRACKPAD | DIRECT
                    Row(
                        modifier = Modifier
                            .border(1.dp, IndustrialColors.ObsidianBorder, RoundedCornerShape(2.dp))
                    ) {
                        for (mode in listOf(InputMode.TRACKPAD, InputMode.DIRECT_TOUCH, InputMode.GAMEPAD)) {
                            val active = inputMode == mode
                            Box(
                                modifier = Modifier
                                    .background(if (active) IndustrialColors.SignalOrange else IndustrialColors.ObsidianBg)
                                    .clickable {
                                        inputMode = mode
                                        if (mode != InputMode.GAMEPAD) {
                                            editLayout = false
                                        }
                                    }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    mode.label,
                                    color = if (active) IndustrialColors.ObsidianBg else IndustrialColors.Cream,
                                    fontFamily = JetBrainsMonoFamily,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    HudIconBtn(
                        resId = R.drawable.ic_keyboard,
                        active = showKeyboard,
                        onClick = { showKeyboard = !showKeyboard }
                    )
                    HudIconBtn(
                        resId = R.drawable.ic_layout,
                        active = editLayout,
                        onClick = {
                            showSettings = false
                            inputMode = InputMode.GAMEPAD
                            editLayout = !editLayout
                        }
                    )
                    HudIconBtn(
                        resId = R.drawable.ic_settings,
                        active = showSettings,
                        onClick = {
                            editLayout = false
                            showSettings = !showSettings
                        }
                    )
                    HudIconBtn(
                        resId = R.drawable.ic_lock,
                        active = telemetry.bitrateLocked,
                        onClick = { client.toggleBitrateLock() }
                    )
                    HudIconBtn(
                        resId = if (telemetry.audioMuted) R.drawable.ic_volume_off else R.drawable.ic_volume_on,
                        active = telemetry.audioMuted,
                        onClick = { client.toggleMute() }
                    )
                    HudIconBtn(
                        resId = R.drawable.ic_minimize,
                        active = false,
                        onClick = { hudMinimized = true }
                    )
                    HudIconBtn(
                        resId = R.drawable.ic_power,
                        active = false,
                        tintOrange = true,
                        onClick = onDisconnect
                    )
                }
            }
        }

        // Full native Android IME Keyboard + 1-row PC Special Keys Strip
        if (showKeyboard) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                ImeKeyboardBridge(
                    onKey = { vk, scan, down -> client.sendKeyboard(vk, down, scan) },
                    onClose = { showKeyboard = false }
                )
            }
        }

        // In-stream Controller & Layout Settings Modal
        if (showSettings) {
            SettingsPanel(
                activeProfileName = activeProfileName,
                profile = profile,
                inStream = true,
                onSelectProfile = onSelectProfile,
                onProfileChange = onProfileChange,
                onOpenTouchDragEditor = {
                    showSettings = false
                    inputMode = InputMode.GAMEPAD
                    editLayout = true
                },
                onClose = { showSettings = false }
            )
        }
    }
}

@Composable
private fun HudIconBtn(
    resId: Int,
    active: Boolean,
    tintOrange: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(
                if (active) IndustrialColors.ObsidianBorder else IndustrialColors.ObsidianBg,
                RoundedCornerShape(2.dp)
            )
            .border(
                1.dp,
                if (active || tintOrange) IndustrialColors.SignalOrange else IndustrialColors.ObsidianBorder,
                RoundedCornerShape(2.dp)
            )
            .clickable(onClick = onClick)
            .padding(5.dp)
    ) {
        Icon(
            painter = painterResource(resId),
            contentDescription = null,
            tint = if (tintOrange || active) IndustrialColors.SignalOrange else IndustrialColors.Cream,
            modifier = Modifier.size(14.dp)
        )
    }
}
