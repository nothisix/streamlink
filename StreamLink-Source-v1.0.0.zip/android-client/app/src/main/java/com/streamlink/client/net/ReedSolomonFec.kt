package com.streamlink.client.net

/**
 * Deterministic Cauchy Reed-Solomon erasure decoder over GF(2^8)
 * with primitive polynomial 0x11D, matching pc-host/src/net/fec.rs.
 */
object ReedSolomonFec {
    private const val PRIM_POLY = 0x11D
    private val exp = IntArray(512)
    private val log = IntArray(256)

    init {
        var x = 1
        for (i in 0 until 255) {
            exp[i] = x
            exp[i + 255] = x
            log[x] = i
            x = x shl 1
            if ((x and 0x100) != 0) {
                x = x xor PRIM_POLY
            }
        }
    }

    private fun gfMul(a: Int, b: Int): Int {
        if (a == 0 || b == 0) return 0
        return exp[log[a] + log[b]]
    }

    private fun gfInv(a: Int): Int {
        return exp[255 - log[a]]
    }

    private fun cauchyEntry(r: Int, c: Int, k: Int): Int {
        return gfInv(r xor (k + c))
    }

    fun reconstructData(shards: Array<ByteArray?>, k: Int, m: Int): Boolean {
        if (k <= 0 || shards.size < k + m) return false
        val missingData = ArrayList<Int>(m)
        for (i in 0 until k) {
            if (shards[i] == null) missingData.add(i)
        }
        if (missingData.isEmpty()) return true

        val present = ArrayList<Int>(k)
        for (i in 0 until (k + m)) {
            if (shards[i] != null) {
                present.add(i)
                if (present.size == k) break
            }
        }
        if (present.size < k) return false

        val shardLen = shards[present[0]]!!.size
        val mat = IntArray(k * k)
        val inv = IntArray(k * k)

        for (rowIdx in 0 until k) {
            val shardId = present[rowIdx]
            if (shardId < k) {
                mat[rowIdx * k + shardId] = 1
            } else {
                val r = shardId - k
                for (c in 0 until k) {
                    mat[rowIdx * k + c] = cauchyEntry(r, c, k)
                }
            }
            inv[rowIdx * k + rowIdx] = 1
        }

        // Gauss-Jordan inversion over GF(2^8)
        for (col in 0 until k) {
            var pivot = -1
            for (r in col until k) {
                if (mat[r * k + col] != 0) {
                    pivot = r
                    break
                }
            }
            if (pivot == -1) return false
            if (pivot != col) {
                for (j in 0 until k) {
                    val tmpM = mat[col * k + j]
                    mat[col * k + j] = mat[pivot * k + j]
                    mat[pivot * k + j] = tmpM
                    val tmpI = inv[col * k + j]
                    inv[col * k + j] = inv[pivot * k + j]
                    inv[pivot * k + j] = tmpI
                }
            }

            val scale = gfInv(mat[col * k + col])
            if (scale != 1) {
                for (j in 0 until k) {
                    mat[col * k + j] = gfMul(mat[col * k + j], scale)
                    inv[col * k + j] = gfMul(inv[col * k + j], scale)
                }
            }

            for (r in 0 until k) {
                if (r == col) continue
                val factor = mat[r * k + col]
                if (factor != 0) {
                    for (j in 0 until k) {
                        mat[r * k + j] = mat[r * k + j] xor gfMul(factor, mat[col * k + j])
                        inv[r * k + j] = inv[r * k + j] xor gfMul(factor, inv[col * k + j])
                    }
                }
            }
        }

        for (targetCol in missingData) {
            val recovered = ByteArray(shardLen)
            for (j in 0 until k) {
                val coeff = inv[targetCol * k + j]
                if (coeff == 0) continue
                val src = shards[present[j]]!!
                if (coeff == 1) {
                    for (i in 0 until shardLen) {
                        recovered[i] = (recovered[i].toInt() xor (src[i].toInt() and 0xFF)).toByte()
                    }
                } else {
                    for (i in 0 until shardLen) {
                        val prod = gfMul(coeff, src[i].toInt() and 0xFF)
                        recovered[i] = (recovered[i].toInt() xor prod).toByte()
                    }
                }
            }
            shards[targetCol] = recovered
        }
        return true
    }
}
