package com.streamlink.client

import com.streamlink.client.net.Protocol
import com.streamlink.client.net.ReedSolomonFec
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProtocolAndFecTest {
    @Test
    fun headerGamepadAndMousePacketsRoundtrip() {
        val pkt = Protocol.buildGamepadInput(
            sessionId = 0x12345678,
            buttons = 0x1000,
            lt = 128,
            rt = 255,
            lx = 15000,
            ly = -15000,
            rx = 0,
            ry = 32767,
            seq = 42
        )
        assertEquals(24, pkt.size)
        val hdr = Protocol.parseHeader(pkt, pkt.size)
        assertNotNull(hdr)
        assertEquals(Protocol.PKT_INPUT_GAMEPAD, hdr!!.type)
        assertEquals(0x12345678, hdr.sessionId)

        assertEquals("0482", Protocol.sanitizePin(" 0482 "))
        assertEquals("1234", Protocol.sanitizePin("12a34"))

        val rel = Protocol.buildMouseRel(0x11223344, -10, 15, -1, 1, 3)
        assertEquals(15, rel.size)
        assertEquals(Protocol.PKT_INPUT_MOUSE_REL, Protocol.parseHeader(rel, rel.size)!!.type)

        val abs = Protocol.buildMouseAbs(0x11223344, 32768, 16384, 1, 0, 0)
        assertEquals(15, abs.size)
        assertEquals(Protocol.PKT_INPUT_MOUSE_ABS, Protocol.parseHeader(abs, abs.size)!!.type)
    }

    @Test
    fun cauchyReedSolomonRecoversMissingDataShards() {
        val k = 3
        val m = 2
        val len = 16
        val d0 = ByteArray(len) { (it * 7 + 1).toByte() }
        val d1 = ByteArray(len) { (it * 13 + 3).toByte() }
        val d2 = ByteArray(len) { (it * 29 + 5).toByte() }

        val exp = IntArray(512)
        val log = IntArray(256)
        var x = 1
        for (i in 0 until 255) {
            exp[i] = x; exp[i + 255] = x; log[x] = i
            x = x shl 1
            if ((x and 0x100) != 0) x = x xor 0x11D
        }
        fun gfMul(a: Int, b: Int) = if (a == 0 || b == 0) 0 else exp[log[a] + log[b]]
        fun gfInv(a: Int) = exp[255 - log[a]]

        val data = arrayOf(d0, d1, d2)
        val parity = Array(m) { ByteArray(len) }
        for (r in 0 until m) {
            for (c in 0 until k) {
                val coeff = gfInv(r xor (k + c))
                for (i in 0 until len) {
                    parity[r][i] = (parity[r][i].toInt() xor gfMul(coeff, data[c][i].toInt() and 0xFF)).toByte()
                }
            }
        }

        val shards = arrayOf<ByteArray?>(null, d1, null, parity[0], parity[1])
        assertTrue(ReedSolomonFec.reconstructData(shards, k, m))
        assertArrayEquals(d0, shards[0])
        assertArrayEquals(d2, shards[2])
    }
}
